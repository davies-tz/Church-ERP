import uuid

from httpx import ASGITransport, AsyncClient
from sqlalchemy import select

from app.main import app
from app.core.config import settings
from app.core.db import SessionLocal, tenant_session
from app.domain.templates import seed_levels
from app.models import Tenant


async def test_operator_bootstrap_keeps_dns_and_publishing_gates(two_tenants, monkeypatch):
    a, b = two_tenants
    async with SessionLocal() as session:
        tenants = (await session.execute(select(Tenant).where(Tenant.id.in_([a, b])))).scalars().all()
        slugs = {str(t.id): t.slug for t in tenants}
    for tid in [a, b]:
        async with tenant_session(tid) as session:
            await seed_levels(session, tid, 'blank')
    host = f'bootstrap-{uuid.uuid4().hex[:10]}.example.org'
    route = f'/platform/tenants/{slugs[a]}/site-bootstrap'
    headers = {'X-Platform-Token': settings.PLATFORM_ADMIN_TOKEN}
    async def no_proof(*args): return False
    async def proof(*args): return True
    monkeypatch.setattr('app.domain.site_bootstrap.domain_txt_verified', no_proof)
    async with AsyncClient(transport=ASGITransport(app=app), base_url='https://operator.example.org') as client:
        assert (await client.post(route, json={'hostname': host})).status_code == 403
        first = await client.post(route, headers=headers, json={'hostname': host})
        assert first.status_code == 200, first.text
        data = first.json()
        assert data['verified_at'] is None and data['is_published'] is False
        repeat = await client.post(route, headers=headers, json={'hostname': host})
        assert repeat.json() == data
        assert (await client.get(f'https://{host}/sites/public', params={'hostname': host})).status_code == 404
        assert (await client.post(route, headers=headers, json={'hostname': host, 'publish': True})).status_code == 400
        assert (await client.post(route, headers=headers, json={'hostname': host, 'verify_dns': True})).status_code == 400
        assert (await client.post(f'/platform/tenants/{slugs[b]}/site-bootstrap', headers=headers,
                                  json={'hostname': host})).status_code == 409
        monkeypatch.setattr('app.domain.site_bootstrap.domain_txt_verified', proof)
        done = await client.post(route, headers=headers, json={'hostname': host, 'verify_dns': True, 'publish': True})
        assert done.status_code == 200, done.text
        assert done.json()['verified_at'] and done.json()['is_published']
        assert (await client.get(f'https://{host}/sites/public', params={'hostname': host})).status_code == 200
        assert (await client.get('https://wrong.example.org/sites/public', params={'hostname': host})).status_code == 404
        assert (await client.post(route, headers=headers, json={'hostname': 'other.example.org'})).status_code == 409
