"""Operator-only initial site setup, retaining real DNS proof and explicit publishing."""
import secrets
from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import select

from app.core.db import tenant_session, set_tenant
from app.domain.church_sites import normalize_hostname, domain_txt_verified
from app.domain.structure import create_org_unit
from app.models import Tenant, HierarchyLevelType, OrgUnit, ChurchSite, ChurchSiteDomain


async def bootstrap_site(slug, hostname, *, verify_dns=False, publish=False):
    try:
        host = normalize_hostname(hostname)
    except ValueError as error:
        raise HTTPException(400, str(error)) from error
    async with tenant_session(None) as session:
        # Serialize setup for this tenant. Every subsequent tenant-owned query
        # runs under its transaction-local RLS context and explicit tenant filter.
        tenant = (await session.execute(select(Tenant).where(
            Tenant.slug == slug, Tenant.status == 'active').with_for_update())).scalar_one_or_none()
        if tenant is None:
            raise HTTPException(404, 'Tenant not found')
        await set_tenant(session, str(tenant.id))
        site = (await session.execute(select(ChurchSite).where(
            ChurchSite.tenant_id == tenant.id))).scalars().all()
        if len(site) > 1:
            raise HTTPException(409, 'Use the existing site editor for an established tenant')
        if site:
            site = site[0]
            domain = (await session.execute(select(ChurchSiteDomain).where(
                ChurchSiteDomain.tenant_id == tenant.id,
                ChurchSiteDomain.site_id == site.id,
                ChurchSiteDomain.hostname == host))).scalar_one_or_none()
            if domain is None:
                raise HTTPException(409, 'Initial site already exists; use its site editor')
        else:
            if (await session.execute(select(OrgUnit.id).where(
                    OrgUnit.tenant_id == tenant.id).limit(1))).first():
                raise HTTPException(409, 'Use the site editor for an existing church structure')
            claimed = (await session.execute(select(ChurchSiteDomain.id).where(
                ChurchSiteDomain.hostname == host))).first()
            if claimed:
                raise HTTPException(409, 'Hostname already claimed')
            level = (await session.execute(select(HierarchyLevelType).where(
                HierarchyLevelType.tenant_id == tenant.id,
                HierarchyLevelType.parent_key.is_(None)).order_by(
                    HierarchyLevelType.depth))).scalars().first()
            if level is None:
                raise HTTPException(409, 'Tenant has no root hierarchy level')
            unit = await create_org_unit(session, tenant_id=str(tenant.id),
                                         level_key=level.key, name=tenant.name)
            site = ChurchSite(tenant_id=tenant.id, org_unit_id=unit.id,
                              display_name=tenant.name, is_published=False)
            session.add(site)
            await session.flush()
            domain = ChurchSiteDomain(tenant_id=tenant.id, site_id=site.id,
                                      hostname=host, verification_token=secrets.token_urlsafe(32))
            session.add(domain)
            await session.flush()
        if verify_dns and domain.verified_at is None:
            if not await domain_txt_verified(host, domain.verification_token):
                raise HTTPException(400, 'DNS TXT verification was not found')
            domain.verified_at = datetime.now(timezone.utc)
        if publish:
            if domain.verified_at is None:
                raise HTTPException(400, 'Verify DNS before publishing')
            site.is_published = True
        return dict(site_id=str(site.id), domain_id=str(domain.id), hostname=host,
                    dns_record=f'_sanctuary.{host}',
                    dns_value=f'sanctuary-site-verification={domain.verification_token}',
                    verified_at=domain.verified_at.isoformat() if domain.verified_at else None,
                    is_published=site.is_published)
