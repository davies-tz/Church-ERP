"""Read-only hosted smoke checks for a fresh, unpublished acceptance service.

This does not provision a tenant, bypass DNS proof, or certify live E2E.
"""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('base_url')
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    base = args.base_url.rstrip('/')
    host = urlsplit(base).hostname
    if urlsplit(base).scheme != 'https' or not host:
        raise SystemExit('A real HTTPS service URL is required')
    paths = [('/', {200}), ('/health', {200}), ('/api/health', {200}),
             ('/.env', {404}), ('/api/not-a-route', {404}),
             ('/api/platform/tenants', {403}),
             ('/api/sites/manage/units', {401, 403, 404}),
             (f'/api/sites/public?hostname={host}', {404}),
             (f'/api/sites/public/notices?hostname={host}', {404}),
             (f'/api/sites/public/sermons?hostname={host}', {404}),
             ('/api/sites/public?hostname=grace.localhost', {400, 404})]
    results = []
    for path, expected in paths:
        try:
            response = urlopen(Request(base + path), timeout=30)
        except HTTPError as error:
            response = error
        with response:
            body = response.read(1000).decode('utf-8', errors='replace')
            status = response.code
            ok = status in expected
            if path in {'/health', '/api/health'}:
                ok = ok and json.loads(body) == {'status': 'ok'}
            results.append({'path': path, 'status': status, 'pass': ok})
    evidence = {'checked_at_utc': datetime.now(timezone.utc).isoformat(),
                'base_url': base, 'scope': 'Read-only fresh/unpublished service; not live tenant E2E',
                'tls': 'Standard certificate and hostname validation enabled',
                'result': 'PASS' if all(r['pass'] for r in results) else 'FAIL',
                'checks': results}
    args.evidence.parent.mkdir(parents=True, exist_ok=True)
    args.evidence.write_text(json.dumps(evidence, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(evidence, indent=2))
    if evidence['result'] != 'PASS':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
