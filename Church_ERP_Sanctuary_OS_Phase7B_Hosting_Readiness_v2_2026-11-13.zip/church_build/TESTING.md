# Actual checks vs. pending checks — Sanctuary build

## Current continuation — free test hosting preparation (13 November 2026) 🔄

- Selected **Render Free + Neon Free**. See `deploy/FREE_HOSTING.md` and `render.yaml`.
- Added a single-origin hosted entrypoint and image. It serves only the compiled
  frontend, preserves Host on `/api`, validates secrets/TLS and rejects a database
  role that bypasses RLS. Hosted startup migrates but never seeds demo accounts.
- Added tenant/scoped editor unit choices, explicit tenant filters for sermon
  management, and no-store media responses so shared caches do not retain newly
  withdrawn sermons. Localized domain status labels and guarded editor submissions.
- Added native keyboard-modal focus handling for Bible/sermon dialogs; authentic
  WEB text retrieval/read-only behavior is unchanged. Localized text-size labels.
- Added built-React browser contract tests with explicit fixtures (not live E2E),
  plus hosted-routing, database-role and editor-scope tests for the backend suite;
  **these API-level tests have not executed here**.
- **Passed locally:** 8 hierarchy + 6 hosted-configuration tests, Python compilation,
  sermon function checks, 6 palette checks, and parsing 42 TS/TSX files with a
  locally cached Babel 7.29.12 parser. Parsing is not a TypeScript typecheck/build.
- **Cloud preparation verified:** a separate Neon Free PostgreSQL 16 project,
  application-role login with NOSUPERUSER/NOBYPASSRLS, and private object-storage
  bucket. No application migrations or application RLS integration ran there yet.
- GitHub connection can read the repository but **creating a branch was rejected
  with HTTP 403**. No new branch/commit/PR, source deployment, or CI run exists.
  Existing Render service was not modified. GitHub write authorization is needed.
- Still pending: actual PostgreSQL migration/RLS/API suites, locked frontend
  production build, domain ownership/HTTPS, browser E2E/accessibility/usability,
  backup/restore and security review. A free hosting URL does not bypass DNS proof.

Evidence for this continuation is in `evidence/2026-11-13-hosting/`. Earlier dated
results below are history. **7B stays 🔄; no later phase has started.**


## 13 November 2026 — Phase 7B continuation 🔄

This is the current delivery status; dated results below are historical.
Started from `Church_ERP_Sanctuary_OS_Phase7B_Privacy_Increment_2026-11-12.zip`.
Compared and merged `Church_ERP_Sanctuary_OS_Phase7B_Ancestor_Consent_Hardening_2026-11-09.zip`,
which contains safeguards missing from the later archive. The original 7 November
Public Bulletins baseline remains the lineage; this is a full incremental source delivery.

- Restored migration **0021**, separate descendant-site consent (false by default),
  tenant/parent/path ancestry proof, English/Kiswahili controls, site identity remount,
  PostgreSQL regressions, acceptance runbook and CI workflow from the 9 November source.
- Retained the 12 November strict UUID/path parser, API tenant filter, domain-layer
  tenant ownership check and rejection of public announcements without a church unit.
- New: reject duplicate ancestry proof rows, validate submitted church UUIDs before SQL,
  convert malformed domain-layer IDs to a controlled publication error, associate form
  labels with controls, allow bounded multiline notice text, prevent duplicate submissions,
  and clear public-sharing consent when cancelling. The TypeScript check now resolves
  the project's compiler instead of a Linux-specific absolute path.
- Added eight executable hierarchy regressions, five publication guard cases for the
  backend suite, a local evidence recorder, and a disposable-CI migration rollback check.
- Branding and the existing authentic, read-only English WEB Bible remain intact.
  Kiswahili UI does not claim to supply a Kiswahili Bible translation.

**Verified now:** 8 hierarchy regression tests; Python compilation; sermon validation
function checks; 6 palette-token contrast checks. These do not prove database security
or whole-interface accessibility.

**Not passed here:** schema/SQL and DNS-mock scripts (missing Python dependencies),
TypeScript syntax and production build (compiler/dependencies unavailable), backend
suite/migrations (pytest/Alembic and PostgreSQL environment unavailable). Docker CLI
is installed, but the Docker Desktop Linux engine is not running. Dependency downloads
failed; the broader-access retry was rejected by automatic approval review.

**Not executed:** live domain/HTTPS, browser E2E, keyboard/screen reader/mobile/user
acceptance, backup/restore and production security review. No real domain or deployment
was supplied. CI has been updated but has **not** run in this session.

Run `python scripts/verify_phase7b.py` to reproduce the local checks. Inspect
`evidence/2026-11-13/results.json` and its individual command logs, plus
`evidence/2026-11-13/source_lineage.json` and `changes_from_2026-11-12.patch`.
See `PHASE7B_ACCEPTANCE_RUNBOOK.md` for the remaining PostgreSQL and deployment checks.
Apply migration 0021 before running the updated app; do not downgrade a real database
just to test rollback (it discards descendant-sharing choices).

**Phase 7B stays 🔄. No later phase was started or accepted in this delivery.**


## Checks executed while preparing this package

- `python -m compileall -q backend/app backend/tests backend/alembic/versions` — Python syntax and import-file compilation (pass).
- TypeScript compiler `transpileModule` parse of all frontend `.ts` and `.tsx` files — TS/TSX syntax (pass). **Not a full typecheck**.
- Browser CSS visual QA screenshots using Chromium on a standalone HTML design preview — static design only; **not an end-to-end test of React**.
- Pure validation test for byte ranges, file signatures and allowed URLs via isolated module-function execution (see check logs, if available).

## Checks NOT executed here

Docker/Postgres/MinIO and Node dependencies are not installed in the execution environment. Consequently, no assertion is made that the full app deployed successfully or that the integration tests passed.

## On the user's Windows machine (Docker Desktop)

```powershell
cd "C:\Users\HomePC\Desktop\Church_ERP-main"
# Replace/merge with delivered source files, keep your previous .env and database volume.
docker compose up -d --build
docker compose exec backend alembic upgrade head
docker compose exec backend pytest tests/test_sermons.py -v
docker compose exec backend pytest -v
```

Browser demo: http://localhost:5173/?tenant=grace and http://localhost:5173/?tenant=stmarks . Log in as admin for the chosen tenant and go to **Sermons**. Upload a small MP3 or add a real YouTube URL; it starts as **draft**, so public homepage stays empty. Click **Publish**, refresh public home, verify the sermon card and playback. Then archive and verify the item disappears publicly.

## Mandatory manual acceptance tests

1. Open Grace and St. Mark's in separate private browser sessions. Confirm different branding, no global church directory and no cross-tenant sermons.
2. Add a **draft** in Grace: it does not appear publicly. Publish: it appears in Grace only. Archive: disappears. Test cross-tenant guessed media IDs return 404.
3. Upload a small real MP3 and play/pause/seek. Confirm HTTP `206 Partial Content` on range requests and `416` on invalid range.
4. Try uploading an `.html` file disguised as MP4 or a file over 25MB: request must fail. Try an invalid URL: request must fail.
5. Sign in to St. Mark's and check there is no inherited Grace login. A member cannot see the media editor or staff financial figures.
6. With no active database connection, public sermons show an honest offline state rather than invented content.
7. Open Bible by mouse, Tab/Enter and on touch; choose John 3, change chapter, search, zoom. With internet disabled, show connection error and eBible fallback.
8. At screen widths 360/390/768/1024/1440, ensure no horizontal overflow or truncated navigation. Repeat in English and Kiswahili.
9. Confirm readable contrast, focus indicators, 200% zoom and reduced-motion behavior. Run a screen reader pass on each dialog.
10. Test with real non-technical church members, not only developers. See `DESIGN_SYSTEM.md` for the guided usability script.


## Research-led iteration checks (7 November 2026)

**Executed successfully in this build:**

```bash
python scripts/check_design.py         # 6 core AA palette checks — PASS
python scripts/check_sermon_logic.py   # media magic, size, URL and byte ranges — PASS
python -m compileall -q backend/app backend/tests backend/alembic/versions  # syntax — PASS
```

**Attempted but not runnable here:**

- `cd frontend && npm run build` — **blocked**, because the current container's `node_modules` has empty/partial `@types` and React packages. `npm ci` timed out in the restricted environment. Re-run after a clean dependency install on the user's machine.
- `cd backend && pytest -q tests/test_sermons.py` — **blocked**, environment missing `asyncpg` and a Docker/PostgreSQL instance. The tests were not marked as passed.

**NEW manual acceptance checks:**

1. In admin dashboard, grant a role `view_reports` but not `view_finance`/`manage_assets`. Confirm finance, assets and finance CSV are absent; test API endpoints independently with that role.
2. Use **Easy view** with keyboard, on 360px device, and switch `?tenant=grace` to `?tenant=stmarks`: preference should be independently stored per tenant.
3. Test text color contrast for both public-site themes; the script covers only canonical token pairs, not every nested UI surface.
4. Check member navigation no longer includes privileged structure management without the permission.
5. Original preview images are **static samples**, not a pass for React, accessibility, API or Docker integration.

See `BUILD_PHASES_2026_2027.md` for the next source-building sprint and launch gates.


## Phase 7B implementation test report — 7 November 2026

**Executed in this environment:**

- `python scripts/test_church_site_logic.py` — **PASS**: normalizing hostnames, rejecting 11 malformed/unsafe domains, verifying DNS TXT (success/failure with mocked DNS).
- `python -m compileall -q backend/app backend/alembic/versions` — **PASS**, Python syntax only.
- TypeScript compiler `transpileModule` of **41** `.ts`/`.tsx` files — **PASS**, syntax parsing only (not a typecheck).

**Unavailable / NOT passed:**

- `npm ci` timed out because this execution environment could not fetch packages; a React production build was **not** completed.
- `pytest tests/test_church_sites.py` was **not** run because Python `asyncpg` and a PostgreSQL environment are unavailable here; test exists for Windows/Docker.
- Production domain DNS/TLS, registration server-side constraints, full UI/keyboard checks, performance, pen testing and backup/restore are outstanding.

**Run locally in Docker after applying the ZIP as a separate test copy:**

```powershell
docker compose up -d --build
docker compose exec backend alembic upgrade head
docker compose exec backend python -m app.seeds.seed
docker compose exec backend pytest tests/test_church_sites.py -v
docker compose exec backend pytest -v
```

**Browser checks:**

- `http://localhost:5173/?site=grace.localhost` is only Grace's public homepage.
- `http://localhost:5173/?site=stmarks.localhost` is only St. Mark's public homepage.
- Both demo domains are seeded as verified local-only mappings; they are not registered public websites.
- Sign in to Grace, navigate **Church websites / Tovuti za makanisa**; update the welcome text and verify the public page changes.
- Publish a sermon under a specific org unit, ensure only the matching site displays it; tenant-global sermon feed must not leak it.
- Confirm an unverified custom domain returns 404, verify TXT ownership, configure HTTPS in hosting, and then confirm the public endpoint resolves correctly.
- Check unauthenticated visitors cannot create/update sites and a scoped editor cannot manage another unit.


### 7 November 2026 — Phase 7B hardening, still 🔄 (not ✅)

The latest source update binds domain-specific public APIs to the real HTTP Host, resolves verified domain → tenant before accepting a client tenant header, blocks broad legacy registration from church-specific domains, and prevents parish registration/sermon pages from displaying other churches. Vite now preserves the Host; database/cache/storage/admin ports bind to loopback for the local demo.

Offline validation: Python syntax, 41 TypeScript/TSX syntax parses, hostname/DNS-mock checks, media validation and six color-token contrast checks **passed**. Docker/PostgreSQL/RLS integration, full npm build, real DNS/HTTPS, security and user acceptance remain **unverified**. See `PHASE7B_SECURITY_AND_TEST_RESULTS.md` for exact commands and evidence. **Do not mark green ✅ yet.**


### 7 November 2026 — Phase 7B public bulletin publishing (current increment) 🔄

**Built in code, not production-verified:**

- Added migration `0020_public_bulletins.py`: announcements have `is_public` with a **false** database default. All existing and future notices stay private unless an authorized editor explicitly opts into public display.
- The staff announcement form includes an English/Kiswahili public-visibility checkbox (off by default), with an explanation of who can read the notice.
- Verified church homepages now show a small editorial updates section only when actual public notices exist. No placeholder notices or tenant directory.
- New `GET /sites/public/notices?hostname=<current-host>` verifies the request Host + published site, then applies tenant RLS and selects at most five deliberately public notices from the exact site unit or ancestor units. No sibling notices, internal-only announcements, publisher identity or internal org identifiers are returned. Parent-unit propagation is explicit opt-in on the publication itself.
- Added PostgreSQL integration assertions to `backend/tests/test_church_sites.py` for private/public, same-tenant sibling, cross-tenant and hostname-spoof isolation, plus database-free boundary and schema checks in `scripts/test_public_bulletins.py`.

**Offline checks passed:** `python -m compileall`, `python scripts/test_public_bulletins.py`, existing DNS and media checks, and TypeScript/TSX transpile-parsing. **Not verified:** PostgreSQL integration, RLS, full npm production build, deployment, accessibility/user acceptance. Full frontend installation was blocked by missing npm packages (offline cache incomplete); PostgreSQL/Docker are unavailable here.

**Do not award Phase 7B ✅** until the required integration and acceptance gates pass. Status stays 🔄.


### 2026-11-12 Phase 7B privacy increment (verification pending)
- Public bulletin scope now requires canonical, nonrepeating hierarchy UUIDs ending at the requested church unit; malformed paths fail closed.
- Public notices without a church unit are rejected on authenticated publishing and domain creation; public listing excludes unscoped notices.
- Publishing checks the target unit tenant explicitly, in addition to session scoping.
- Database/RLS, full frontend build, live DNS/TLS, browser accessibility and end-to-end acceptance have **not** been verified. Phase 7B remains 🔄.
