import { useEffect, useState } from "react";
import type { Branding } from "../lib/branding";
import { api } from "../lib/api";
import { TENANT_SLUG } from "../lib/tenant";
import { LanguageToggle } from "../components/LanguageToggle";
import { BibleReader } from "../components/BibleReader";
import { ModalDialog } from "../components/ModalDialog";
import type { Sermon } from "../lib/sermons";
import type { PublicChurchSite } from "../lib/churchSites";
import "./PublicHome.css";

type PublicNotice = { id: string; title: string; body: string; urgency: string; created_at: string };

type Props = { branding: Branding; churchSite: PublicChurchSite | null; locale: string; onLocaleChange: (value: string) => void; onLogin: () => void; onRegister: () => void };
const year = new Date().getFullYear();

function embedMediaLink(value: string | null): string | null {
  if (!value) return null;
  try {
    const u = new URL(value);
    if (u.protocol !== "https:") return null;
    const host = u.hostname.toLowerCase();
    let id = "";
    if (host === "youtu.be") id = u.pathname.slice(1);
    if (["youtube.com", "www.youtube.com", "m.youtube.com"].includes(host)) {
      id = u.pathname === "/watch" ? u.searchParams.get("v") || "" : u.pathname.startsWith("/shorts/") ? u.pathname.split("/")[2] : u.pathname.startsWith("/live/") ? u.pathname.split("/")[2] : "";
    }
    if (/^[a-zA-Z0-9_-]{11}$/.test(id)) return `https://www.youtube-nocookie.com/embed/${id}`;
    if (host === "vimeo.com" || host === "www.vimeo.com") {
      id = u.pathname.slice(1).split("/")[0];
      if (/^\d{6,12}$/.test(id)) return `https://player.vimeo.com/video/${id}`;
    }
    return null;
  } catch { return null; }
}

function SermonMedia({ sermon, sw, onClose, churchSite }: { sermon: Sermon; sw: boolean; onClose: () => void; churchSite: PublicChurchSite | null }) {
  const src = churchSite ? `/api/sites/public/sermons/${encodeURIComponent(sermon.id)}/media?hostname=${encodeURIComponent(churchSite.hostname)}` : `/api/sermons/public/${encodeURIComponent(TENANT_SLUG)}/${encodeURIComponent(sermon.id)}/media`;
  const embed = sermon.media_source === "external" ? embedMediaLink(sermon.external_url) : null;
  return <ModalDialog className="sermon-dialog-backdrop" label={sermon.title} onClose={onClose}>
    <section className="sermon-dialog">
      <div className="sermon-dialog-head"><div><small>{sw ? "MAHUBIRI" : "SERMON LIBRARY"}</small><h3>{sermon.title}</h3><p>{sermon.speaker}</p></div><button onClick={onClose} aria-label={sw ? "Funga" : "Close"}>✕</button></div>
      {embed ? <iframe className="sermon-embed" src={embed} title={sermon.title} allow="encrypted-media; picture-in-picture; fullscreen" allowFullScreen referrerPolicy="strict-origin-when-cross-origin"/> : sermon.media_source === "external" ? <a className="sermon-external" href={sermon.external_url || "#"} target="_blank" rel="noopener noreferrer">{sw ? "Fungua mahubiri" : "Open sermon"} ↗</a> : sermon.media_kind === "audio" ? <audio src={src} controls preload="metadata"/> : <video src={src} controls playsInline preload="metadata"/>}
      {sermon.summary && <p className="sermon-dialog-summary">{sermon.summary}</p>}
    </section>
  </ModalDialog>;
}

export function PublicHome({ branding, churchSite, locale, onLocaleChange, onLogin, onRegister }: Props) {
  const sw = locale === "sw";
  const [bibleOpened, setBibleOpened] = useState(false);
  const [readerOpen, setReaderOpen] = useState(false);
  const [sermons, setSermons] = useState<Sermon[]>([]);
  const [notices, setNotices] = useState<PublicNotice[]>([]);
  const [sermonsState, setSermonsState] = useState<"loading"|"ready"|"offline">("loading");
  const [media, setMedia] = useState<Sermon|null>(null);
  const [sermonFilter, setSermonFilter] = useState<"all" | "audio" | "video">("all");
  const [mobileNav, setMobileNav] = useState(false);
  const theme = churchSite?.theme || (branding.slug === "stmarks" ? "terracotta" : "forest");
  useEffect(() => {
    let active = true;
    api<Sermon[]>(churchSite ? `/sites/public/sermons?hostname=${encodeURIComponent(churchSite.hostname)}` : "/sermons/public")
      .then(items => { if(active){ setSermons(items); setSermonsState("ready"); } })
      .catch(() => {if(active)setSermonsState("offline");});
    return ()=>{active=false;};
  }, [branding.slug, churchSite?.id]);
  useEffect(() => {
    if (!churchSite) { setNotices([]); return; }
    let active = true;
    api<PublicNotice[]>(`/sites/public/notices?hostname=${encodeURIComponent(churchSite.hostname)}`)
      .then((items) => { if (active) setNotices(items); })
      .catch(() => { if (active) setNotices([]); });
    return () => { active = false; };
  }, [churchSite?.id]);
  const filtered = sermons.filter(s => sermonFilter === "all" || s.media_kind === sermonFilter);
  const featured = sermons.find(s=>s.is_featured) ?? sermons[0];

  function selectSermon(item: Sermon) {
    setMedia(item);
  }
  function openBook() { if(!bibleOpened) {setBibleOpened(true);window.setTimeout(()=>setReaderOpen(true),850);} else setReaderOpen(true); }

  return <div className={`church-public public-theme-${theme}`}>
    <a className="public-skip" href="#church-main">{sw ? "Ruka hadi maudhui" : "Skip to content"}</a>
    <div className="public-topline"><span>✣ {sw ? "KARIBU NYUMBANI" : "A PLACE TO BELONG"}</span><span>{sw ? "Imani • Upendo • Ushirika" : "Faith • Hope • Community"}</span></div>
    <header className="public-nav">
      <a className="public-brand" href="#home" aria-label={branding.display_name}>
        <span className="public-brand-symbol" aria-hidden="true">✳</span>
        <span className="public-brand-wordmark"><strong>{branding.display_name}</strong><small>{branding.tagline || (sw ? "Tunaunganishwa na imani" : "Together in faith")}</small></span>
      </a>
      <nav className={mobileNav ? "nav-open" : ""} aria-label={sw ? "Menyu kuu" : "Main navigation"}>
        <a href="#home" onClick={()=>setMobileNav(false)}>{sw ? "Nyumbani" : "Home"}</a>
        <a href="#welcome" onClick={()=>setMobileNav(false)}>{sw ? "Kuhusu sisi" : "Our community"}</a>
        {notices.length > 0 && <a href="#notices" onClick={()=>setMobileNav(false)}>{sw ? "Matangazo" : "Updates"}</a>}
        <a href="#sermons" onClick={()=>setMobileNav(false)}>{sw ? "Mahubiri" : "Sermons"}</a>
        <a href="#scripture" onClick={()=>setMobileNav(false)}>{sw ? "Biblia" : "Bible"}</a>
      </nav>
      <div className="public-actions"><LanguageToggle value={locale} onChange={onLocaleChange}/><button className="public-login" type="button" onClick={onLogin}>{sw ? "Ingia" : "Sign in"}<span aria-hidden="true">↗</span></button><button className="public-menu" type="button" aria-expanded={mobileNav} aria-label={sw ? "Fungua menyu" : "Toggle menu"} onClick={()=>setMobileNav(!mobileNav)}>☰</button></div>
    </header>
    <main id="church-main">
      <section className="public-hero" id="home">
        <div className="hero-architect" aria-hidden="true"><div className="architect-arch arch-one"/><div className="architect-arch arch-two"/><div className="architect-arch arch-three"/><span>✳</span></div>
        <div className="public-hero-inner"><span className="hero-eyebrow"><i aria-hidden="true"/>{sw ? "KANISA LAKO. FAMILIA YAKO." : "YOUR CHURCH. YOUR COMMUNITY."}</span>
          <h1>{sw ? <>Karibu <em>nyumbani</em><br/>kwa imani.</> : <>Come as you are.<br/><em>Belong here.</em></>}</h1>
          <p>{sw ? (churchSite?.welcome_message || `Karibu ${branding.display_name}. Mahali pa kusikia Neno, kukua kiroho, na kushirikiana katika upendo.`) : (churchSite?.welcome_message || `Welcome to ${branding.display_name}. A home for worship, meaningful connections and a life shaped by faith.`)}</p>
          <div className="public-cta"><button className="public-primary-button" onClick={onRegister}>{sw ? "Jiunge na familia" : "Become a member"}<span>↗</span></button><a href="#sermons" className="hero-link">{sw ? "Sikiliza mahubiri" : "Listen to sermons"}<span>↓</span></a></div>
          <div className="hero-bottom-note"><span className="hero-divider"/><span>{sw ? "UJUMBE WA TUMAINI KWA KILA MMOJA" : "A MESSAGE OF HOPE FOR EVERYONE"}</span></div>
        </div>
        <div className="hero-art" aria-hidden="true"><div className="hero-art-orbit outer"/><div className="hero-art-orbit inner"/><div className="hero-art-cross">✝</div><div className="hero-art-caption"><span>FAITH</span><b>✦</b><span>FELLOWSHIP</span></div></div>
        <div className="hero-vertical-label" aria-hidden="true">FAITH · HOPE · COMMUNITY</div>
      </section>
      <section className="public-info-strip" id="welcome" aria-label={sw ? "Kuhusu kanisa" : "About our church"}>
        <div><span className="info-symbol">✳</span><div><small>01 / {sw ? "TUKUTANE" : "GATHER"}</small><strong>{sw ? "Tuabudu pamoja" : "Worship together"}</strong><p>{churchSite?.service_times || (sw ? "Kila mtu anakaribishwa." : "Everyone has a place here.")}</p></div></div>
        <div><span className="info-symbol">♡</span><div><small>02 / {sw ? "TUKUE" : "GROW"}</small><strong>{sw ? "Tujifunze pamoja" : "Grow in faith"}</strong><p>{churchSite?.location_label || (sw ? "Neno lituongoze kila siku." : "Rooted in the living Word.")}</p></div></div>
        <div><span className="info-symbol">✦</span><div><small>03 / {sw ? "TUTUMIKE" : "SERVE"}</small><strong>{sw ? "Tuhudumiane" : "Love in action"}</strong><p>{sw ? "Upendo kupitia matendo." : "Faith expressed in service."}</p></div></div>
      </section>
      {notices.length > 0 && <section className="public-notices" id="notices" aria-labelledby="notices-heading">
        <div className="public-notices-heading"><span className="public-eyebrow-dark">✣ {sw ? "KUTOKA KANISANI" : "FROM OUR CHURCH"}</span><h2 id="notices-heading">{sw ? "Matangazo ya kanisa" : "Church updates"}</h2><p>{sw ? "Taarifa zilizochapishwa kwa ajili ya jamii yetu." : "Public updates shared with our community."}</p></div>
        <div className="public-notices-list">{notices.map((notice) => <article key={notice.id} className="public-notice">
          <div className="public-notice-meta"><span>{notice.urgency === "urgent" ? (sw ? "MUHIMU SANA" : "URGENT") : (sw ? "TANGAZO" : "UPDATE")}</span><time dateTime={notice.created_at}>{new Date(notice.created_at).toLocaleDateString(sw ? "sw-TZ" : "en-GB", { day: "numeric", month: "short", year: "numeric" })}</time></div>
          <h3>{notice.title}</h3><p>{notice.body}</p>
        </article>)}</div>
      </section>}
      <section id="sermons" className="public-sermons">
        <div className="public-section-heading"><div><span className="public-eyebrow-dark">● {sw ? "SAUTI YA NENO" : "THE SOUND OF THE WORD"}</span><h2>{sw ? <>Neno la <em>maisha.</em></> : <>Words that <em>move us.</em></>}</h2><p>{sw ? "Mahubiri, mafundisho na ujumbe wa kiroho kutoka kanisa lako." : "Listen again. Find encouragement in every sermon and teaching."}</p></div><span className="section-side-label">SERMON ARCHIVE / {year}</span></div>
        {featured && <div className="featured-sermon"><div className="featured-art"><span className="featured-art-sun">✷</span><div className="featured-wave" aria-hidden="true">▂▅▃▇▅▃▆▂▆▇▃▅▂▇▅▂▃▆▇▂▅</div><small>FROM OUR CHURCH · {featured.language.toUpperCase()}</small></div><div className="featured-content"><span className="featured-label">✣ {sw ? "MAHUBIRI MAALUM" : "FEATURED MESSAGE"}</span><h3>{featured.title}</h3><p>{featured.summary || (sw ? "Sikiliza ujumbe huu kutoka kanisa letu." : "A message from our church community.")}</p><span className="featured-speaker">{featured.speaker || branding.display_name}</span><button onClick={()=>selectSermon(featured)}>{featured.media_kind === "audio" ? "♫" : "▶"} {sw ? "Sikiliza sasa" : "Play message"} <span>↗</span></button></div></div>}
        <div className="sermon-filterbar"><h3>{sw ? "Maktaba ya mahubiri" : "Explore our messages"}</h3><div className="sermon-filters" aria-label={sw ? "Chuja mahubiri" : "Filter sermons"}>{(["all","video","audio"] as const).map(kind=><button key={kind} onClick={()=>setSermonFilter(kind)} aria-pressed={sermonFilter === kind} className={sermonFilter===kind?"selected":""}>{kind==="all"?(sw?"Yote":"All"):kind==="video"?"Video":"Audio"}</button>)}</div></div>
        {sermonsState === "loading" && <div className="sermon-empty" role="status">{sw ? "Inatafuta mahubiri..." : "Loading sermons..."}</div>}
        {sermonsState === "offline" && <div className="sermon-empty" role="status"><strong>{sw ? "Mahubiri hayapatikani kwa sasa" : "Sermons temporarily unavailable"}</strong><p>{sw ? "Angalia muunganisho na ujaribu tena." : "Please check your connection and try again."}</p></div>}
        {sermonsState === "ready" && filtered.length === 0 && <div className="sermon-empty"><span className="sermon-empty-mark" aria-hidden="true">♫</span><div><strong>{sw ? "Mahubiri yataonekana hapa yakichapishwa" : "Published sermons will appear here"}</strong><p>{sw ? "Kanisa lako bado halijachapisha mahubiri katika kundi hili." : "Your church has not published any sermons in this category yet."}</p></div></div>}
        {filtered.length > 0 && <div className="sermon-grid">{filtered.slice(0,9).map((s,i)=><button className="sermon-tile" key={s.id} onClick={()=>selectSermon(s)}><span className="sermon-tile-art"><b>{String(i+1).padStart(2,"0")}</b><span>{s.media_kind === "audio" ? "♫" : "▶"}</span></span><span className="sermon-tile-info"><small>{s.media_kind.toUpperCase()} · {s.language.toUpperCase()}</small><strong>{s.title}</strong><span>{s.speaker || branding.display_name} <b aria-hidden="true">↗</b></span></span></button>)}</div>}
      </section>
      <section id="scripture" className="public-scripture"><div className="scripture-intro"><span className="scripture-number">03 / THE LIVING WORD</span><span className="scripture-heading-mark">✝</span><h2>{sw ? <>Fungua <em>Neno.</em><br/>Pata nuru.</> : <>Open the <em>Word.</em><br/>Find your light.</>}</h2><p>{sw ? "Biblia halisi, si maandishi ya kubuni. Fungua, soma sura na utafute mistari." : "A real, read-only Bible. Open it, explore chapters, and read scripture in its original wording."}</p><button className="scripture-read" onClick={openBook}>{sw ? "Fungua Biblia" : "Open the Bible"}<span>↗</span></button><span className="scripture-translation">WORLD ENGLISH BIBLE · PUBLIC DOMAIN</span></div>
        <div className="scripture-art"><div className="scripture-ornament" aria-hidden="true">✤</div><button className={`bible-book ${bibleOpened ? "is-open" : ""}`} type="button" onClick={openBook} aria-label={sw?"Fungua Biblia na usome":"Open Bible reader"}><span className="bible-book-back"/><span className="bible-pages"><span>JOHN 3:16</span><i>For God so loved the world,<br/>that he gave his one and<br/>only Son...</i><small>WORLD ENGLISH BIBLE</small></span><span className="bible-book-cover"><span>✝</span><strong>HOLY<br/>BIBLE</strong><small>THE WORD OF GOD</small></span></button><span className="scripture-art-hint">↖ {sw ? "Bonyeza kufungua" : "Click to read"}</span></div></section>
      <section className="public-belong"><div><span>✣ {sw ? "WEWE NI WA MUHIMU" : "THERE IS ROOM FOR YOU"}</span><h2>{sw ? "Hadithi yako ina nafasi hapa." : "Your story belongs here."}</h2><p>{sw ? "Tuanze safari hii pamoja. Jiunge na jumuiya ya kanisa lako." : "Faith grows stronger together. Find your place in our community."}</p></div><button onClick={onRegister}>{sw ? "Jiunge nasi" : "Join our community"}<b>↗</b></button></section>
    </main>
    <footer className="public-footer"><div className="public-footer-brand"><span>✳</span><div><strong>{branding.display_name}</strong><small>{branding.tagline || "Faith. Community. Service."}</small></div></div><div className="public-footer-links"><a href="#home">{sw?"Nyumbani":"Home"}</a><a href="#sermons">{sw?"Mahubiri":"Sermons"}</a><a href="#scripture">{sw?"Biblia":"Bible"}</a><button onClick={onLogin}>{sw?"Ingia":"Sign in"}</button></div><p>© {year} {branding.display_name}. {sw?"Haki zote zimehifadhiwa.":"All rights reserved."}</p></footer>
    {readerOpen && <BibleReader sw={sw} onClose={()=>setReaderOpen(false)} />}
    {media && <SermonMedia sermon={media} sw={sw} churchSite={churchSite} onClose={()=>setMedia(null)} />}
  </div>;
}
