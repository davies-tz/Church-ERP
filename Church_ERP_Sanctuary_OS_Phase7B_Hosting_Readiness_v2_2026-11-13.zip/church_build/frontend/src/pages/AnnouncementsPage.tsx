import { FormEvent, useEffect, useState } from "react";
import { api } from "../lib/api";
import { Announcement, OrgUnit, T } from "../lib/types";

interface Props {
  t: T;
  caps: Set<string>;
}

const URGENCIES = ["low", "normal", "high", "urgent"];

function urgencyLabel(t: T, u: string) {
  return t(`urgency${u.charAt(0).toUpperCase()}${u.slice(1)}`);
}

export function AnnouncementsPage({ t, caps }: Props) {
  const [items, setItems] = useState<Announcement[]>([]);
  const [units, setUnits] = useState<OrgUnit[]>([]);
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [urgency, setUrgency] = useState("normal");
  const [scope, setScope] = useState("");
  const [isPublic, setIsPublic] = useState(false);
  const [shareDescendants, setShareDescendants] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    setItems(await api<Announcement[]>("/announcements"));
  }

  useEffect(() => {
    refresh().catch(() => {});
    if (caps.has("manage_structure")) {
      api<OrgUnit[]>("/structure/units").then(setUnits).catch(() => {});
    }
  }, [caps]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    setError(null);
    try {
      await api<Announcement>("/announcements", {
        method: "POST",
        body: JSON.stringify({
          title,
          body: body,
          urgency,
          org_unit_id: scope || null,
          is_public: isPublic,
          show_on_descendant_sites: isPublic && !!scope && shareDescendants,
        }),
      });
      setOpen(false);
      setTitle("");
      setBody("");
      setUrgency("normal");
      setScope("");
      setIsPublic(false);
      setShareDescendants(false);
      await refresh();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="stack">
      {caps.has("manage_structure") && (
        <section className="panel">
          <h2>{t("publishAnnouncement")}</h2>
          {error && <div className="error" role="alert">{error}</div>}
          {!open && (
            <button className="btn-approve btn-small" onClick={() => setOpen(true)}>
              {t("publishAnnouncement")}
            </button>
          )}
          {open && (
            <form onSubmit={submit} className="stack verify-form">
              <label htmlFor="announcement-title">{t("announcementTitle")}</label>
              <input id="announcement-title" maxLength={200} value={title} onChange={(e) => setTitle(e.target.value)} required />
              <label htmlFor="announcement-body">{t("announcementBody")}</label>
              <textarea id="announcement-body" rows={4} maxLength={10000} value={body} onChange={(e) => setBody(e.target.value)} required />
              <label htmlFor="announcement-urgency">{t("urgency")}</label>
              <select id="announcement-urgency" value={urgency} onChange={(e) => setUrgency(e.target.value)}>
                {URGENCIES.map((u) => (
                  <option key={u} value={u}>
                    {urgencyLabel(t, u)}
                  </option>
                ))}
              </select>
              <label htmlFor="announcement-scope">{t("publishScope")}</label>
              <select id="announcement-scope" value={scope} onChange={(e) => { setScope(e.target.value); setIsPublic(false); setShareDescendants(false); }}>
                <option value="">{t("entireInstitution")}</option>
                {units.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name}
                  </option>
                ))}
              </select>
              {!scope && <p className="muted small" role="status">{t("selectChurchForPublicNotice")}</p>}
              {!!scope && <label className="public-notice-consent" style={{display: "flex", alignItems: "flex-start", gap: 12}}>
                <input type="checkbox" checked={isPublic} onChange={(e) => { setIsPublic(e.target.checked); if (!e.target.checked) setShareDescendants(false); }} style={{width: 20, height: 20, flexShrink: 0}} />
                <span>{t("showOnPublicWebsite")}<small style={{display:"block", lineHeight:1.6, marginTop: 4}}>{t("showOnPublicWebsiteHelp")}</small></span>
              </label>}
              {isPublic && !!scope && <label className="public-notice-consent" style={{display:"flex", alignItems:"flex-start", gap:12}}>
                <input type="checkbox" checked={shareDescendants} onChange={(e)=>setShareDescendants(e.target.checked)} style={{width:20,height:20,flexShrink:0}} />
                <span>{t("shareDescendantSites")}<small style={{display:"block",lineHeight:1.6,marginTop:4}}>{t("shareDescendantSitesHelp")}</small></span>
              </label>}
              <div className="req-actions">
                <button type="submit" className="btn-approve" disabled={submitting} aria-busy={submitting}>
                  {t("publish")}
                </button>
                <button type="button" className="btn-muted" onClick={() => { setOpen(false); setIsPublic(false); setShareDescendants(false); setError(null); }} disabled={submitting}>
                  {t("cancel")}
                </button>
              </div>
            </form>
          )}
        </section>
      )}

      <section className="panel">
        <h2>{t("announcements")} ({items.length})</h2>
        {items.length === 0 && <p className="muted">{t("noAnnouncements")}</p>}
        {items.map((a) => (
          <div className="req-item" key={a.id}>
            <div className="req-head">
              <strong>{a.title}</strong>
              <span className={`status urgency-${a.urgency}`}>{urgencyLabel(t, a.urgency)}</span>
            </div>
            <p className="muted small">{a.body}</p>
            <div className="muted small">
              {a.org_unit_name ?? t("entireInstitution")}
              {a.is_public ? ` · ${t("visibleOnPublicWebsite")}` : ""}
              {a.show_on_descendant_sites ? ` · ${t("sharedWithDescendants")}` : ""}
              {a.published_by_name ? ` · ${a.published_by_name}` : ""}
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}
