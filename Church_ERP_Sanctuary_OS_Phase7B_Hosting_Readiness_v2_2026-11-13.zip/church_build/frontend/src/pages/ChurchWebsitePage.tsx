import { useEffect, useState, type FormEvent } from "react";
import { api } from "../lib/api";
import type { ManagedChurchSite, ChurchSiteDomain } from "../lib/churchSites";
import "./ChurchWebsitePage.css";

type Unit = { id: string; name: string; level_key: string };
type Fields = Pick<ManagedChurchSite, "display_name" | "tagline" | "welcome_message" | "service_times" | "location_label" | "contact_email" | "theme" | "is_published">;
const EMPTY: Fields = {
  display_name: "", tagline: "", welcome_message: "", service_times: "",
  location_label: "", contact_email: null, theme: "forest", is_published: true,
};

export function ChurchWebsitePage({ locale }: { locale: string }) {
  const sw = locale === "sw";
  const [sites, setSites] = useState<ManagedChurchSite[]>([]);
  const [units, setUnits] = useState<Unit[]>([]);
  const [selected, setSelected] = useState<string>("");
  const [unitId, setUnitId] = useState("");
  const [form, setForm] = useState<Fields>({ ...EMPTY });
  const [domain, setDomain] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const current = sites.find((site) => site.id === selected);
  const refresh = async (id?: string) => {
    const items = await api<ManagedChurchSite[]>("/sites/manage");
    setSites(items);
    if (id) setSelected(id);
    else if (!selected && items.length) setSelected(items[0].id);
  };
  useEffect(() => {
    void refresh().catch((e) => setError(e.message));
    api<Unit[]>("/sites/manage/units").then(setUnits).catch((e) => setError(e.message));
  }, []);
  useEffect(() => {
    if (current) {
      setForm({ display_name: current.display_name, tagline: current.tagline,
        welcome_message: current.welcome_message, service_times: current.service_times,
        location_label: current.location_label, contact_email: current.contact_email,
        theme: current.theme, is_published: current.is_published });
    } else setForm({ ...EMPTY });
  }, [selected, sites]);

  function change<K extends keyof Fields>(key: K, value: Fields[K]) {
    setForm((old) => ({ ...old, [key]: value }));
  }
  async function save(e: FormEvent) {
    e.preventDefault(); if (saving) return;
    setSaving(true); setError(""); setSuccess("");
    try {
      const body = { ...form, contact_email: form.contact_email || null };
      const created = current
        ? await api<ManagedChurchSite>(`/sites/manage/${current.id}`, { method: "PUT", body: JSON.stringify(body) })
        : await api<ManagedChurchSite>("/sites/manage", { method: "POST", body: JSON.stringify({ ...body, org_unit_id: unitId }) });
      await refresh(created.id);
      setSuccess(sw ? "Taarifa za tovuti zimehifadhiwa." : "Church website settings saved.");
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setSaving(false); }
  }
  async function addDomain(e: FormEvent) {
    e.preventDefault(); if (!current || saving) return;
    setError(""); setSuccess(""); setSaving(true);
    try {
      await api(`/sites/manage/${current.id}/domains`, { method: "POST", body: JSON.stringify({ hostname: domain }) });
      setDomain(""); await refresh(current.id);
      setSuccess(sw ? "Domain imeongezwa. Weka DNS TXT kisha uthibitishe." : "Domain registered. Add its DNS TXT record before verification.");
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setSaving(false); }
  }
  async function verify(d: ChurchSiteDomain) {
    setError(""); setSuccess(""); setSaving(true);
    try {
      await api(`/sites/manage/domains/${d.id}/verify`, { method: "POST" });
      await refresh(selected); setSuccess(sw ? "Umiliki wa domain umethibitishwa." : "Domain ownership verified.");
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setSaving(false); }
  }
  async function remove(d: ChurchSiteDomain) {
    if (!window.confirm(sw ? "Ondoa domain hii?" : "Remove this domain?")) return;
    setError(""); setSuccess(""); setSaving(true);
    try { await api(`/sites/manage/domains/${d.id}`, { method: "DELETE" }); await refresh(selected); }
    catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setSaving(false); }
  }
  function preview(host: string) {
    const local = host.endsWith(".localhost");
    const target = local ? `${window.location.origin}/?site=${encodeURIComponent(host)}` : `https://${host}/`;
    window.open(target, "_blank", "noopener,noreferrer");
  }

  return <div className="site-editor">
    <div className="site-editor-header">
      <span className="site-editor-kicker">SANCTUARY / WEB STUDIO</span>
      <h1>{sw ? "Tovuti ya kanisa lako" : "Your church website"}</h1>
      <p>{sw ? "Unda tovuti ya kanisa hili tu. Taarifa zako hazitawekwa kwenye orodha ya makanisa yote." : "Create a standalone church homepage. Visitors see this church only, never a public tenant directory."}</p>
    </div>
    {error && <div className="site-editor-alert bad" role="alert">{error}</div>}
    {success && <div className="site-editor-alert good" role="status">{success}</div>}
    <div className="site-editor-grid">
      <div className="site-editor-menu">
        <h2>{sw ? "Tovuti zako" : "Your websites"}</h2>
        {sites.map(site => <button disabled={saving} aria-pressed={selected === site.id} className={selected === site.id ? "current" : ""} key={site.id} onClick={() => setSelected(site.id)}>{site.display_name}<small>{site.is_published ? (sw ? "Imechapishwa" : "Published") : (sw ? "Haijaonyeshwa" : "Unpublished")}</small></button>)}
        <button disabled={saving} className={!selected ? "current new" : "new"} onClick={() => { setSelected(""); setForm({ ...EMPTY }); }}>{sw ? "+ Ongeza tovuti" : "+ New church website"}</button>
      </div>
      <div className="site-editor-content">
        <form className="site-editor-form" onSubmit={save}>
          <div className="site-editor-heading"><h2>{current ? (sw ? "Badili taarifa" : "Edit website") : (sw ? "Tengeneza tovuti" : "Create website")}</h2><span>{current ? current.org_unit_id.slice(0,8) : "NEW SITE"}</span></div>
          {!current && <label>{sw ? "Kanisa / Parish" : "Church / Parish"}<select required value={unitId} onChange={e => setUnitId(e.target.value)}><option value="">{sw ? "Chagua" : "Choose a church"}</option>{units.map(u => <option key={u.id} value={u.id}>{u.name} ({u.level_key})</option>)}</select></label>}
          <label>{sw ? "Jina litakaloonekana" : "Public church name"}<input required maxLength={200} minLength={2} value={form.display_name} onChange={e => change("display_name",e.target.value)} /></label>
          <label>{sw ? "Kauli mbiu" : "Tagline"}<input maxLength={300} value={form.tagline} onChange={e => change("tagline",e.target.value)} /></label>
          <label className="site-editor-wide">{sw ? "Ujumbe wa ukaribisho" : "Welcome message"}<textarea rows={3} maxLength={1500} value={form.welcome_message} onChange={e => change("welcome_message",e.target.value)} /></label>
          <label>{sw ? "Muda wa ibada" : "Service times"}<input maxLength={300} placeholder={sw ? "Jumapili saa 3:00 asubuhi" : "Sunday 9:00 AM"} value={form.service_times} onChange={e => change("service_times",e.target.value)} /></label>
          <label>{sw ? "Mahali" : "Location"}<input maxLength={300} value={form.location_label} onChange={e => change("location_label",e.target.value)} /></label>
          <label>{sw ? "Barua pepe ya kanisa" : "Public contact email"}<input type="email" maxLength={250} value={form.contact_email ?? ""} onChange={e => change("contact_email",e.target.value)} /></label>
          <label>{sw ? "Muonekano" : "Visual theme"}<select value={form.theme} onChange={e => change("theme", e.target.value as Fields["theme"])}><option value="forest">Forest / Cream</option><option value="terracotta">Terracotta / Warm paper</option></select></label>
          <label className="site-editor-check"><input type="checkbox" checked={form.is_published} onChange={e => change("is_published",e.target.checked)}/>{sw ? "Ruhusu wageni waone tovuti hii" : "Publish this church homepage"}</label>
          <div className="site-editor-wide"><button type="submit" disabled={saving}>{saving ? (sw ? "Inahifadhi..." : "Saving...") : (sw ? "Hifadhi tovuti" : "Save website")}</button></div>
        </form>
        {current && <section className="site-editor-domains">
          <h2>{sw ? "Anwani za tovuti" : "Church website domains"}</h2>
          <p>{sw ? "Thibitisha umiliki kwa DNS TXT. Domain lazima ielekezwe kwa hosting yenye HTTPS." : "Prove ownership with a DNS TXT record. Also configure HTTPS and DNS routing with your host."}</p>
          {current.domains.map(d => <div key={d.id} className="site-domain-row">
            <div className="site-domain-status"><strong>{d.hostname}</strong><span>{d.verified_at ? (sw ? "✓ Imethibitishwa" : "✓ Verified") : (sw ? "Inasubiri uthibitisho wa DNS" : "Pending DNS verification")}</span></div>
            {!d.verified_at && <div className="site-dns"><div><b>TXT</b> <code>{d.dns_record}</code></div><code>{d.dns_value}</code></div>}
            <div className="site-domain-actions">
              {d.verified_at && <button type="button" onClick={()=>preview(d.hostname)}>{sw ? "Fungua" : "Preview"} ↗</button>}
              {!d.verified_at && <button type="button" disabled={saving} onClick={()=>verify(d)}>{sw ? "Thibitisha DNS" : "Verify DNS"}</button>}
              <button type="button" className="danger" disabled={saving} onClick={()=>remove(d)}>{sw ? "Ondoa" : "Remove"}</button>
            </div>
          </div>)}
          <form className="site-domain-add" onSubmit={addDomain}><label>{sw ? "Ongeza domain nyingine" : "Add a domain"}<input type="text" required placeholder="parish.example.org" value={domain} onChange={e=>setDomain(e.target.value)} /></label><button type="submit" disabled={saving}>{sw ? "Ongeza domain" : "Add domain"}</button></form>
        </section>}
      </div>
    </div>
  </div>;
}
