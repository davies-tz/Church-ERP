import { useEffect, useRef, type ReactNode } from "react";

// Native modal dialogs keep keyboard focus inside, make the background inert,
// support Escape and restore focus to the opener when closed.
export function ModalDialog({ className, label, labelledBy, onClose, children }: {
  className: string;
  label?: string;
  labelledBy?: string;
  onClose: () => void;
  children: ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const close = useRef(onClose);
  close.current = onClose;

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    const overflow = document.body.style.overflow;
    dialog.showModal();
    document.body.style.overflow = "hidden";
    return () => {
      dialog.close();
      document.body.style.overflow = overflow;
    };
  }, []);

  return <dialog ref={ref} className={className} aria-label={label} aria-labelledby={labelledBy}
    onCancel={event => { event.preventDefault(); close.current(); }}
    onMouseDown={event => { if (event.target === event.currentTarget) close.current(); }}>
    {children}
  </dialog>;
}
