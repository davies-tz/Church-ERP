"""Hosted routing and startup checks. Uses temporary assets, never real church data."""
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, Mock

from httpx import ASGITransport, AsyncClient
import pytest

from app.core.release_checks import verify_database_role
from app.production import create_app


async def test_single_origin_api_and_static_assets(tmp_path):
    (tmp_path / "index.html").write_text("<h1>Compiled church frontend</h1>")
    (tmp_path / "app.js").write_text("console.log('app')")
    app = create_app(tmp_path)
    async with AsyncClient(transport=ASGITransport(app=app), base_url="https://church.example.org") as client:
        index = await client.get("/")
        script = await client.get("/app.js")
        health = await client.get("/health")
        api = await client.get("/api/health")
        unknown_api = await client.get("/api/not-a-route")
        outside_root = await client.get("/%2e%2e/.env")
    assert index.status_code == script.status_code == 200
    assert "Compiled church frontend" in index.text
    assert health.json() == api.json() == {"status": "ok"}
    assert unknown_api.status_code == outside_root.status_code == 404


async def test_mount_preserves_real_host_for_public_site_binding(tmp_path, monkeypatch):
    from app.api.routes import church_sites
    calls = []

    async def lookup(hostname, request_host):
        calls.append((hostname, request_host))
        from fastapi import HTTPException
        raise HTTPException(404, "Unpublished test site")

    monkeypatch.setattr(church_sites, "_public_site", lookup)
    app = create_app(tmp_path)
    async with AsyncClient(transport=ASGITransport(app=app), base_url="https://north.example.org") as client:
        response = await client.get("/api/sites/public", params={"hostname": "south.example.org"})
    assert response.status_code == 404
    assert calls == [("south.example.org", "north.example.org")]


@pytest.mark.parametrize("superuser,bypass", [(True, False), (False, True), (True, True), (False, False)])
async def test_hosted_database_rejects_rls_bypass(superuser, bypass):
    row = SimpleNamespace(rolsuper=superuser, rolbypassrls=bypass)
    connection = AsyncMock()
    connection.execute.return_value = Mock(one=Mock(return_value=row))
    engine = MagicMock()
    engine.connect.return_value.__aenter__ = AsyncMock(return_value=connection)
    engine.connect.return_value.__aexit__ = AsyncMock(return_value=False)
    if superuser or bypass:
        with pytest.raises(RuntimeError, match="NOBYPASSRLS"):
            await verify_database_role(engine)
    else:
        await verify_database_role(engine)
