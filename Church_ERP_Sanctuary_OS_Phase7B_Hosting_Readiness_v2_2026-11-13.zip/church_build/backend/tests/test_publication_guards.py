"""Domain regressions using mocks; PostgreSQL/RLS coverage is separate."""
from types import SimpleNamespace
from unittest.mock import AsyncMock
import uuid

import pytest

from app.domain.announcements import AnnouncementError, create_announcement


@pytest.mark.parametrize("payload", [
    {"is_public": True},
    {"show_on_descendant_sites": True},
    {"org_unit_id": "invalid"},
    {"org_unit_id": str(uuid.uuid4()), "show_on_descendant_sites": True},
])
async def test_invalid_publication_never_writes(payload):
    session = AsyncMock()
    with pytest.raises(AnnouncementError):
        await create_announcement(session, tenant_id=str(uuid.uuid4()),
                                  published_by=str(uuid.uuid4()), title="Notice", body="Text", **payload)
    session.add.assert_not_called()
    session.flush.assert_not_awaited()


async def test_foreign_tenant_unit_rejected_even_if_session_returns_it():
    session = AsyncMock()
    session.get.return_value = SimpleNamespace(id=uuid.uuid4(), tenant_id=uuid.uuid4())
    with pytest.raises(AnnouncementError, match="Org unit not found"):
        await create_announcement(session, tenant_id=str(uuid.uuid4()),
                                  published_by=str(uuid.uuid4()), title="Notice", body="Text",
                                  org_unit_id=str(session.get.return_value.id), is_public=True)
    session.add.assert_not_called()
    session.flush.assert_not_awaited()
