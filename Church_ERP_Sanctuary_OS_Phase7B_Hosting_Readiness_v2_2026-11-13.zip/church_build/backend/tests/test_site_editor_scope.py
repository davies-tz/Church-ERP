"""Private site editor choices must respect both tenant and church scope."""
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock
import uuid

import pytest
from fastapi import HTTPException
from sqlalchemy.dialects.postgresql import dialect

from app.api.routes.church_sites import manageable_site_units
from app.domain import authz


async def test_editor_unit_choices_exclude_siblings(monkeypatch):
    tenant, own, sibling = (uuid.uuid4() for _ in range(3))
    own_unit = SimpleNamespace(id=own, name="My church", level_key="parish", path=f"/{own}/")
    other_unit = SimpleNamespace(id=sibling, name="Other church", level_key="parish", path=f"/{sibling}/")
    session = AsyncMock()
    session.execute.return_value = Mock(scalars=Mock(return_value=Mock(all=Mock(return_value=[own_unit, other_unit]))))
    monkeypatch.setattr(authz, "load_grants", AsyncMock(return_value=[
        authz.Grant("admin", own_unit.path, frozenset({authz.MANAGE_STRUCTURE}))]))
    choices = await manageable_site_units((session, SimpleNamespace(id=uuid.uuid4(), tenant_id=tenant)))
    assert choices == [{"id": str(own), "name": "My church", "level_key": "parish"}]
    query = session.execute.await_args.args[0].compile(dialect=dialect())
    assert "org_units.tenant_id =" in str(query)
    assert tenant in query.params.values()


async def test_member_cannot_read_site_editor_unit_choices(monkeypatch):
    session = AsyncMock()
    monkeypatch.setattr(authz, "load_grants", AsyncMock(return_value=[]))
    with pytest.raises(HTTPException) as error:
        await manageable_site_units((session, SimpleNamespace(id=uuid.uuid4(), tenant_id=uuid.uuid4())))
    assert error.value.status_code == 403
    session.execute.assert_not_awaited()
