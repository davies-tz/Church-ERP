"""Fail closed when a hosted deployment would bypass tenant isolation."""


def validate_release_secrets(settings) -> None:
    if settings.ENABLE_DEMO_SITE_PREVIEWS:
        raise RuntimeError("Hosted deployments must disable demo site previews")
    for name, demo in (("JWT_SECRET", "change-me-in-production-please"),
                       ("PLATFORM_ADMIN_TOKEN", "dev-platform-token")):
        value = getattr(settings, name)
        if value == demo or len(value) < 32:
            raise RuntimeError(f"Set a unique {name} with at least 32 characters")
    if not settings.MINIO_SECURE:
        raise RuntimeError("Hosted object storage must use TLS")


async def verify_database_role(engine) -> None:
    from sqlalchemy import text

    async with engine.connect() as connection:
        row = (await connection.execute(text(
            "SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user"
        ))).one()
        if row.rolsuper or row.rolbypassrls:
            raise RuntimeError("Application database role must be NOSUPERUSER and NOBYPASSRLS")
