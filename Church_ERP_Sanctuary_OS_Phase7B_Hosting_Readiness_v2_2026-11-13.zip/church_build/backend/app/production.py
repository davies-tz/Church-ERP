"""Single-origin hosted frontend + API, separate from the local Docker entrypoint."""
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from starlette.staticfiles import StaticFiles

from app.core.config import settings
from app.core.db import engine
from app.core.release_checks import validate_release_secrets, verify_database_role
from app.main import app as api_app


@asynccontextmanager
async def lifespan(_app):
    validate_release_secrets(settings)
    await verify_database_role(engine)
    yield
    await engine.dispose()


def create_app(frontend_dist: str | Path | None = None) -> FastAPI:
    # StaticFiles only exposes the compiled frontend. Source and secrets stay out
    # of its document root. Mounting /api preserves the actual incoming Host.
    directory = Path(frontend_dist or settings.FRONTEND_DIST)
    hosted = FastAPI(docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)

    @hosted.get("/health")
    async def health():
        return {"status": "ok"}

    hosted.mount("/api", api_app)
    hosted.mount("/", StaticFiles(directory=directory, html=True), name="frontend")
    return hosted
