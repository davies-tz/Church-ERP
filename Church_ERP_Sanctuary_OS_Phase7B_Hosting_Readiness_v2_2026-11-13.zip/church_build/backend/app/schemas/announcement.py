import datetime
import uuid

from pydantic import BaseModel, Field, model_validator


class AnnouncementCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    body: str = Field(min_length=1, max_length=10_000)
    urgency: str = "normal"
    org_unit_id: str | None = Field(default=None, pattern=r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
    is_public: bool = False  # must be deliberately opted into public display
    show_on_descendant_sites: bool = False  # separate explicit consent for child sites

    @model_validator(mode="after")
    def validate_public_sharing(self):
        if self.show_on_descendant_sites and (not self.is_public or not self.org_unit_id):
            raise ValueError("Sharing to descendant websites needs a public, scoped announcement")
        return self


class AnnouncementResponse(BaseModel):
    id: str
    title: str = Field(min_length=1, max_length=200)
    body: str = Field(min_length=1, max_length=10_000)
    urgency: str
    org_unit_id: str | None
    org_unit_name: str | None
    published_by_name: str | None
    created_at: datetime.datetime
    is_public: bool
    show_on_descendant_sites: bool


class PublicBulletin(BaseModel):
    """No private publisher, member, internal org identifiers or contact details."""
    id: uuid.UUID
    title: str = Field(min_length=1, max_length=200)
    body: str = Field(min_length=1, max_length=10_000)
    urgency: str
    created_at: datetime.datetime


class LatestAnnouncement(BaseModel):
    announcement: AnnouncementResponse | None
