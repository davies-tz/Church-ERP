"""Scoped sermon publishing and publicly playable media for each church tenant."""
import uuid
from datetime import datetime, timezone
from urllib.parse import urlparse

from fastapi import APIRouter, Depends, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import Response
from sqlalchemy import select

from app.api.deps import get_scoped_session, get_tenant
from app.core.db import SessionLocal, set_tenant
from app.core.storage import get as get_object, key_belongs_to, make_key, put
from app.domain import authz
from app.models import OrgUnit, Sermon, Tenant
from app.schemas.sermon import SermonExternalCreate, SermonResponse, SermonStatusUpdate

router = APIRouter(prefix="/sermons", tags=["sermons"])
MAX_MEDIA_BYTES = 25 * 1024 * 1024  # small demo uploads; production needs streaming/transcoding
_ALLOWED_SITES = {"youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "vimeo.com", "www.vimeo.com", "soundcloud.com", "www.soundcloud.com"}
_VALID_MIME = {"audio/mpeg": "audio", "audio/wav": "audio", "audio/x-wav": "audio", "audio/ogg": "audio", "video/mp4": "video", "video/webm": "video"}


def validate_media_data(data: bytes, mime: str) -> str:
    """Check magic signatures, not just the client-supplied content type."""
    kind = _VALID_MIME.get(mime)
    if not kind or not data or len(data) > MAX_MEDIA_BYTES:
        raise ValueError("Unsupported media file or size exceeds 25 MB")
    valid = {
        "audio/mpeg": data.startswith(b"ID3") or (data[0] == 0xff and len(data) > 1 and data[1] & 0xe0 == 0xe0),
        "audio/wav": data[:4] == b"RIFF" and data[8:12] == b"WAVE",
        "audio/x-wav": data[:4] == b"RIFF" and data[8:12] == b"WAVE",
        "audio/ogg": data.startswith(b"OggS"),
        "video/mp4": data[4:8] == b"ftyp",
        "video/webm": data.startswith(b"\x1a\x45\xdf\xa3"),
    }
    if not valid[mime]:
        raise ValueError("The file does not match its declared media type")
    return kind


def validate_media_url(value: str) -> str:
    url = urlparse(value)
    if url.scheme != "https" or url.username or url.password or (url.hostname or "").lower() not in _ALLOWED_SITES:
        raise ValueError("Use a public HTTPS YouTube, Vimeo or SoundCloud link")
    return value


def select_range(header: str | None, size: int) -> tuple[int, int, bool]:
    """Single-range support for mobile media playback; reject invalid byte requests."""
    if not header:
        return 0, size - 1, False
    if not header.startswith("bytes=") or "," in header or size == 0:
        raise ValueError("Unsupported byte range")
    left, sep, right = header[6:].partition("-")
    if not sep or (left and not left.isdigit()) or (right and not right.isdigit()):
        raise ValueError("Invalid byte range")
    if not left and not right:
        raise ValueError("Invalid byte range")
    if not left:
        length = int(right)
        if length == 0:
            raise ValueError("Invalid suffix range")
        return max(0, size - length), size - 1, True
    start = int(left)
    end = min(int(right), size - 1) if right else size - 1
    if start >= size or start > end:
        raise ValueError("Range outside media")
    return start, end, True


def _response(item: Sermon) -> SermonResponse:
    return SermonResponse(
        id=str(item.id), title=item.title, summary=item.summary, speaker=item.speaker,
        language=item.language, media_kind=item.media_kind, media_source=item.media_source,
        external_url=item.external_url, org_unit_id=str(item.org_unit_id) if item.org_unit_id else None,
        status=item.status, is_featured=item.is_featured, created_at=item.created_at,
        published_at=item.published_at,
    )


async def _check_scope(session, user, org_unit_id: str | None) -> None:
    path = "/"
    if org_unit_id:
        try:
            uid = uuid.UUID(org_unit_id)
        except ValueError:
            raise HTTPException(400, "Invalid church unit")
        unit = (await session.execute(select(OrgUnit).where(
            OrgUnit.id == uid, OrgUnit.tenant_id == user.tenant_id
        ))).scalar_one_or_none()
        if not unit:
            raise HTTPException(404, "Church unit not found")
        path = unit.path
    grants = await authz.load_grants(session, user.id)
    if not authz.can(grants, authz.MANAGE_MEDIA, path):
        raise HTTPException(403, "Not allowed to manage sermons at this church level")


@router.get("/public", response_model=list[SermonResponse])
async def published_sermons(tenant: Tenant = Depends(get_tenant)):
    """No authentication; the public homepage only receives its own tenant's published sermons."""
    async with SessionLocal() as session:
        async with session.begin():
            await set_tenant(session, str(tenant.id))
            result = await session.execute(
                select(Sermon).where(Sermon.status == "published", Sermon.tenant_id == tenant.id, Sermon.org_unit_id.is_(None))
                .order_by(Sermon.is_featured.desc(), Sermon.published_at.desc()).limit(24)
            )
            return [_response(s) for s in result.scalars()]


@router.get("/public/{tenant_slug}/{sermon_id}/media")
async def public_media(tenant_slug: str, sermon_id: uuid.UUID, range_header: str | None = Header(default=None, alias="Range")):
    """Public streaming uses explicit slug because HTML video cannot set X-Tenant-Slug."""
    async with SessionLocal() as session:
        tenant = (await session.execute(select(Tenant).where(Tenant.slug == tenant_slug, Tenant.status == "active"))).scalar_one_or_none()
        if not tenant:
            raise HTTPException(404, "Not found")
        await set_tenant(session, str(tenant.id))
        item = (await session.execute(
            select(Sermon).where(Sermon.id == sermon_id, Sermon.tenant_id == tenant.id, Sermon.org_unit_id.is_(None), Sermon.status == "published")
        )).scalar_one_or_none()
        if not item or not item.storage_key or not key_belongs_to(item.storage_key, str(tenant.id)):
            raise HTTPException(404, "Media not found")
        storage_key = item.storage_key
        mime = item.mime_type or "application/octet-stream"
    data, _stored_content_type = await get_object(storage_key)
    try:
        start, end, partial = select_range(range_header, len(data))
    except ValueError:
        return Response(status_code=416, headers={"Content-Range": f"bytes */{len(data)}", "Accept-Ranges": "bytes"})
    payload = data[start : end + 1]
    headers = {"Accept-Ranges": "bytes", "Content-Length": str(len(payload)),
               "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"}
    if partial:
        headers["Content-Range"] = f"bytes {start}-{end}/{len(data)}"
    return Response(content=payload, media_type=mime, status_code=206 if partial else 200, headers=headers)


@router.get("/manage", response_model=list[SermonResponse])
async def manage_sermons(ctx: tuple = Depends(get_scoped_session)):
    session, user = ctx
    grants = await authz.load_grants(session, user.id)
    if not authz.can(grants, authz.MANAGE_MEDIA):
        raise HTTPException(403, "Not allowed")
    rows = (await session.execute(select(Sermon).where(
        Sermon.tenant_id == user.tenant_id
    ).order_by(Sermon.created_at.desc()).limit(150))).scalars().all()
    units = {str(u.id): u.path for u in (await session.execute(select(OrgUnit).where(
        OrgUnit.tenant_id == user.tenant_id
    ))).scalars().all()}
    return [_response(s) for s in rows if authz.can(grants, authz.MANAGE_MEDIA, units.get(str(s.org_unit_id), "#") if s.org_unit_id else "/")]


@router.post("", response_model=SermonResponse, status_code=201)
async def create_link(body: SermonExternalCreate, ctx: tuple = Depends(get_scoped_session)):
    session, user = ctx
    await _check_scope(session, user, body.org_unit_id)
    if body.media_kind not in ("audio", "video"):
        raise HTTPException(400, "Choose audio or video")
    try:
        url = validate_media_url(str(body.external_url))
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    sermon = Sermon(tenant_id=user.tenant_id, org_unit_id=uuid.UUID(body.org_unit_id) if body.org_unit_id else None,
                    title=body.title.strip(), summary=body.summary.strip(), speaker=body.speaker.strip(),
                    language=body.language, media_kind=body.media_kind, media_source="external",
                    external_url=url, status="draft", created_by=user.id)
    session.add(sermon)
    await session.flush()
    return _response(sermon)


@router.post("/upload", response_model=SermonResponse, status_code=201)
async def upload_sermon(
    title: str = Form(...), speaker: str = Form(""), summary: str = Form(""),
    language: str = Form("sw"), org_unit_id: str | None = Form(None),
    media: UploadFile = File(...), ctx: tuple = Depends(get_scoped_session),
):
    session, user = ctx
    await _check_scope(session, user, org_unit_id)
    if not (3 <= len(title.strip()) <= 180) or len(speaker) > 120 or len(summary) > 2000:
        raise HTTPException(400, "Invalid sermon metadata")
    mime = (media.content_type or "").lower()
    data = await media.read(MAX_MEDIA_BYTES + 1)
    try:
        kind = validate_media_data(data, mime)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    key = make_key(str(user.tenant_id), "sermons", media.filename or "sermon")
    await put(key, data, mime)
    sermon = Sermon(tenant_id=user.tenant_id, org_unit_id=uuid.UUID(org_unit_id) if org_unit_id else None,
                    title=title.strip(), speaker=speaker.strip(), summary=summary.strip(),
                    language=language[:10], media_kind=kind, media_source="upload", mime_type=mime,
                    storage_key=key, status="draft", created_by=user.id)
    session.add(sermon)
    await session.flush()
    return _response(sermon)


@router.patch("/{sermon_id}/status", response_model=SermonResponse)
async def update_status(sermon_id: uuid.UUID, body: SermonStatusUpdate, ctx: tuple = Depends(get_scoped_session)):
    session, user = ctx
    if body.status not in ("draft", "published", "archived"):
        raise HTTPException(400, "Invalid sermon status")
    item = (await session.execute(select(Sermon).where(
        Sermon.id == sermon_id, Sermon.tenant_id == user.tenant_id
    ))).scalar_one_or_none()
    if not item:
        raise HTTPException(404, "Sermon not found")
    await _check_scope(session, user, str(item.org_unit_id) if item.org_unit_id else None)
    item.status = body.status
    item.is_featured = body.is_featured if body.status == "published" else False
    item.published_at = datetime.now(timezone.utc) if body.status == "published" and item.published_at is None else item.published_at
    await session.flush()
    return _response(item)
