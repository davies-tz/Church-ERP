# Earlier merged-source snapshot

These logs were produced for the first 13 November merged-source delivery,
whose ZIP SHA-256 was
`32affc4d7d00f837c3db0f3dac94cedc2744c3af3a9fc45b61f41c32c6e2b693`.

Later hosting and accessibility work is recorded in `../2026-11-13-hosting/`.
In particular, the earlier BibleReader/PublicHome byte-preservation check
describes that earlier snapshot. The current reader/homepage have modal
accessibility changes; the authentic WEB source and read-only text behavior
remain. Historical results are not new acceptance evidence for the current app.
