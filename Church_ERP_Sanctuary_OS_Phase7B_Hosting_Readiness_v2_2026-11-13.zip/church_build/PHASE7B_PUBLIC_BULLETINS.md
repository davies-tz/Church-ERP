# Phase 7B sprint — verified church-specific public bulletins

## Current continuation — free test hosting preparation (13 November 2026) 🔄

- Selected **Render Free + Neon Free**. See `deploy/FREE_HOSTING.md` and `render.yaml`.
- Added a single-origin hosted entrypoint and image. It serves only the compiled
  frontend, preserves Host on `/api`, validates secrets/TLS and rejects a database
  role that bypasses RLS. Hosted startup migrates but never seeds demo accounts.
- Added tenant/scoped editor unit choices, explicit tenant filters for sermon
  management, and no-store media responses so shared caches do not retain newly
  withdrawn sermons. Localized domain status labels and guarded editor submissions.
- Added native keyboard-modal focus handling for Bible/sermon dialogs; authentic
  WEB text retrieval/read-only behavior is unchanged. Localized text-size labels.
- Added built-React browser contract tests with explicit fixtures (not live E2E),
  plus hosted-routing, database-role and editor-scope tests for the backend suite;
  **these API-level tests have not executed here**.
- **Passed locally:** 8 hierarchy + 6 hosted-configuration tests, Python compilation,
  sermon function checks, 6 palette checks, and parsing 42 TS/TSX files with a
  locally cached Babel 7.29.12 parser. Parsing is not a TypeScript typecheck/build.
- **Cloud preparation verified:** a separate Neon Free PostgreSQL 16 project,
  application-role login with NOSUPERUSER/NOBYPASSRLS, and private object-storage
  bucket. No application migrations or application RLS integration ran there yet.
- GitHub connection can read the repository but **creating a branch was rejected
  with HTTP 403**. No new branch/commit/PR, source deployment, or CI run exists.
  Existing Render service was not modified. GitHub write authorization is needed.
- Still pending: actual PostgreSQL migration/RLS/API suites, locked frontend
  production build, domain ownership/HTTPS, browser E2E/accessibility/usability,
  backup/restore and security review. A free hosting URL does not bypass DNS proof.

Evidence for this continuation is in `evidence/2026-11-13-hosting/`. Earlier dated
results below are history. **7B stays 🔄; no later phase has started.**


## 13 November 2026 — Phase 7B continuation 🔄

This is the current delivery status; dated results below are historical.
Started from `Church_ERP_Sanctuary_OS_Phase7B_Privacy_Increment_2026-11-12.zip`.
Compared and merged `Church_ERP_Sanctuary_OS_Phase7B_Ancestor_Consent_Hardening_2026-11-09.zip`,
which contains safeguards missing from the later archive. The original 7 November
Public Bulletins baseline remains the lineage; this is a full incremental source delivery.

- Restored migration **0021**, separate descendant-site consent (false by default),
  tenant/parent/path ancestry proof, English/Kiswahili controls, site identity remount,
  PostgreSQL regressions, acceptance runbook and CI workflow from the 9 November source.
- Retained the 12 November strict UUID/path parser, API tenant filter, domain-layer
  tenant ownership check and rejection of public announcements without a church unit.
- New: reject duplicate ancestry proof rows, validate submitted church UUIDs before SQL,
  convert malformed domain-layer IDs to a controlled publication error, associate form
  labels with controls, allow bounded multiline notice text, prevent duplicate submissions,
  and clear public-sharing consent when cancelling. The TypeScript check now resolves
  the project's compiler instead of a Linux-specific absolute path.
- Added eight executable hierarchy regressions, five publication guard cases for the
  backend suite, a local evidence recorder, and a disposable-CI migration rollback check.
- Branding and the existing authentic, read-only English WEB Bible remain intact.
  Kiswahili UI does not claim to supply a Kiswahili Bible translation.

**Verified now:** 8 hierarchy regression tests; Python compilation; sermon validation
function checks; 6 palette-token contrast checks. These do not prove database security
or whole-interface accessibility.

**Not passed here:** schema/SQL and DNS-mock scripts (missing Python dependencies),
TypeScript syntax and production build (compiler/dependencies unavailable), backend
suite/migrations (pytest/Alembic and PostgreSQL environment unavailable). Docker CLI
is installed, but the Docker Desktop Linux engine is not running. Dependency downloads
failed; the broader-access retry was rejected by automatic approval review.

**Not executed:** live domain/HTTPS, browser E2E, keyboard/screen reader/mobile/user
acceptance, backup/restore and production security review. No real domain or deployment
was supplied. CI has been updated but has **not** run in this session.

Run `python scripts/verify_phase7b.py` to reproduce the local checks. Inspect
`evidence/2026-11-13/results.json` and its individual command logs, plus
`evidence/2026-11-13/source_lineage.json` and `changes_from_2026-11-12.patch`.
See `PHASE7B_ACCEPTANCE_RUNBOOK.md` for the remaining PostgreSQL and deployment checks.
Apply migration 0021 before running the updated app; do not downgrade a real database
just to test rollback (it discards descendant-sharing choices).

**Phase 7B stays 🔄. No later phase was started or accepted in this delivery.**


**Status 🔄 — implementation exists, acceptance tests not fully verified.**

## Why this feature exists

Church admins can publish public announcements on their parish's homepage without accidentally making staff/member communications public. Unlike tenant-wide notices, public bulletins are explicitly opted in; visitors to one parish see that parish's and approved ancestor-level notices, never sibling parishes' notices.

## Changed files

- `backend/alembic/versions/0020_public_bulletins.py` — adds `announcements.is_public boolean NOT NULL DEFAULT false` and an index.
- `backend/app/models/announcement.py`, `backend/app/schemas/announcement.py`, `backend/app/domain/announcements.py` — private-by-default publishing contract and minimal public DTO.
- `backend/app/api/routes/church_sites.py` — new `GET /sites/public/notices?hostname=...`; same verified Host binding and tenant RLS as other site resources.
- `backend/app/domain/public_bulletins.py` — parse ancestor org UUIDs for exact-path scoping.
- `backend/app/api/routes/announcements.py` — authenticated publish opt-in and returned visibility flag.
- `frontend/src/pages/AnnouncementsPage.tsx`, `frontend/src/i18n.ts` — English/Kiswahili consent checkbox.
- `frontend/src/pages/PublicHome.tsx`, `frontend/src/pages/PublicHome.css` — responsive editorial card layout, shown only for actual public notices.
- `backend/tests/test_church_sites.py`, `scripts/test_public_bulletins.py` — security assertions.

## Privacy/visibility rules

1. `is_public=false` by default, including all migrated legacy announcements.
2. Only logged-in roles with `manage_structure` for the selected unit can publish or opt into public visibility. Internal notifications are not affected.
3. Public endpoint first resolves the verified published site for the **real HTTP Host**; a caller-supplied hostname from an unrelated church is refused.
4. Site-specific DB query enforces tenant RLS, `is_public=True`, and validated tenant/parent/path ancestry. Own-unit notices require public consent; ancestor notices also require `show_on_descendant_sites=True`. Null/unscoped notices are always excluded.
5. Public responses contain only `id`, `title`, `body`, `urgency` and `created_at`.
6. Private staff messages, parish sibling messages and notices from a different tenant never appear.

## Test commands

From repo root:

```powershell
python -m compileall -q backend/app backend/alembic backend/tests
python scripts/test_public_bulletins.py
python scripts/test_church_site_logic.py
python scripts/check_sermon_logic.py
node scripts/check_typescript_syntax.cjs
python scripts/check_design.py
```

On an actual **Docker + PostgreSQL** installation with the new migration:

```powershell
docker compose up -d --build
docker compose exec backend alembic upgrade head
docker compose exec backend pytest tests/test_church_sites.py -v
docker compose exec backend pytest tests/test_announcements.py -v
docker compose exec frontend npm run build
```

**Warning:** API integration and browser testing cannot be claimed passed until run against an actual PostgreSQL-backed instance. Do not use the demo passwords in production. Domain and TLS validation remain open.

## Remaining Phase 7B acceptance gates

- Real PostgreSQL+RLS tests, migration up/down test, HTTPS custom-domain routing under trusted reverse proxy.
- E2E editor, tenant-bound registration, sermon streaming, and public bulletin permissions on at least two parishes of same tenant and a different tenant.
- Accessibility test with keyboard/screen reader/mobile, and a church volunteer without technical training.
- Backups/recovery and security review before production exposure.


### 2026-11-12 Phase 7B privacy increment (verification pending)
- Public bulletin scope now requires canonical, nonrepeating hierarchy UUIDs ending at the requested church unit; malformed paths fail closed.
- Public notices without a church unit are rejected on authenticated publishing and domain creation; public listing excludes unscoped notices.
- Publishing checks the target unit tenant explicitly, in addition to session scoping.
- Database/RLS, full frontend build, live DNS/TLS, browser accessibility and end-to-end acceptance have **not** been verified. Phase 7B remains 🔄.
