# Church ERP Sanctuary OS — Phase 7B follow-up increment

## Current continuation — free test hosting preparation (13 November 2026) 🔄

- Selected **Render Free + Neon Free**. See `deploy/FREE_HOSTING.md` and `render.yaml`.
- Added a single-origin hosted entrypoint and image. It serves only the compiled
  frontend, preserves Host on `/api`, validates secrets/TLS and rejects a database
  role that bypasses RLS. Hosted startup migrates but never seeds demo accounts.
- Added tenant/scoped editor unit choices, explicit tenant filters for sermon
  management, and no-store media responses so shared caches do not retain newly
  withdrawn sermons. Localized domain status labels and guarded editor submissions.
- Added native keyboard-modal focus handling for Bible/sermon dialogs; authentic
  WEB text retrieval/read-only behavior is unchanged. Localized text-size labels.
- Added built-React browser contract tests with explicit fixtures (not live E2E),
  plus hosted-routing, database-role and editor-scope tests for the backend suite;
  **these API-level tests have not executed here**.
- **Passed locally:** 8 hierarchy + 6 hosted-configuration tests, Python compilation,
  sermon function checks, 6 palette checks, and parsing 42 TS/TSX files with a
  locally cached Babel 7.29.12 parser. Parsing is not a TypeScript typecheck/build.
- **Cloud preparation verified:** a separate Neon Free PostgreSQL 16 project,
  application-role login with NOSUPERUSER/NOBYPASSRLS, and private object-storage
  bucket. No application migrations or application RLS integration ran there yet.
- GitHub connection can read the repository but **creating a branch was rejected
  with HTTP 403**. No new branch/commit/PR, source deployment, or CI run exists.
  Existing Render service was not modified. GitHub write authorization is needed.
- Still pending: actual PostgreSQL migration/RLS/API suites, locked frontend
  production build, domain ownership/HTTPS, browser E2E/accessibility/usability,
  backup/restore and security review. A free hosting URL does not bypass DNS proof.

Evidence for this continuation is in `evidence/2026-11-13-hosting/`. Earlier dated
results below are history. **7B stays 🔄; no later phase has started.**


## 13 November 2026 — Phase 7B continuation 🔄

This is the current delivery status; dated results below are historical.
Started from `Church_ERP_Sanctuary_OS_Phase7B_Privacy_Increment_2026-11-12.zip`.
Compared and merged `Church_ERP_Sanctuary_OS_Phase7B_Ancestor_Consent_Hardening_2026-11-09.zip`,
which contains safeguards missing from the later archive. The original 7 November
Public Bulletins baseline remains the lineage; this is a full incremental source delivery.

- Restored migration **0021**, separate descendant-site consent (false by default),
  tenant/parent/path ancestry proof, English/Kiswahili controls, site identity remount,
  PostgreSQL regressions, acceptance runbook and CI workflow from the 9 November source.
- Retained the 12 November strict UUID/path parser, API tenant filter, domain-layer
  tenant ownership check and rejection of public announcements without a church unit.
- New: reject duplicate ancestry proof rows, validate submitted church UUIDs before SQL,
  convert malformed domain-layer IDs to a controlled publication error, associate form
  labels with controls, allow bounded multiline notice text, prevent duplicate submissions,
  and clear public-sharing consent when cancelling. The TypeScript check now resolves
  the project's compiler instead of a Linux-specific absolute path.
- Added eight executable hierarchy regressions, five publication guard cases for the
  backend suite, a local evidence recorder, and a disposable-CI migration rollback check.
- Branding and the existing authentic, read-only English WEB Bible remain intact.
  Kiswahili UI does not claim to supply a Kiswahili Bible translation.

**Verified now:** 8 hierarchy regression tests; Python compilation; sermon validation
function checks; 6 palette-token contrast checks. These do not prove database security
or whole-interface accessibility.

**Not passed here:** schema/SQL and DNS-mock scripts (missing Python dependencies),
TypeScript syntax and production build (compiler/dependencies unavailable), backend
suite/migrations (pytest/Alembic and PostgreSQL environment unavailable). Docker CLI
is installed, but the Docker Desktop Linux engine is not running. Dependency downloads
failed; the broader-access retry was rejected by automatic approval review.

**Not executed:** live domain/HTTPS, browser E2E, keyboard/screen reader/mobile/user
acceptance, backup/restore and production security review. No real domain or deployment
was supplied. CI has been updated but has **not** run in this session.

Run `python scripts/verify_phase7b.py` to reproduce the local checks. Inspect
`evidence/2026-11-13/results.json` and its individual command logs, plus
`evidence/2026-11-13/source_lineage.json` and `changes_from_2026-11-12.patch`.
See `PHASE7B_ACCEPTANCE_RUNBOOK.md` for the remaining PostgreSQL and deployment checks.
Apply migration 0021 before running the updated app; do not downgrade a real database
just to test rollback (it discards descendant-sharing choices).

**Phase 7B stays 🔄. No later phase was started or accepted in this delivery.**


Date: 7 November 2026

**Status: 🔄 In progress. No ✅.** This archive extends Phase 7B but does **not** pass the release gate for independently hosted parishes.

## Implemented in this increment

1. **Real Host binding.** `/sites/public`, registration, published-sermon listing and site media require `?hostname=` to match the actual request Host. The only exception is the explicit `.localhost` demo with `ENABLE_DEMO_SITE_PREVIEWS=true`.
2. **Verified custom-domain tenant routing.** Authenticated API requests first resolve a verified domain mapping. A mismatched `X-Tenant-Slug` gets HTTP 403. Unknown custom domains cannot select an arbitrary tenant using a header. A single-level legacy tenant subdomain still works.
3. **Legacy registration guard.** Old tenant-wide `/auth/register` works on the tenant's legacy site or localhost only; an independent parish domain must use its own `/sites/public/register`, which determines church unit on the server.
4. **No public church directory on site signup.** Parish signup form no longer fetches the tenant-wide list. `/tenant/churches` is restricted to the current verified site's org unit on that domain.
5. **Sermon uploader picks the site automatically.** Authenticated sermon-manager on a parish domain targets that parish by default; it does not offer the tenant-wide option.
6. **Vite passes through the original Host.** `changeOrigin=false` is required for the API side's domain isolation.
7. **Demo exposure reduced.** PostgreSQL, Redis, MinIO and backend port bindings in `docker-compose.yml` are loopback-only. Expose **frontend** through one ngrok endpoint; do not point the same ngrok domain at multiple Docker services.
8. **Production-style static frontend recipe.** `frontend/Dockerfile.production` + `nginx.production.conf` serve a built React SPA and proxy `/api/` to the backend while preserving Host. `deploy/DockerCompose_preview_only.yml` is an example, **not a production deployment** (existing DB bootstrap secrets are still demo-grade).
9. **Negative tests added**: same-tenant and cross-tenant site resolution, unpublished content, wrong-Host spoof, wrong-tenant header, tenant-wide signup bypass, site-specific signup, scoped public church list and cross-site media denial.

## Checks actually run here

| Check | Result |
|---|---|
| Python `compileall` of app and test code | PASS (syntax only) |
| TypeScript/TSX transpile-parse (41 files) | PASS (syntax only, not type-check) |
| Pure hostname + DNS TXT mocking tests | PASS |
| Media signature + media URL + HTTP range tests | PASS |
| Approved forest/terracotta palette token contrast checks | PASS (6 checks; manual components still pending) |
| PostgreSQL + FastAPI integration suite | NOT RUN: no Docker/Postgres available in this environment; `asyncpg` missing |
| Full frontend `npm ci` + `npm run build` | NOT RUN: npm packages not available offline |
| Real TLS, DNS challenge and reverse-proxy behavior | NOT RUN: needs a real controlled domain and ingress |
| Mobile, screen-reader, usability testing | NOT RUN: needs supported devices / participant checks |

**Do not use ✅ until the pending tests above are performed and passed.**

## Commands on Windows with Docker Desktop

```powershell
Copy-Item .env.example .env
# Replace demo secrets before connecting to external users.
docker compose up -d --build
docker compose exec backend alembic upgrade head
docker compose exec backend python -m app.seeds.seed
docker compose exec backend pytest tests/test_church_sites.py -v
# For a separate frontend build check:
docker compose exec frontend npm run build
```

For local dev only (`ENABLE_DEMO_SITE_PREVIEWS=true`):
- `http://localhost:5173/?site=grace.localhost`
- `http://localhost:5173/?site=stmarks.localhost`

### Before real use

- Replace known passwords in `db/init.sql` with secret-injected app credentials, and rotate all seeded demo credentials; delete/disable demo accounts.
- Run a trusted HTTPS reverse proxy that forwards the **original Host** to both frontend and backend.
- Disable the demo site flag; use individually verified real domains (TXT proof, A/CNAME + TLS).
- Add request-rate limiting, registration abuse controls, backup/restore and tenant-level security tests.
- Confirm user testing in Kiswahili/English and accessibility on low-end phones.


### 7 November 2026 — Phase 7B public bulletin publishing (current increment) 🔄

**Built in code, not production-verified:**

- Added migration `0020_public_bulletins.py`: announcements have `is_public` with a **false** database default. All existing and future notices stay private unless an authorized editor explicitly opts into public display.
- The staff announcement form includes an English/Kiswahili public-visibility checkbox (off by default), with an explanation of who can read the notice.
- Verified church homepages now show a small editorial updates section only when actual public notices exist. No placeholder notices or tenant directory.
- New `GET /sites/public/notices?hostname=<current-host>` verifies the request Host + published site, then applies tenant RLS and selects at most five deliberately public notices from the exact site unit or ancestor units. No sibling notices, internal-only announcements, publisher identity or internal org identifiers are returned. Parent-unit propagation is explicit opt-in on the publication itself.
- Added PostgreSQL integration assertions to `backend/tests/test_church_sites.py` for private/public, same-tenant sibling, cross-tenant and hostname-spoof isolation, plus database-free boundary and schema checks in `scripts/test_public_bulletins.py`.

**Offline checks passed:** `python -m compileall`, `python scripts/test_public_bulletins.py`, existing DNS and media checks, and TypeScript/TSX transpile-parsing. **Not verified:** PostgreSQL integration, RLS, full npm production build, deployment, accessibility/user acceptance. Full frontend installation was blocked by missing npm packages (offline cache incomplete); PostgreSQL/Docker are unavailable here.

**Do not award Phase 7B ✅** until the required integration and acceptance gates pass. Status stays 🔄.
