// Offline syntax only; full type-check + Vite build requires npm ci.
const fs = require('fs');
const path = require('path');
const ts = require(require.resolve('typescript', { paths: [path.join(__dirname, '..', 'frontend'), process.cwd()] }));
const root = path.join(__dirname, '..', 'frontend', 'src');
let count=0, errors=[];
function scan(dir) {
  for (const name of fs.readdirSync(dir)) {
    const file=path.join(dir,name);
    if (fs.statSync(file).isDirectory()) scan(file);
    else if (/\.tsx?$/.test(name)) {
      const src=fs.readFileSync(file,'utf8');
      const result=ts.transpileModule(src,{fileName:file,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,module:ts.ModuleKind.ESNext}});
      count++;
      for(const d of result.diagnostics || []) {
        if(d.category === ts.DiagnosticCategory.Error) errors.push(`${file}: ${ts.flattenDiagnosticMessageText(d.messageText, '\n')}`);
      }
    }
  }
}
scan(root);
if(errors.length){console.error(errors.join('\n'));process.exit(1);}
console.log(`PASS: parsed/transpiled ${count} frontend TypeScript/TSX source files (syntax only)`);
