"""Run the real hosted configuration checks without optional Python packages."""
import importlib.util
from pathlib import Path
from types import SimpleNamespace
import unittest

path = Path(__file__).resolve().parents[1] / "backend/app/core/release_checks.py"
spec = importlib.util.spec_from_file_location("release_checks", path)
rules = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rules)


class HostedConfigurationTests(unittest.TestCase):
    def settings(self, **changes):
        values = dict(ENABLE_DEMO_SITE_PREVIEWS=False, JWT_SECRET="j" * 48,
                      PLATFORM_ADMIN_TOKEN="p" * 48, MINIO_SECURE=True)
        return SimpleNamespace(**(values | changes))

    def test_configured_hosted_instance(self):
        rules.validate_release_secrets(self.settings())

    def test_demo_routing_rejected(self):
        with self.assertRaises(RuntimeError):
            rules.validate_release_secrets(self.settings(ENABLE_DEMO_SITE_PREVIEWS=True))

    def test_default_jwt_rejected(self):
        with self.assertRaises(RuntimeError):
            rules.validate_release_secrets(self.settings(JWT_SECRET="change-me-in-production-please"))

    def test_default_operator_token_rejected(self):
        with self.assertRaises(RuntimeError):
            rules.validate_release_secrets(self.settings(PLATFORM_ADMIN_TOKEN="dev-platform-token"))

    def test_short_secrets_rejected(self):
        for key in ("JWT_SECRET", "PLATFORM_ADMIN_TOKEN"):
            with self.subTest(key=key), self.assertRaises(RuntimeError):
                rules.validate_release_secrets(self.settings(**{key: "short"}))

    def test_unencrypted_storage_rejected(self):
        with self.assertRaises(RuntimeError):
            rules.validate_release_secrets(self.settings(MINIO_SECURE=False))


if __name__ == "__main__":
    unittest.main(verbosity=2)
