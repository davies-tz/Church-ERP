"""Executable hierarchy regression tests; no database or third-party packages.

Runs the real public_bulletins module. This does not certify SQL execution/RLS.
"""
import importlib.util
from pathlib import Path
from types import SimpleNamespace
import unittest
import uuid

source = Path(__file__).resolve().parents[1] / "backend/app/domain/public_bulletins.py"
spec = importlib.util.spec_from_file_location("public_bulletins", source)
rules = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rules)


class HierarchyPrivacyTests(unittest.TestCase):
    def setUp(self):
        self.tenant, self.other, self.root, self.child = [uuid.uuid4() for _ in range(4)]
        self.path = f"/{self.root}/{self.child}/"
        self.rows = [
            SimpleNamespace(id=self.root, tenant_id=self.tenant, parent_id=None, path=f"/{self.root}/"),
            SimpleNamespace(id=self.child, tenant_id=self.tenant, parent_id=self.root, path=self.path),
        ]

    def proof(self, rows=None, path=None):
        return rules.verified_ancestor_unit_ids(
            self.path if path is None else path, self.child, self.tenant,
            self.rows if rows is None else rows)

    def test_valid_tree_in_any_query_order(self):
        self.assertEqual(self.proof(), (self.root, self.child))
        self.assertEqual(self.proof(list(reversed(self.rows))), (self.root, self.child))

    def test_missing_ancestor(self):
        with self.assertRaises(ValueError): self.proof(self.rows[1:])

    def test_duplicate_database_rows(self):
        with self.assertRaises(ValueError): self.proof(self.rows + [self.rows[0]])

    def test_cross_tenant_parent(self):
        self.rows[0].tenant_id = self.other
        with self.assertRaises(ValueError): self.proof()

    def test_forged_parent_link(self):
        self.rows[1].parent_id = self.other
        with self.assertRaises(ValueError): self.proof()

    def test_forged_ancestor_path(self):
        self.rows[0].path = f"/{self.other}/{self.root}/"
        with self.assertRaises(ValueError): self.proof()

    def test_wrong_site_endpoint(self):
        with self.assertRaises(ValueError):
            rules.scoped_ancestor_unit_ids(self.path, self.other)

    def test_malformed_paths_fail_closed(self):
        for bad in (None, "", "/", "abc", f"/{self.root}//{self.child}/",
                    f"/{self.root}/{self.root}/{self.child}/", self.path[:-1],
                    f"/{self.root.hex}/{self.child}/", f"/invalid/{self.child}/"):
            with self.subTest(path=bad), self.assertRaises(ValueError): self.proof(path=bad if bad is not None else "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
