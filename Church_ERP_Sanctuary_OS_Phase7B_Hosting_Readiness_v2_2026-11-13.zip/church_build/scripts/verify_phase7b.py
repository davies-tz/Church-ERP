"""Record reproducible local checks without converting missing dependencies to passes."""
import json
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--evidence-dir", default="evidence/2026-11-13")
args = parser.parse_args()
EVIDENCE = ROOT / args.evidence_dir
EVIDENCE.mkdir(parents=True, exist_ok=True)
npm = shutil.which("npm.cmd") or shutil.which("npm") or "npm"
checks = [
    ("hierarchy_regressions", [sys.executable, "scripts/test_phase7b_privacy_regression.py"], ROOT),
    ("hosted_config_regressions", [sys.executable, "scripts/test_release_checks.py"], ROOT),
    ("python_compilation", [sys.executable, "-m", "compileall", "-q", "backend/app", "backend/alembic", "backend/tests", "deploy", "scripts"], ROOT),
    ("palette", [sys.executable, "scripts/check_design.py"], ROOT),
    ("sermon_validation", [sys.executable, "scripts/check_sermon_logic.py"], ROOT),
    ("bulletin_schema_sql", [sys.executable, "scripts/test_public_bulletins.py"], ROOT),
    ("hostname_dns_mocks", [sys.executable, "scripts/test_church_site_logic.py"], ROOT),
    ("typescript_syntax", ["node", "scripts/check_typescript_syntax.cjs"], ROOT),
    ("frontend_build", [npm, "run", "build"], ROOT / "frontend"),
    ("publication_and_site_tests", [sys.executable, "-m", "pytest", "tests/test_publication_guards.py", "tests/test_church_sites.py", "tests/test_tenant_isolation.py", "tests/test_site_editor_scope.py", "tests/test_production.py", "-v"], ROOT / "backend"),
    ("migration_status", [sys.executable, "-m", "alembic", "current"], ROOT / "backend"),
    ("docker_engine", ["docker", "version"], ROOT),
]
results = []
for name, command, cwd in checks:
    try:
        run = subprocess.run(command, cwd=cwd, capture_output=True, text=True,
                             encoding="utf-8", errors="replace", timeout=45)
        code, output = run.returncode, run.stdout + run.stderr
    except (OSError, subprocess.TimeoutExpired) as exc:
        code, output = -1, str(exc)
    # Absolute Python/npm executable paths are machine details, not requirements.
    relative_cwd = str(cwd.relative_to(ROOT)) or "."
    (EVIDENCE / f"{name}.txt").write_text(
        f"cwd: {relative_cwd}\ncommand: {command!r}\nexit_code: {code}\n\n{output}", encoding="utf-8")
    results.append({"check": name, "exit_code": code,
                    "result": "PASS" if code == 0 else "NOT PASSED: inspect log"})
    print(f"{name}: {results[-1]['result']}")
(EVIDENCE / "results.json").write_text(json.dumps({
    "date": "2026-11-13", "phase": "7B", "phase_status": "IN PROGRESS",
    "checks": results,
    "not_executed": ["real DNS/HTTPS", "browser E2E", "screen reader/mobile acceptance", "backup/restore", "production security review"],
}, indent=2), encoding="utf-8")
