# Phase 7B free test hosting — Render + Neon

Status on 13 November 2026: prepared, **not deployed or accepted**.

## Selected arrangement

- Render Free web service builds `deploy/Dockerfile.render`. One origin serves
  the compiled React frontend at `/` and the API at `/api`. The actual Host is
  preserved; no caller header is promoted into trusted church identity.
- Neon Free PostgreSQL 16, using `church_app`, not an owner/admin connection.
- Neon Object Storage with the `sanctuary-private` **private** bucket. Objects
  remain tenant-prefixed and can only be served through the existing authorized
  API or verified-site published-media routes.
- Redis is not used by the current backend source; no additional hosted Redis
  instance is required for this deployment profile.

Render Free sleeps after 15 minutes without incoming requests and has usage
quotas. Neon Free currently includes 1 GB Postgres storage, 100 CU-hours per
project/month and 5 GB object storage. Keep the project on its Free plan; this is
a small test/pilot setup with quotas, not an uptime or zero-overage guarantee.
Do not select paid upgrades to finish acceptance without a new user decision.

Sources checked 13 November 2026:
[Render limits](https://render.com/docs/free),
[Neon pricing](https://neon.com/pricing),
[Neon roles](https://neon.com/docs/manage/roles),
[Neon storage](https://neon.com/docs/storage/get-started).

## Resources prepared in this session

- Render workspace: `My Workspace` (selected by the user).
- Existing Render `Church-ERP` service uses `davies-tz/Church-ERP`, branch `main`.
  Its latest listed deployment was `build_failed`. It was **not modified**.
- New separate Neon project: `Sanctuary OS Phase7B Acceptance`,
  `snowy-breeze-42540157`, PostgreSQL 16, Frankfurt, branch
  `br-quiet-shadow-baeyvbz8`, database `church_erp`.
- Created `church_app` as a restricted read/write login and granted schema
  USAGE/CREATE for Alembic. An actual login query confirmed `rolsuper=false`
  and `rolbypassrls=false`. This is **not** application RLS integration evidence.
- Created `sanctuary-private` and verified its access level is `private`.
- No application migrations have been run in this database. No real church
  records, demo users, passwords or public media have been uploaded.
- GitHub rejected creating the source branch with HTTP 403, `Resource not
  accessible by integration`. The connected writer must be authorized before
  publishing the source and triggering CI. The same 403 was returned after the user reported reconnecting. No branch, commit or PR was created.

## Deployment procedure after repository writes are available

1. Push this complete runtime source on an isolated `codex/phase7b-...` branch.
   Keep existing repository files; do not overwrite or deploy the old `main`
   service automatically. Run `.github/workflows/phase7b-gates.yml` and inspect
   the real PostgreSQL suite, migration rollback/re-upgrade and frontend build.
2. Use `render.yaml` to review a **separate Free test service** in My Workspace,
   or create an equivalent Free Docker web service from that test branch.
   A Blueprint plan needs review/approval before it is applied. This file is not
   proof that a service exists.
3. Set DATABASE_URL using the newly created `church_app` login and the **direct**
   Neon endpoint. Use the SQLAlchemy asyncpg scheme and `ssl=require`, for example:
   `postgresql+asyncpg://church_app:<secret>@<direct-neon-host>/church_erp?ssl=require`.
   URL-encode password characters. Do not use the default owner, the demo
   password, or blindly paste `sslmode`/`channel_binding` parameters intended
   for another driver. Keep all credentials in the hosting environment.
4. Supply the storage endpoint hostname **without** `https://`, the private S3
   access key/secret, `MINIO_REGION=eu-central-1`, `MINIO_SECURE=true`, and
   `MINIO_BUCKET=sanctuary-private`. Neon uses path-style S3 addressing. The
   existing MinIO client uses path-style requests for this custom endpoint.
   Keep the bucket private; exercise upload/download integration before acceptance.
5. Generate unique JWT_SECRET and PLATFORM_ADMIN_TOKEN values in Render. Keep
   ENABLE_DEMO_SITE_PREVIEWS=false. Hosted startup rejects demo/short secrets,
   plaintext storage and a database login with superuser/BYPASSRLS privileges.
   It then applies migrations and starts the single-origin app. It never runs
   the demo seed and never introduces the known demo account passwords.
6. Check `/health` and `/api/health`, then follow the acceptance runbook against
   real tenant/site records and test data. `/api/platform/*` remains guarded by
   the operator token; never put this token in the browser bundle or URLs.

## Domain ownership is still a separate gate

Render supplies an HTTPS `onrender.com` service URL. Availability and exact names
are determined by Render; no URL has been reserved for the new test service.
That URL alone does **not** prove church domain ownership in this application's
DNS TXT verification flow. Do not set `verified_at` manually, enable demo previews
publicly, or treat the free provider subdomain as a verified church domain.

For each independent church homepage, supply a domain/subdomain with control of
its DNS TXT records, point it at the service, verify the `_sanctuary` record, and
test HTTPS and routing. A registered custom domain can cost money; free hosting
does not include ownership of a custom domain. If no controllable domain is
available, this acceptance gate remains pending, without weakening verification.

## Evidence and remaining work

Run `python scripts/verify_phase7b.py --evidence-dir evidence/2026-11-13-hosting`.
Current local checks cannot replace the cloud production build, application
PostgreSQL/RLS suite, domain/HTTPS, browser E2E, accessible-user testing,
backup/restore and security review in `PHASE7B_ACCEPTANCE_RUNBOOK.md`.
Phase 7B stays 🔄 and later phases remain deferred until those gates pass.
