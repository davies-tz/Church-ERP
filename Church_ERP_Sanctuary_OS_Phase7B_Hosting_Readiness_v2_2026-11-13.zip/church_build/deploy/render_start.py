"""Hosted startup: validate, migrate, then serve; never seed demo credentials."""
import asyncio
import os
import subprocess
import sys

from app.core.config import settings
from app.core.db import engine
from app.core.release_checks import validate_release_secrets, verify_database_role


async def preflight():
    validate_release_secrets(settings)
    try:
        await verify_database_role(engine)
    finally:
        await engine.dispose()


if __name__ == "__main__":
    asyncio.run(preflight())
    subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head"], check=True)
    port = int(os.environ.get("PORT", "10000"))
    os.execv(sys.executable, [sys.executable, "-m", "uvicorn", "app.production:create_app",
                            "--factory", "--host", "0.0.0.0", "--port", str(port),
                            "--proxy-headers", "--forwarded-allow-ips", "127.0.0.1"])
