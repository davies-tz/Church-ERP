# CHURCH ERP — SANCTUARY OS

## Current continuation — free test hosting preparation (13 November 2026) 🔄

- Selected **Render Free + Neon Free**. See `deploy/FREE_HOSTING.md` and `render.yaml`.
- Added a single-origin hosted entrypoint and image. It serves only the compiled
  frontend, preserves Host on `/api`, validates secrets/TLS and rejects a database
  role that bypasses RLS. Hosted startup migrates but never seeds demo accounts.
- Added tenant/scoped editor unit choices, explicit tenant filters for sermon
  management, and no-store media responses so shared caches do not retain newly
  withdrawn sermons. Localized domain status labels and guarded editor submissions.
- Added native keyboard-modal focus handling for Bible/sermon dialogs; authentic
  WEB text retrieval/read-only behavior is unchanged. Localized text-size labels.
- Added built-React browser contract tests with explicit fixtures (not live E2E),
  plus hosted-routing, database-role and editor-scope tests for the backend suite;
  **these API-level tests have not executed here**.
- **Passed locally:** 8 hierarchy + 6 hosted-configuration tests, Python compilation,
  sermon function checks, 6 palette checks, and parsing 42 TS/TSX files with a
  locally cached Babel 7.29.12 parser. Parsing is not a TypeScript typecheck/build.
- **Cloud preparation verified:** a separate Neon Free PostgreSQL 16 project,
  application-role login with NOSUPERUSER/NOBYPASSRLS, and private object-storage
  bucket. No application migrations or application RLS integration ran there yet.
- GitHub connection can read the repository but **creating a branch was rejected
  with HTTP 403**. No new branch/commit/PR, source deployment, or CI run exists.
  Existing Render service was not modified. GitHub write authorization is needed.
- Still pending: actual PostgreSQL migration/RLS/API suites, locked frontend
  production build, domain ownership/HTTPS, browser E2E/accessibility/usability,
  backup/restore and security review. A free hosting URL does not bypass DNS proof.

Evidence for this continuation is in `evidence/2026-11-13-hosting/`. Earlier dated
results below are history. **7B stays 🔄; no later phase has started.**


## 13 November 2026 — Phase 7B continuation 🔄

This is the current delivery status; dated results below are historical.
Started from `Church_ERP_Sanctuary_OS_Phase7B_Privacy_Increment_2026-11-12.zip`.
Compared and merged `Church_ERP_Sanctuary_OS_Phase7B_Ancestor_Consent_Hardening_2026-11-09.zip`,
which contains safeguards missing from the later archive. The original 7 November
Public Bulletins baseline remains the lineage; this is a full incremental source delivery.

- Restored migration **0021**, separate descendant-site consent (false by default),
  tenant/parent/path ancestry proof, English/Kiswahili controls, site identity remount,
  PostgreSQL regressions, acceptance runbook and CI workflow from the 9 November source.
- Retained the 12 November strict UUID/path parser, API tenant filter, domain-layer
  tenant ownership check and rejection of public announcements without a church unit.
- New: reject duplicate ancestry proof rows, validate submitted church UUIDs before SQL,
  convert malformed domain-layer IDs to a controlled publication error, associate form
  labels with controls, allow bounded multiline notice text, prevent duplicate submissions,
  and clear public-sharing consent when cancelling. The TypeScript check now resolves
  the project's compiler instead of a Linux-specific absolute path.
- Added eight executable hierarchy regressions, five publication guard cases for the
  backend suite, a local evidence recorder, and a disposable-CI migration rollback check.
- Branding and the existing authentic, read-only English WEB Bible remain intact.
  Kiswahili UI does not claim to supply a Kiswahili Bible translation.

**Verified now:** 8 hierarchy regression tests; Python compilation; sermon validation
function checks; 6 palette-token contrast checks. These do not prove database security
or whole-interface accessibility.

**Not passed here:** schema/SQL and DNS-mock scripts (missing Python dependencies),
TypeScript syntax and production build (compiler/dependencies unavailable), backend
suite/migrations (pytest/Alembic and PostgreSQL environment unavailable). Docker CLI
is installed, but the Docker Desktop Linux engine is not running. Dependency downloads
failed; the broader-access retry was rejected by automatic approval review.

**Not executed:** live domain/HTTPS, browser E2E, keyboard/screen reader/mobile/user
acceptance, backup/restore and production security review. No real domain or deployment
was supplied. CI has been updated but has **not** run in this session.

Run `python scripts/verify_phase7b.py` to reproduce the local checks. Inspect
`evidence/2026-11-13/results.json` and its individual command logs, plus
`evidence/2026-11-13/source_lineage.json` and `changes_from_2026-11-12.patch`.
See `PHASE7B_ACCEPTANCE_RUNBOOK.md` for the remaining PostgreSQL and deployment checks.
Apply migration 0021 before running the updated app; do not downgrade a real database
just to test rollback (it discards descendant-sharing choices).

**Phase 7B stays 🔄. No later phase was started or accepted in this delivery.**

## Approved implementation phases | November 2026

> **Product:** one secure multi-tenant church platform, but **no shared church directory as the public homepage**. Each church/branch eventually has its own branded address and identity. The platform is an invisible technical backbone, not the visitor's experience.
>
> **Status key:** ✅ phase fully implemented AND acceptance tests passed · 🔄 currently being built · ⚠️ source exists but acceptance tests not yet passed · ⏳ planned. **No green tick is awarded merely for having code.**
>
> **Source of ideas:** MyChurchIT, ChurchCMS, Subsplash, Breeze/Tithely, Planning Center, and YFM. Learn from user journeys, never reuse their branding or copyrighted layouts.

## 0. Locked product decisions

1. **Tenant isolation is mandatory**: each denomination/country is a tenant; each diocese, parish, congregation or branch is an `org_unit` underneath it. Existing RLS and role-at-unit permissions remain; no re-architecture to a separate database per parish.
2. **Church identity is independent**: Phase 7B maps a verified hostname to **both** `tenant_id` **and** `org_unit_id`, so every participating parish can have its own home, service schedule, contact information, approved public media and content editors. The current site is tenant-level only; do not misrepresent it.
3. **No public tenant selector/directory**: visitors arriving at a church domain see that church only. A separate super-admin console serves the platform operator.
4. **Financial integrity**: only explicitly authorized accounting roles enter/post finance transactions; maker-checker, ledgers and audit trails are enforced server-side. Ordinary members never see staff finance or another member's private data.
5. **Real scripture, unchanged**: the animated Bible is an interaction. It opens an actual read-only Bible edition from a legitimate public-domain/licensed source. Never generate or edit scripture. Translations must be individually licensed/verified.
6. **Sermons use real workflows**: media is tenant- and site-scoped, draft until published, must be accessible on church's home, playable without autoplay. Audio, video, external embed, transcripts and live content have explicit rights/access rules.
7. **Dignity & accessibility**: English/Kiswahili controls, plain action language, no unexplained icons, high contrast, large taps, keyboard navigation, reduced motion and low-bandwidth fallbacks. Test with members with limited digital literacy.

## Research → product decisions

| Reviewed reference | Useful pattern | Original decision for Sanctuary OS |
|---|---|---|
| MyChurchIT | denomination/church/group/individual portal structure | hierarchy-aware RBAC + scoped dashboards; independent parish microsite in Phase 7B |
| ChurchCMS | media library, member mobile access, prayer requests, QR attendance | integrated church media studio and future care + check-in workflows |
| Subsplash | connected church journey from first visit to engagement | public-first website → visit → join → attend → participate → give, with no disconnected products |
| Breeze/Tithely | easy people/groups/events/forms, accessible onboarding | three main next actions on member dashboard, simplified view; forms & people operations |
| Planning Center | Home work hub, Services, Check-ins, Calendar, Groups, Publishing, Church Center | action-oriented staff workspace, worship/volunteer planning, room booking, secure children check-in, branded web/PWA |
| YFM | a homepage designed around media discovery / listening | featured published sermon, real audio/video player, editorial media shelves; no design/assets copied |

## Phase 5 — People, families & governance ⏳
**Goal:** a reliable picture of church life, not just a member list.

- Family/household links, relationships and consent; pastoral privacy controls.
- Leadership appointments with dates, position history and authorized replacement workflows.
- Attendance (services, groups); secure check-in for adults and children with pickup authority.
- Meetings, minutes, tasks, decisions and approvals with records of who acted.

**Exit test:** parish officer can register household; authorized leader can appoint a person from eligible member list; other parishes cannot access that family; audit log records sensitive changes.

## Phase 6 — Financial operations & fundraising ⏳
**Goal:** trustworthy finance used by non-accountants only at appropriate read-only level.

- Monthly/quarterly/yearly budgets; budget-vs-actual and parent-unit funding requests.
- Fundraising campaigns/project milestones, targets and contribution receipts.
- Procurement request → approval → payment; maker/checker separation.
- Income-producing assets linked to real ledger entries; church/project summaries.
- Reconciliation, TZS and supported foreign currencies, export controls.

**Exit test:** unauthorized users cannot post a transaction; all figures reconcile to underlying ledger rows; a user cannot approve their own posting; cross-org scopes enforced.

## Phase 7A — Original public home + real sermon studio ⚠️
**Already in this starter source:** media-forward responsive home; two distinct theme variants; authorized sermon upload (small MP3/WAV/OGG/MP4/WebM), HTTPS external links, draft/publish/archive, featured sermon, public media listing and playback; PostgreSQL RLS migration `0018_sermons.py`.

**Pending validation and hardening:** real Docker integration tests, audio seek, permissions, antivirus scan, large-upload streaming, CDN/transcode, thumbnails, moderation and media rights consent.

**Exit test:** publish an actual sermon under Grace and verify that St. Mark's cannot see or stream it; draft and archived sermons never show publicly; a normal member cannot publish.

## Phase 7B — Truly independent parish/branch websites 🔄 **CURRENT BUILD**

- `church_sites`: id, tenant_id, org_unit_id, title, tagline, languages, address, contact, primary image, approved palette and layout variant.
- `church_site_domains`: hostname, tenant_id, org_unit_id, challenge, verified_at, active, HTTPS status; reject unverified or ambiguous hostnames.
- All public APIs resolve the *trusted hostname* server-side to a site context. Ignore arbitrary client-supplied tenant/org-unit for authorization.
- Public sermons, schedules, bulletins, announcements and ministry pages filter by the mapped site and explicitly permitted parent content. **Public announcements are now an explicit opt-in:** private-by-default, selected by exact unit/ancestors only. Schedules are still a website-profile text field, not a calendar.
- Scoped editor/CMS for local church admins; parent denomination retains hierarchical visibility according to RBAC.
- Separate operator-only platform interface, separate support and billing domains.

**Exit test:** `parish-a.example`, `parish-b.example` and denomination's domain render different content and branding. No cross-site media or membership leaks. No site list on either homepage. Tests prove hostname spoofing fails.

### Phase 7B build increment — 7 November 2026

**Implemented in source (not yet a completed phase):**

- `0019_church_sites.py` creates independent sites mapped to a tenant **and a specific org unit**, with Row-Level Security on site content. Global hostname mapping contains only public routing identifiers, not private data.
- Tenant-admin / appropriately scoped `manage_structure` users can create/edit a church website, configure welcoming text, worship times, location, theme and published state, and register/remove domains. Site editor appears as **Church websites / Tovuti za makanisa** inside the staff dashboard.
- Each domain requires DNS TXT proof (`_sanctuary.<hostname>`); until verified, neither public homepage nor sermons can resolve through it. Demo-only `grace.localhost` and `stmarks.localhost` domains are seeded automatically for local preview.
- Public API resolves **verified domain -> tenant -> org unit** and filters **published** sermons to exactly that unit, with similarly scoped media streaming. Existing legacy tenant-level public sermon endpoints now serve **tenant-wide entries only** (`org_unit_id IS NULL`), preventing parish recordings from being listed tenant-wide.
- Frontend resolves the verified site before tenant login, applies that site's identity, uses site-only sermon feed and registers website visitors into the resolved org unit **server-side** through `/sites/public/register`. A custom hostname without a verified mapping shows a clear unconfigured message rather than Grace's homepage.
- Added domain-validation/DNS-proof unit checks, TSX syntax checks and a Docker-ready integration test covering two units of the same tenant and a third tenant.

**Still required before Phase 7B can receive ✅:** run PostgreSQL/Docker integration suite, exercise site registration and legacy tenant-registration policy plus content-editor permissions end-to-end, configure DNS/HTTPS at real ingress, test restore/rollback, review security of host routing, and complete responsive + accessibility acceptance checks. **Never interpret a local test or static screenshot as a production deployment.**

## Phase 8A — Authentic Bible + distinct role-aware workspace ⚠️
**Already in starter source:** animated book cover opening to World English Bible (read-only, fetched from bible-api.com); book/chapter navigation and text controls; staff workspace with live overview; member's plain-language actions; new **Easy view / Mwonekano rahisi** toggle for larger controls, preserved per tenant.

**Access-control improvement in this increment:** finance/asset cards and downloads now require their relevant capabilities in the frontend. **Backend permissions must still be independently tested.**

**Exit test:** non-accountants never see finance shortcuts on their dashboard; no fictional KPI figures; user can reach Bible and church service request with keyboard or touch.

## Phase 8B — Worship-first usability & scripture enhancements ⏳

- Properly licensed/allowed Kiswahili Bible edition; offline chapter access; book/chapter/verse search, bookmarks and spoken reading where permitted.
- Member first-visit guided flows; optional reduced-complexity home and clear failure recovery.
- Staff "Today at Church" panel with tasks needing attention, next service, people follow-up and quick actions—not a maze of charts.
- Custom accessibility preferences per member; usability evidence on real low-end Androids, slow networks and older members.

**Exit test:** 5 members of mixed digital literacy independently complete 5 common tasks with no instructor; keyboard & screen reader checks and WCAG 2.2 AA audit recorded.

## Phase 9 — Documents, communication & pastoral care ⏳

- Scoped document library, search, download, upload moderation, retention.
- Member ID cards with QR, printable receipts and notices.
- Opt-in SMS/email/push with delivery logs, privacy defaults and unsubscribes.
- Prayer requests (public/private), pastoral care follow-up, consent, confidentiality.
- English/Kiswahili printed communication; no private prayer information on public homepage.

**Exit test:** a parish member accesses only approved resources; another unit cannot fetch private documents by guessed IDs; delivery respects opt-outs.

## Phase 10 — Security, QA and first pilot release ⏳ (release gate)

- Verified domains + HTTPS, tenant/org scope integration tests, RLS/IDOR and audit-event review.
- Secrets, 2FA/admin MFA, backup+restore demonstration, environment separation, monitoring, migration rollback, abuse/rate controls.
- Accessibility + performance budget tests; OWASP ASVS risk assessment; Tanzania PDPA applicability and data governance review.
- Pilot with two differently branded churches on live data only after safeguards pass.

**Exit test:** rollback/restore shown, no cross-tenant exposure, media security tested and release checklist signed. **Current starter is not production ready.**

## Phase 11 — Planning Center-inspired church operations ⏳ (pilot expansion)

- Service planning: worship schedule, assigned roles, choir/worship team, rehearsal and order-of-service.
- Volunteer availability, rota, accept/decline invites and replacement alerts.
- Shared calendar + facilities/room/equipment scheduling, conflict prevention and RSVP.
- Event forms, attendee registration and printable check-in lists; scheduled follow-ups.
- Group lifecycle: Bible study, youth, women/men, choir, ministry circles; safe group communication.

**Exit test:** a service planner schedules a Sunday service, avoids a double-booked room, invites volunteers and checks attendance, using the same member records.

## Phase 12 — Member journey, engagement & mobile ⏳ (pilot expansion)

- Church-specific installable PWA: Home, Sermons, Bible, Events, My Church and Profile; offline drafts/sync if secure.
- First-visit/new-believer journey: visit card → consent → join a group → leader follow-up → welcome service.
- Parent/guardian-authorized children check-in with verifiable pickup token and retention controls.
- Voice/listen actions and very clear labels as *progressively enhanced* accessibility options.
- In-app group chat with block/report tools, privacy boundaries, notification preferences.

**Exit test:** mobile member can find sermon, join event, manage a request and view church-only notifications on a budget Android device without confusion.

## Phase 13 — Evidence-driven operations & SaaS sustainability ⏳

- Per-tenant storage/usage limits, billing only in platform-operator area; legal terms and data exports.
- Privacy-preserving ministry insights (attendance trend, service participation, campaign progress) with small-group suppression and scoped access.
- Audit and performance dashboards for operators (no raw church-sensitive content by default).
- Configurable denomination templates/hierarchy and migration/import assistant.

**Exit test:** admin sees only permitted aggregate metrics; no identifiable household data in analytics without specific permission; every tenant can export its own data.

---

## Design system requirements (apply to every phase)

- **Original expression:** "Sanctuary" combines a calm sacred editorial homepage with *action-first* member workspace, not a corporate analytics dashboard.
- **Color 60/30/10 heuristic:** ~60% paper/neutral; ~30% forest/terracotta; <=10% brass accent. Accent gold is for emphasis against dark, not small text on white.
- **Tested palette samples:** forest dark `#132B29` ↔ paper `#F7F5EF` = **13.71:1**; body `#1E3936` ↔ paper = **11.37:1**; gold `#D8B878` ↔ dark = **7.86:1**; subtle text `#5D6A64` ↔ paper = **5.19:1**. Use WCAG AA >=4.5:1 ordinary text and >=3:1 large text; dynamic church-selected colors must be validated too.
- **Typography:** expressive Georgia/serif for short hero and Scripture headings, ordinary sans-serif for controls; body >=16px for primary reading experiences, clear 1.5+ line-height.
- **Touch:** target controls >=44px where feasible; visible focus, skip link, correct heading order, no auto-playing sound, motion reduced when requested.
- **Responsiveness:** test 360 / 390 / 768 / 1024 / 1440; make forms, embedded players and media filters work without horizontal overflow.
- **Accessibility:** no icon-only actions without labels, no charts without a written interpretation, no fictitious statistics or made-up sermons/schedules.
- **Performance:** lazy media, optimized assets, avoid huge homepage autoplay background videos, operate on constrained 3G/4G.

## Immediate engineering sprint (START HERE)

1. **Run current tests, including `tests/test_church_sites.py`,** using Docker; capture failing cases instead of marking source existence as a passing test.
2. **Validate and harden the Phase 7B implementation:** run migration `0019`, verify DNS ownership under real domains, confirm parish-level APIs and the site editor behave securely in Docker.
3. Scope sermons per public `org_unit_id` and add site-specific publishing rights; move from 25 MB demo limit to secure upload infrastructure.
4. **Deferred until all Phase 7B gates pass:** make Phase 8B simple-mode usable with older members and test accessible navigation/contrast.
5. **Deferred until its preceding phases are accepted:** build Phase 11 first vertical slice (events, service times, volunteer assignments) before expanding into all modules.

## Reference pages reviewed

- https://www.mychurchit.org/church-management-system/
- https://churchcms.app/
- https://www.subsplash.com/blog/church-management-software
- https://www.breezechms.com/lp/best-church-management-software
- https://www.planningcenter.com/
- https://www.planningcenter.com/home
- https://www.planningcenter.com/church-center
- https://www.planningcenter.com/check-ins
- https://www.breezechms.com/
- https://www.yfm.co.za/


### 7 November 2026 — Phase 7B hardening, still 🔄 (not ✅)

The latest source update binds domain-specific public APIs to the real HTTP Host, resolves verified domain → tenant before accepting a client tenant header, blocks broad legacy registration from church-specific domains, and prevents parish registration/sermon pages from displaying other churches. Vite now preserves the Host; database/cache/storage/admin ports bind to loopback for the local demo.

Offline validation: Python syntax, 41 TypeScript/TSX syntax parses, hostname/DNS-mock checks, media validation and six color-token contrast checks **passed**. Docker/PostgreSQL/RLS integration, full npm build, real DNS/HTTPS, security and user acceptance remain **unverified**. See `PHASE7B_SECURITY_AND_TEST_RESULTS.md` for exact commands and evidence. **Do not mark green ✅ yet.**

### 7 November 2026 — Phase 7B public bulletin publishing (current increment) 🔄

**Built in code, not production-verified:**

- Added migration `0020_public_bulletins.py`: announcements have `is_public` with a **false** database default. All existing and future notices stay private unless an authorized editor explicitly opts into public display.
- The staff announcement form includes an English/Kiswahili public-visibility checkbox (off by default), with an explanation of who can read the notice.
- Verified church homepages now show a small editorial updates section only when actual public notices exist. No placeholder notices or tenant directory.
- New `GET /sites/public/notices?hostname=<current-host>` verifies the request Host + published site, then applies tenant RLS and selects at most five deliberately public notices from the exact site unit or ancestor units. No sibling notices, internal-only announcements, publisher identity or internal org identifiers are returned. Parent-unit propagation is explicit opt-in on the publication itself.
- Added PostgreSQL integration assertions to `backend/tests/test_church_sites.py` for private/public, same-tenant sibling, cross-tenant and hostname-spoof isolation, plus database-free boundary and schema checks in `scripts/test_public_bulletins.py`.

**Offline checks passed:** `python -m compileall`, `python scripts/test_public_bulletins.py`, existing DNS and media checks, and TypeScript/TSX transpile-parsing. **Not verified:** PostgreSQL integration, RLS, full npm production build, deployment, accessibility/user acceptance. Full frontend installation was blocked by missing npm packages (offline cache incomplete); PostgreSQL/Docker are unavailable here.

**Do not award Phase 7B ✅** until the required integration and acceptance gates pass. Status stays 🔄.


### 2026-11-12 Phase 7B privacy increment (verification pending)
- Public bulletin scope now requires canonical, nonrepeating hierarchy UUIDs ending at the requested church unit; malformed paths fail closed.
- Public notices without a church unit are rejected on authenticated publishing and domain creation; public listing excludes unscoped notices.
- Publishing checks the target unit tenant explicitly, in addition to session scoping.
- Database/RLS, full frontend build, live DNS/TLS, browser accessibility and end-to-end acceptance have **not** been verified. Phase 7B remains 🔄.
