"""Built React browser contracts with explicit API fixtures; NOT live E2E/RLS.

Install scripts/requirements-browser.txt and Chromium; build frontend first.
"""
import json
from pathlib import Path
import subprocess
import time
from urllib.parse import urlsplit
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence" / "browser-contracts"
SITE = dict(id="acceptance-site", tenant_slug="acceptance", org_unit_id="00000000-0000-4000-8000-000000000001",
            hostname="localhost", display_name="Acceptance test church", tagline="Test fixture",
            welcome_message="Browser acceptance fixture", service_times="", location_label="",
            contact_email="", theme="forest")
BRAND = dict(slug="acceptance", name=SITE["display_name"], display_name=SITE["display_name"],
             tagline="Test fixture", logo_light_url=None, login_bg_url=None,
             color_primary="#132b29", color_secondary="#1d433c", color_accent="#d8b878",
             font_key="Georgia", default_locale="en", enabled_locales=["en", "sw"])


def api_fixture(route):
    path = urlsplit(route.request.url).path
    responses = {"/api/sites/public": SITE, "/api/tenant/branding": BRAND,
                 "/api/sites/public/sermons": [], "/api/sites/public/notices": []}
    route.fulfill(status=200 if path in responses else 404,
                  json=responses.get(path, {"detail": "Unexpected acceptance API request"}))


def bible_fixture(route):
    # Authentic public-domain WEB wording, confined to a deterministic test fixture.
    if urlsplit(route.request.url).path == "/data/web":
        payload = {"books": [{"id": "JHN", "name": "John"}]}
    else:
        payload = {"verses": [{"chapter": 3, "verse": 16,
                    "text": "For God so loved the world, that he gave his one and only Son, that whoever believes in him should not perish, but have eternal life."}],
                   "translation": {"name": "World English Bible", "license": "Public Domain"}}
    route.fulfill(json=payload)


def run():
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    with (EVIDENCE / "preview-server.txt").open("w", encoding="utf-8") as output:
        server = subprocess.Popen(["node", "node_modules/vite/bin/vite.js", "preview",
                                   "--host", "127.0.0.1", "--port", "4173", "--strictPort"],
                                  cwd=ROOT / "frontend", stdout=output, stderr=subprocess.STDOUT)
        try:
            for _ in range(100):
                if server.poll() is not None:
                    raise RuntimeError("Preview server failed; inspect preview-server.txt")
                try:
                    with urlopen("http://127.0.0.1:4173", timeout=1): break
                except OSError: time.sleep(0.1)
            else: raise RuntimeError("Preview server did not start")

            with sync_playwright() as playwright:
                browser = playwright.chromium.launch()
                context = browser.new_context(reduced_motion="reduce")
                context.route("**/api/**", api_fixture)
                context.route("https://bible-api.com/**", bible_fixture)
                page = context.new_page()
                page.set_default_timeout(15000)
                errors = []
                page.on("pageerror", lambda error: errors.append(str(error)))
                # Retain actionable evidence even when the first control fails.
                page.goto("http://127.0.0.1:4173")
                page.screenshot(path=EVIDENCE / "initial-home.png", full_page=True)
                page.get_by_role("button", name="Open the Bible", exact=True).wait_for()
                for width in (360, 390, 768, 1024, 1440):
                    page.set_viewport_size({"width": width, "height": 900})
                    assert page.evaluate("document.documentElement.scrollWidth <= window.innerWidth"), width
                opener = page.get_by_role("button", name="Open the Bible", exact=True)
                opener.click()
                dialog = page.get_by_role("dialog", name="Read the Bible", exact=True)
                dialog.wait_for()
                dialog.get_by_text("For God so loved the world,", exact=False).wait_for()
                for _ in range(12):
                    page.keyboard.press("Tab")
                    assert page.evaluate("document.activeElement.closest('dialog') !== null")
                page.keyboard.press("Escape")
                dialog.wait_for(state="detached")
                assert opener.evaluate("element => element === document.activeElement")
                page.get_by_role("button", name="SW", exact=True).click()
                page.get_by_role("button", name="Fungua Biblia", exact=True).click()
                sw_dialog = page.get_by_role("dialog", name="Soma Biblia", exact=True)
                sw_dialog.get_by_role("button", name="Ongeza ukubwa wa maandishi", exact=True).wait_for()
                page.screenshot(path=EVIDENCE / "kiswahili-bible.png", full_page=True)
                page.keyboard.press("Escape")
                assert not errors, errors
                browser.close()
        finally:
            server.terminate()
            try: server.wait(timeout=10)
            except subprocess.TimeoutExpired: server.kill(); server.wait()
    (EVIDENCE / "result.json").write_text(json.dumps({
        "result": "PASS", "scope": "Built React with API/Bible fixtures; not live E2E or RLS",
        "checks": ["five viewport widths", "native modal focus containment", "Escape",
                   "opener focus restoration", "English/Kiswahili controls", "no page errors"]
    }, indent=2), encoding="utf-8")
    print("PASS: built-React browser contracts with explicit fixtures; live E2E remains separate")


if __name__ == "__main__":
    run()
