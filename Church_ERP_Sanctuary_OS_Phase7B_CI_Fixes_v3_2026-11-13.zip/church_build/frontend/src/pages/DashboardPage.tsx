import { useEffect, useState } from "react";
import { api, downloadFile } from "../lib/api";
import { Dashboard, T } from "../lib/types";
import "./Workspace.css";

interface Props { locale: string; t: T; caps: Set<string>; onNavigate: (section: string) => void }
const number=(n:number)=>new Intl.NumberFormat("en-US").format(Math.round(n));
const money=(n:number,currency:string)=>`${currency} ${number(n)}`;

export function DashboardPage({locale,t,caps,onNavigate}:Props) {
  const [d,setD]=useState<Dashboard|null>(null);
  const [error,setError]=useState("");
  const sw=locale==="sw";
  useEffect(()=>{api<Dashboard>("/reports/dashboard").then(setD).catch(e=>setError(e.message));},[]);
  if(error)return <div className="workspace-alert" role="alert">{sw?"Taarifa hazipatikani kwa sasa.":"Dashboard information could not be loaded."} {error}</div>;
  if(!d)return <div className="workspace-alert" role="status">{sw?"Inapakia taarifa za kanisa...":"Loading church overview..."}</div>;
  const cards=[
    {title:sw?"Waumini wote":"Our members",val:number(d.members_total),desc:sw?"Waliosajiliwa":"Registered members",icon:"♙",nav:"members"},
    {title:sw?"Maombi yanayosubiri":"Needs attention",val:number(d.requests_pending),desc:sw?"Maombi ya huduma":"Service requests",icon:"✦",nav:"requests"},
    ...(caps.has("view_finance") ? [{title:sw?"Salio la fedha":"Financial balance",val:money(d.finance.net,d.finance.currency),desc:sw?"Mapato ukitoa matumizi":"Income minus expenses",icon:"≋",nav:"finance"}] : []),
    ...(caps.has("manage_assets") ? [{title:sw?"Thamani ya mali":"Church assets",val:money(d.assets.total_value,d.finance.currency),desc:sw?"Thamani iliyorekodiwa":"Recorded value",icon:"◇",nav:"assets"}] : []),
  ];
  const actions=[{icon:"♙",title:sw?"Angalia waumini":"View members",desc:sw?"Taarifa na usajili":"Records & registrations",nav:"members"},
    {icon:"◉",title:sw?"Shughulikia maombi":"Review requests",desc:sw?"Maombi yanayosubiri":"Pending service requests",nav:"requests"},
    ...(caps.has("view_finance") ? [{icon:"⌁",title:sw?"Angalia ripoti":"Review finances",desc:sw?"Mapato na matumizi":"Income & expenses",nav:"finance"}] : [])];
  const max=Math.max(1,...d.members_by_unit.map(m=>m.count));
  return <div className="workspace">
    <section className="workspace-welcome"><div><span className="workspace-kicker">✳ {sw?"MUHTASARI WA KANISA":"YOUR CHURCH AT A GLANCE"}</span><h1>{sw?"Karibu kwenye kazi ya leo.":"Let's care for our community."}</h1><p>{sw?"Taarifa muhimu, kazi zinazohitaji uangalizi, na hatua za kuchukua—mahali pamoja.":"The most important numbers, people and next steps. All in one place."}</p></div><span className="workspace-welcome-emblem" aria-hidden="true">✝</span></section>
    <div className="workspace-stats">{cards.map((c,i)=><button key={c.nav} onClick={()=>onNavigate(c.nav)} className={i===1&&d.requests_pending>0?"workspace-stat attention":"workspace-stat"}><span className="workspace-stat-icon">{c.icon}</span><span className="workspace-stat-title">{c.title}</span><strong>{c.val}</strong><span className="workspace-stat-bottom">{c.desc}<b>↗</b></span></button>)}</div>
    <section className="workspace-actions"><div className="workspace-section-title"><span>01 / {sw?"FANYA KAZI":"QUICK ACTIONS"}</span><h2>{sw?"Ungependa kufanya nini?":"What would you like to do?"}</h2></div><div className="workspace-action-grid">{actions.map(x=><button key={x.nav} onClick={()=>onNavigate(x.nav)}><span className="workspace-action-icon">{x.icon}</span><span><strong>{x.title}</strong><small>{x.desc}</small></span><b>→</b></button>)}</div></section>
    <div className="workspace-lower"><section className="workspace-card"><div className="workspace-card-heading"><span>02 / {sw?"JUMUIYA":"COMMUNITY"}</span><h2>{sw?"Waumini kwa maeneo":"Members by church unit"}</h2><p>{sw?"Idadi ya waumini katika kila eneo.":"How your congregation is distributed."}</p></div>{d.members_by_unit.length>0?d.members_by_unit.slice(0,9).map(unit=><div className="workspace-bar" key={unit.name}><div><span>{unit.name}</span><strong>{number(unit.count)}</strong></div><div className="workspace-bar-rail"><span style={{width:`${Math.max(unit.count>0?2:0,unit.count/max*100)}%`}}/></div></div>):<p className="workspace-placeholder">{sw?"Hakuna takwimu za waumini bado.":"Member statistics will appear here."}</p>}</section>
    <section className="workspace-card"><div className="workspace-card-heading"><span>03 / {sw?"RIPOTI":"REPORTS"}</span><h2>{sw?"Takrima ya kanisa":"Church records"}</h2><p>{sw?"Pakua nakala za taarifa za kanisa.":"Keep a clear copy of your records."}</p></div><div className="workspace-report-links"><button onClick={()=>downloadFile("/reports/members.csv","members.csv")}>♙ <span>{t("members")} CSV</span><b>↓</b></button>{caps.has("view_finance") && <button onClick={()=>downloadFile("/reports/finance.csv","finance.csv")}>≋ <span>{t("finance")} CSV</span><b>↓</b></button>}<button onClick={()=>downloadFile("/reports/sacraments.csv","sacraments.csv")}>✦ <span>{t("sacramentalRecord")} CSV</span><b>↓</b></button></div><div className="workspace-reminder"><strong>✣ {sw?"Kumbusho":"A little reminder"}</strong><p>{sw?"Taarifa za waumini ni za siri. Zishirikishe kwa watu wenye ruhusa tu.":"Member data is private. Share exported records only with authorized people."}</p></div></section></div>
  </div>;
}
