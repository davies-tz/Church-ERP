import { useEffect, useRef, type ReactNode } from "react";

// Native modal semantics make the background inert and restore opener focus.
// Explicit Tab wrapping also avoids the browser chrome focus stop at each end.
export function ModalDialog({ className, label, labelledBy, onClose, children }: {
  className: string;
  label?: string;
  labelledBy?: string;
  onClose: () => void;
  children: ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const close = useRef(onClose);
  close.current = onClose;

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    const overflow = document.body.style.overflow;
    dialog.showModal();
    document.body.style.overflow = "hidden";
    return () => {
      dialog.close();
      document.body.style.overflow = overflow;
    };
  }, []);

  return <dialog ref={ref} className={className} aria-label={label} aria-labelledby={labelledBy}
    onKeyDown={event => {
      if (event.key !== "Tab") return;
      const dialog = event.currentTarget;
      const controls = Array.from(dialog.querySelectorAll<HTMLElement>(
        'button:not(:disabled), a[href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])'
      )).filter(element => element.tabIndex >= 0 && element.getClientRects().length > 0);
      const first = controls[0], last = controls[controls.length - 1];
      if (!first) { event.preventDefault(); dialog.focus(); return; }
      if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog)) {
        event.preventDefault(); last.focus();
      } else if (!event.shiftKey && (document.activeElement === last || document.activeElement === dialog)) {
        event.preventDefault(); first.focus();
      }
    }}
    onCancel={event => { event.preventDefault(); close.current(); }}
    onMouseDown={event => { if (event.target === event.currentTarget) close.current(); }}>
    {children}
  </dialog>;
}
