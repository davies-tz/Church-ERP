# Church ERP

Multi-tenant, white-label church ERP platform. Each denomination/country is a
**tenant**; every church, diocese, region, or district it contains is an **org
unit** inside that tenant's own configurable hierarchy. Access is enforced by
PostgreSQL Row-Level Security, not just application code.

- Backend: FastAPI + SQLAlchemy 2.0 (async) + Alembic + PostgreSQL
- Frontend: React + Vite + TypeScript (per-tenant theming)
- Object storage: MinIO (S3-compatible) — member photos, certificates, verification documents
- Tenancy: shared DB + RLS; each tenant reached by subdomain (`grace.localhost`) or `?tenant=`/`X-Tenant-Slug`

## Current progress — green ticks only after acceptance tests

| Platform phase | Status |
|---|---|
| 5 People, families & governance | ⏳ Planned |
| 6 Financial expansion | ⏳ Planned |
| 7A Homepage & sermon studio | ⚠️ Source implemented, integration tests pending |
| **7B Independent church websites** | **🔄 In progress — domain/site code and editor implemented; live tests pending** |
| 8A Real Bible & role-aware dashboard | ⚠️ Source implemented, full validation pending |
| 8B Scripture & accessible UX | ⏳ Planned |
| 9 Documents, ID & communication | ⏳ Planned |
| 10 Security & pilot release | ⏳ Planned |
| 11 Worship planning & volunteers | ⏳ Planned |
| 12 Mobile member journey | ⏳ Planned |
| 13 Analytics & platform operations | ⏳ Planned |

**✅ means the entire phase is finished and all defined acceptance checks have passed.** No active phase is marked green prematurely.

### Phase 7B — What has been built

- `backend/alembic/versions/0019_church_sites.py`: tenant/org-unit site records and domain verification records.
- `backend/app/api/routes/church_sites.py`: public domain-resolution and per-site sermon APIs, admin website/editor APIs, DNS TXT verification.
- `frontend/src/pages/ChurchWebsitePage.tsx`: church website settings + domains (only for leaders with `manage_structure`).
- `frontend/src/App.tsx` and `frontend/src/pages/PublicHome.tsx`: resolve church by verified hostname; keep public sermons and opt-in public announcements scoped to that exact site.
- `backend/alembic/versions/0020_public_bulletins.py`: explicit opt-in to publish notices; all existing notices remain private.
- `GET /sites/public/notices`: up to five announcements from this church or its parent offices, never siblings; no publisher details.
- Local examples **after migration and seed**: `http://localhost:5173/?site=grace.localhost` and `http://localhost:5173/?site=stmarks.localhost`.
- Domain ownership is proved using a TXT record named `_sanctuary.<your-domain>` before public access. You must separately point DNS to your hosting provider and configure HTTPS. `.localhost` is for development only.

**Not finished:** Full Docker integration testing, production DNS/HTTPS configuration, security review, accessibility audit and legacy tenant registration policy. See `PHASE7B_DELIVERY_NOTES.md` and `TESTING.md`.


### 7 November 2026 — Phase 7B public bulletin publishing (current increment) 🔄

**Built in code, not production-verified:**

- Added migration `0020_public_bulletins.py`: announcements have `is_public` with a **false** database default. All existing and future notices stay private unless an authorized editor explicitly opts into public display.
- The staff announcement form includes an English/Kiswahili public-visibility checkbox (off by default), with an explanation of who can read the notice.
- Verified church homepages now show a small editorial updates section only when actual public notices exist. No placeholder notices or tenant directory.
- New `GET /sites/public/notices?hostname=<current-host>` verifies the request Host + published site, then applies tenant RLS and selects at most five deliberately public notices from the exact site unit or ancestor units. No sibling notices, internal-only announcements, publisher identity or internal org identifiers are returned. Parent-unit propagation is explicit opt-in on the publication itself.
- Added PostgreSQL integration assertions to `backend/tests/test_church_sites.py` for private/public, same-tenant sibling, cross-tenant and hostname-spoof isolation, plus database-free boundary and schema checks in `scripts/test_public_bulletins.py`.

**Offline checks passed:** `python -m compileall`, `python scripts/test_public_bulletins.py`, existing DNS and media checks, and TypeScript/TSX transpile-parsing. **Not verified:** PostgreSQL integration, RLS, full npm production build, deployment, accessibility/user acceptance. Full frontend installation was blocked by missing npm packages (offline cache incomplete); PostgreSQL/Docker are unavailable here.

**Do not award Phase 7B ✅** until the required integration and acceptance gates pass. Status stays 🔄.

## START HERE — research-led product direction (7 November 2026)

**[Full build phases + acceptance criteria (Phases 5–13)](BUILD_PHASES_2026_2027.md)** is the current canonical roadmap. The earlier `ROADMAP_MEMBER_PORTAL.md` is retained as the **historic member-portal phases** (MP1–MP6); do not confuse those numbers with the expanded platform phases.

The product is **multi-tenant backstage, independently branded for visitors**: no global church catalog on a congregation's homepage. The current source supports *tenant-level* branding and published sermons. **Phase 7B source is now under construction:** verified domain → tenant + org unit, site-only public sermons, and an editable church website profile. Not production-tested; see the current sprint status below.

Research input: Planning Center (services, work hub, check-ins, publishing, groups and calendar); Breeze/Tithely (people, groups, events and forms); MyChurchIT (hierarchy); ChurchCMS (media, mobile and giving); Subsplash (cohesive member journeys); YFM (media-first discovery). These are functional references, not copied layouts. See [`DESIGN_SYSTEM.md`](DESIGN_SYSTEM.md) for original palette, screen sizes and accessibility rules.

**Working code in this package:** responsive public site with two theme variants; sermon links/upload/publishing source; animated Bible opening to a real read-only English WEB chapter reader; role-adaptive dashboard and **Easy view / Mwonekano rahisi** with larger buttons. Finance and asset dashboard links are now hidden without corresponding capabilities; backend permissions still require testing. The latest offline smoke tests are in `scripts/` and the limits are recorded in [`TESTING.md`](TESTING.md).

**Current engineering sprint:** Apply migration `0019_church_sites` and `0020_public_bulletins`, run Docker integration tests, verify domain routing and tenant boundaries, and finish Phase 7B operational hardening. A static preview is not evidence of a running production app.

See [`ROADMAP_MEMBER_PORTAL.md`](ROADMAP_MEMBER_PORTAL.md) for the original member-portal implementation history.

---

## Running it in Docker

This is the only supported way to run the full stack — `docker-compose.yml`
wires together 5 services: Postgres, Redis, MinIO, the FastAPI backend, and the
Vite frontend.

### 1. First-time setup

```bash
cd church-erp
cp .env.example .env
docker compose up --build
```

On startup the backend container automatically:
1. runs `alembic upgrade head` (applies every migration),
2. runs `python -m app.seeds.seed` (seeds two demo tenants with sample data — safe to re-run, it's idempotent),
3. starts `uvicorn` with `--reload`.

Once it's up:

| Service | URL |
|---|---|
| Frontend | http://localhost:5173 |
| Backend API | http://localhost:8000 (interactive docs at `/docs`) |
| MinIO console | http://localhost:9001 (`minio` / `minio12345`) |
| Postgres | `localhost:5432` (`postgres`/`postgres`, db `church_erp`) |

### 2. Everyday commands

```bash
docker compose up -d          # start in the background
docker compose logs -f backend    # tail one service's logs
docker compose restart frontend   # Vite's file-watcher over the Windows→Linux
                                   # volume mount is unreliable; restart after
                                   # editing frontend code if hot-reload doesn't pick it up
docker compose down           # stop everything, keep data
docker compose down -v        # stop and WIPE all data (Postgres + MinIO volumes)
```

> **Windows note:** `docker compose down -v` (or plain `down`) stops *every*
> service, including the frontend — bring it back with
> `docker compose up -d frontend`; `restart` won't recreate a removed container.

### 3. Try the multi-tenant white-labeling

Two seeded churches with different branding:

- http://localhost:5173/?tenant=grace   → "Grace Community Church" (purple)
- http://localhost:5173/?tenant=stmarks → "St. Mark's Parish" (green)

Seeded login for both: `admin@<tenant>.local` / `password`

(In production, tenants are reached by subdomain: `grace.churcherp.app`.
Locally, pass the tenant via `?tenant=<slug>` query param, the
`X-Tenant-Slug` header, or `grace.localhost:5173`.)

### 4. Run the test suite

```bash
docker compose exec backend pytest -v
```

`tests/test_tenant_isolation.py` proves that with tenant B's context set, a
query **cannot** read tenant A's rows — enforced by Postgres RLS, not app
code. No feature ships until this passes.

### 5. Environment variables (`.env`)

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | asyncpg connection string — always the non-superuser `church_app` role, never a superuser (RLS is bypassed by superusers/`BYPASSRLS` roles) |
| `REDIS_URL` | Redis connection |
| `JWT_SECRET` | HMAC signing key for access tokens — **change in production** |
| `JWT_EXPIRE_MINUTES` | token lifetime |
| `BASE_DOMAIN` | production wildcard domain used for subdomain tenant resolution |
| `CORS_ORIGINS` | comma-separated allowed origins |
| `MINIO_*` | endpoint/keys/bucket — set directly in `docker-compose.yml` for the containerized stack |

### 6. Running the backend without Docker (optional)

Requires Python 3.12 and a reachable Postgres.

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
alembic upgrade head
python -m app.seeds.seed
uvicorn app.main:app --reload
```

### `.claude/launch.json` dev-server shortcuts

The project root (one level above `church-erp/`) has a `.claude/launch.json`
with two named configs you can launch from Claude Code's dev-server picker:

- **web (full stack)** — `docker compose -f church-erp/docker-compose.yml up` (port 5173)
- **api (backend only)** — same, but only `db redis minio backend` (port 8000)

---

## Sanctuary Edition — 7 Nov 2026 (creative website + real sermon MVP)

The multi-tenant ERP now has an original editorial church homepage and a role-aware workspace. New files include `frontend/src/pages/PublicHome.*`, `frontend/src/components/BibleReader.tsx`, `frontend/src/pages/SermonsManager.*`, `frontend/src/pages/Workspace.css`, `backend/app/api/routes/sermons.py`, `backend/app/models/sermon.py`, and Alembic `0018_sermons.py`.

- **Tenant-specific website:** Grace uses a forest palette; St. Mark's a terracotta palette. Each site shows **only its own branding and published sermons**, not all platform churches. `?tenant=` is **for local demo only**.
- **Real sermon content, not placeholder:** a `manage_media` permission grants church-scoped uploading of MP3/WAV/OGG/MP4/WebM (max 25 MiB) or registration of an HTTPS YouTube/Vimeo/SoundCloud link. Uploads start as **draft**, require an explicit **Publish** action, can be featured/archived, and become publicly playable only while published. Database tables enforce per-tenant PostgreSQL RLS; uploaded files use per-tenant MinIO prefixes.
- **Read-only real Bible:** animated book cover opens a reader that loads authentic **World English Bible** text from `bible-api.com/data/web`; book/chapter navigation, chapter-word filtering and font adjustment. Translation is English; Kiswahili interface does not mean a licensed Swahili Bible is provided. Internet is required for uncached chapters.
- **Role-aware workspace:** staff see action-led metrics; ordinary members see plain-language service, announcement and sermon shortcuts. Login storage keys are tenant-scoped even when the demo uses one localhost origin.
- **UX standards:** WCAG 2.2 AA contrast targets, visible focus, no video autoplay, responsive mobile layouts, readable typography, reduced-motion support.

New documentation: [`DESIGN_SYSTEM.md`](DESIGN_SYSTEM.md) (competitor lessons, colours, information hierarchy and acceptance criteria), [`TESTING.md`](TESTING.md) (what was and was **not** tested), and the extended [`ROADMAP_MEMBER_PORTAL.md`](ROADMAP_MEMBER_PORTAL.md).

**Current gaps:** site identity is **per tenant** rather than a distinct branded public homepage for *each parish/branch org unit*. Verified custom-domain mapping and parish-level websites are Phase 7B. Media virus scanning/transcoding/CDN, full mobile/screen-reader testing and production deployment are not completed. Do **not** deploy this demo as a public production service without the security and accessibility reviews listed in the testing guide.

### Apply updates locally

```powershell
cd "C:\Users\HomePC\Desktop\Church_ERP-main"
# Copy these source updates into the existing project, keep your current .env & Docker volumes.
docker compose up -d --build
docker compose exec backend alembic upgrade head
docker compose exec backend pytest tests/test_sermons.py -v
```

Visit `http://localhost:5173/?tenant=grace` (or `?tenant=stmarks`). Login using your **local demo credentials only**. If granted media permissions, open **Sermons** in the dashboard, create a draft and publish it. Reload the public home to view the real published media.

---

## Role-Based Access Control (RBAC)

Authorization is **role (function) × org unit (scope)**. A role like `admin`
means "diocese admin" when assigned at a diocese and "parish admin" when
assigned at a parish — there's no per-denomination explosion of role names.

### How it works

1. **Hierarchy**: each tenant defines its own `HierarchyLevelType`s (e.g.
   Country → Region → Diocese → Parish), and every `OrgUnit` stores a
   materialized path (`/root/child/self/`) so "does scope X cover unit Y" is
   just a string-prefix check.
2. **Assignment**: a user is granted a `role_key` at a specific `OrgUnit` (or
   tenant-wide, scope `/`) via the `Assignment` model.
3. **Capability check**: `authz.can(grants, CAPABILITY, target_path)` returns
   true if *any* active assignment grants that capability with a scope that
   is a prefix of the target path.

### Capabilities (`backend/app/domain/authz.py`)

| Capability | Meaning |
|---|---|
| `manage_structure` | create/edit org units, batch-import churches |
| `manage_members` | register/edit members, verify membership, run the verification queue |
| `manage_sacraments` | record baptisms/marriages/etc. |
| `manage_assets` | register and maintain church assets/inventory |
| `record_finance` | enter finance transactions |
| `view_finance` | view finance reports/entries |
| `view_reports` | view the dashboard/reports center |
| `approve` | approve pending service requests / finance entries (maker-checker: whoever recorded an entry can't approve it) |
| `appoint` | assign roles to members (provisions a login if the appointee has none yet) |

### Role catalog

| Role | Capabilities |
|---|---|
| `tenant_admin` | everything — this is the single Country/Denomination-level Super Admin who registers all churches top-down and issues cascading access |
| `admin` | same capability set as `tenant_admin`, but scoped to whatever unit they're assigned at (e.g. a diocese admin) |
| `pastor` | `manage_members`, `manage_sacraments`, `approve` — sacraments are pastoral acts |
| `secretary` | `manage_members` |
| `treasurer` | `record_finance`, `view_finance` |
| `member` | no elevated capabilities — self-service only (own profile, own requests, own contributions) |

### Key rules enforced in code, not just labels

- **"A leader must already be a member" rule**: appointing someone to a
  leadership role requires them to already be a `Member` whose org unit lies
  within the target scope. If they have no login yet, appointment
  auto-provisions one and returns a one-time `temp_password` shown once to the
  admin doing the appointing.
- **Verification gating**: an unverified member is blocked (HTTP 403) from
  self-requesting privileged sacramental services (e.g. marriage) until a
  leader with `manage_members` approves their verification request.
- **Scoped document/record access**: e.g. a verification document can be
  viewed by the member who owns it, or by anyone whose `manage_members`
  scope covers the routing path (the church where they were baptized, or
  their current church).
- **Self vs. admin editing**: a member can always edit their own profile and
  upload their own photo; editing someone else's requires `manage_members`
  scoped to that member's church.

---

## Password & Login Features

- **Show/hide password toggle** on the login screen (`frontend/src/pages/Login.tsx`).
- **Change password** (`🔑` icon in the app header, any logged-in user):
  `POST /auth/change-password` — requires the current password, hashed with
  Argon2 via `passlib`.
- **Self-registration** (`POST /auth/register`, public, no auth required):
  a prospective member fills in full demographic info, picks their church from
  a dropdown, and is logged in immediately with limited (`unverified`) access.
  To unlock privileged services they upload a certificate (e.g. baptism),
  which routes to the leaders of the church where it happened for review and
  approval.
- **Temporary passwords on appointment**: when an admin appoints a member who
  has no existing login, the system generates a random temporary password
  (`secrets.token_urlsafe(6)`), creates their `User` record, and displays the
  temp password once in the UI so the admin can hand it to the new leader.
- All passwords are hashed with **Argon2** (`app/core/security.py`) — never
  stored or logged in plaintext.

---

## Product vision update — November 2026

**One platform, independent church experiences.** This remains a multi-tenant ERP: each tenant has its own church-branded public homepage, sermons, navigation, login, dashboard, users, and protected data. **Never display all tenant churches on a shared church homepage.** A platform-level operator console (if introduced) must be a separate, restricted interface. Resolve tenant identity by verified host/subdomain; `?tenant=` is **development/demo only**. Never use client-supplied tenant identity alone for authorization.

### Build status

- **Started in this update:** responsive church-specific public homepage, interactive opening Bible (CSS/React illustration), clear sign-in and registration entry points, sermons section with truthful empty state, English/Swahili labels.
- **Not yet implemented:** real Bible text reader and licensed translations; sermon upload/publishing/storage/streaming and public listing; church-specific homepage content editor; role-adaptive dashboard redesign; independent production domains and production tenant routing.
- **Design direction:** editorial church identity, calm typography, accessible contrast, large touch targets, progressive disclosure, plain-language Swahili/English, icons **with labels**, keyboard access, reduced-motion support. Bible interaction is an **illustration**, not an editable or complete Bible. A real Bible reader needs a legitimate source/license and passage navigation.
- **Reference:** YFM's media-led home experience is inspiration for featured sermons/audio/video, not a template to copy.

### Delivery phases

| Phase | Scope | Acceptance criteria |
|---|---|---|
| 5 — Membership & governance | Families, leadership terms, attendance, meeting minutes, approval workflows | Unit-scoped permissions and audit trail tested |
| 6 — Finance & operations | Budgets, campaigns/projects, procurement, income-generating assets, financial reports | Accountant-only entry and reconciled totals |
| 7 — Tenant identity & public media | Per-church public site and domain, branding, sermons upload/review/publish, video/audio player, media permissions | Tenant A never exposes tenant B content; publish/unpublish works |
| 8 — Bible & accessible experience | Licensed Bible reader with book/chapter/verse navigation, Bible-opening animation, multilingual accessible public pages, role-adaptive dashboard | Readable on low-end phones; keyboard and screen-reader paths tested |
| 9 — Community tools | Documents, printable ID cards, SMS/email notices, member portal | File permissions, opt-in and delivery failures handled |
| 10 — Production hardening | RLS and IDOR testing, auth, backups, storage security, observability, deployment, tenant-domain verification | Automated isolation tests and restore drill pass |

See `ROADMAP_MEMBER_PORTAL.md` for original phases 1–6 and `PRODUCT_VISION_PHASES_2026.md` for implementation details.


### 7 November 2026 — Phase 7B hardening, still 🔄 (not ✅)

The latest source update binds domain-specific public APIs to the real HTTP Host, resolves verified domain → tenant before accepting a client tenant header, blocks broad legacy registration from church-specific domains, and prevents parish registration/sermon pages from displaying other churches. Vite now preserves the Host; database/cache/storage/admin ports bind to loopback for the local demo.

Offline validation: Python syntax, 41 TypeScript/TSX syntax parses, hostname/DNS-mock checks, media validation and six color-token contrast checks **passed**. Docker/PostgreSQL/RLS integration, full npm build, real DNS/HTTPS, security and user acceptance remain **unverified**. See `PHASE7B_SECURITY_AND_TEST_RESULTS.md` for exact commands and evidence. **Do not mark green ✅ yet.**

### 8 November 2026 build note

Phase 7B public bulletin scoping now validates that each published site's materialized hierarchy path terminates at its own unit ID; invalid paths fail closed. See `PHASE7B_PUBLIC_BULLETINS.md` and `BUILD_PHASES_2026_2027.md` for test evidence and unresolved acceptance gates. Phase 7B is still 🔄.

### 9 November 2026 — Phase 7B unscoped bulletin isolation 🔄

- Hardened `/sites/public/notices`: public announcements with `org_unit_id IS NULL` are **not** displayed on any independent parish website. Only explicitly public notices assigned to the verified site's exact org unit or a validated ancestor are eligible. This prevents a tenant-wide unscoped announcement from inadvertently reaching every parish homepage.
- Added an offline source-regression assertion in `scripts/test_public_bulletins.py`. Ran `python scripts/test_public_bulletins.py` (PASS: both checks) and `python -m compileall -q backend/app backend/tests scripts` (PASS). These checks do **not** exercise SQL execution or RLS.
- Environment: Docker executable unavailable; `asyncpg` unavailable; frontend `node_modules` absent. PostgreSQL/RLS integration, npm production build, DNS/TLS, and browser/accessibility acceptance **not verified**. Phase 7B remains 🔄.

## Latest Phase 7B source update — 9 November 2026 (🔄 not verified for release)

**Base:** `Church_ERP_Sanctuary_OS_Phase7B_Unscoped_Bulletin_Isolation_2026-11-09.zip` (not an older starter). This full source archive now contains Alembic revision **`0021_public_bulletin_descendants`**, database-verified hierarchy chain checks for public notices, and **separate, default-off descendant sharing** for parent church bulletins. Each church site's own publicly opted-in notices continue to appear. A parent's public notices no longer propagate by default. Private, unscoped, sibling and cross-tenant announcements remain excluded from independent site homepages.

The announcement editor offers an original EN/SW consent flow; verified sites retain church-specific branding and published sermons. The read-only World English Bible workflow is unchanged. The repo includes new PostgreSQL regression tests and a CI workflow **definition**, not a successful CI run. Exact checks and remaining blockers are in `PHASE7B_SECURITY_AND_TEST_RESULTS.md`, `evidence/2026-11-09_source_checks.txt` and `PHASE7B_ACCEPTANCE_RUNBOOK.md`.

**Status:** Phase 7B 🔄; PostgreSQL/Docker, frontend production build, real DNS/TLS, accessibility, domain E2E, backup/restore and operator/security acceptance have **not passed here**. To upgrade an **existing test install**, back up its database, then use `docker compose exec backend alembic upgrade head` (which includes migrations 0019, 0020, 0021 as needed). Do not downgrade the production DB to test rollback. Use non-demo credentials before any externally accessible deployment.
