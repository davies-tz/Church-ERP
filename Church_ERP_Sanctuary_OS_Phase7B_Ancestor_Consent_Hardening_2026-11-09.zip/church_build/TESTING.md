# Actual checks vs. pending checks — Sanctuary build

## Checks executed while preparing this package

- `python -m compileall -q backend/app backend/tests backend/alembic/versions` — Python syntax and import-file compilation (pass).
- TypeScript compiler `transpileModule` parse of all frontend `.ts` and `.tsx` files — TS/TSX syntax (pass). **Not a full typecheck**.
- Browser CSS visual QA screenshots using Chromium on a standalone HTML design preview — static design only; **not an end-to-end test of React**.
- Pure validation test for byte ranges, file signatures and allowed URLs via isolated module-function execution (see check logs, if available).

## Checks NOT executed here

Docker/Postgres/MinIO and Node dependencies are not installed in the execution environment. Consequently, no assertion is made that the full app deployed successfully or that the integration tests passed.

## On the user's Windows machine (Docker Desktop)

```powershell
cd "C:\Users\HomePC\Desktop\Church_ERP-main"
# Replace/merge with delivered source files, keep your previous .env and database volume.
docker compose up -d --build
docker compose exec backend alembic upgrade head
docker compose exec backend pytest tests/test_sermons.py -v
docker compose exec backend pytest -v
```

Browser demo: http://localhost:5173/?tenant=grace and http://localhost:5173/?tenant=stmarks . Log in as admin for the chosen tenant and go to **Sermons**. Upload a small MP3 or add a real YouTube URL; it starts as **draft**, so public homepage stays empty. Click **Publish**, refresh public home, verify the sermon card and playback. Then archive and verify the item disappears publicly.

## Mandatory manual acceptance tests

1. Open Grace and St. Mark's in separate private browser sessions. Confirm different branding, no global church directory and no cross-tenant sermons.
2. Add a **draft** in Grace: it does not appear publicly. Publish: it appears in Grace only. Archive: disappears. Test cross-tenant guessed media IDs return 404.
3. Upload a small real MP3 and play/pause/seek. Confirm HTTP `206 Partial Content` on range requests and `416` on invalid range.
4. Try uploading an `.html` file disguised as MP4 or a file over 25MB: request must fail. Try an invalid URL: request must fail.
5. Sign in to St. Mark's and check there is no inherited Grace login. A member cannot see the media editor or staff financial figures.
6. With no active database connection, public sermons show an honest offline state rather than invented content.
7. Open Bible by mouse, Tab/Enter and on touch; choose John 3, change chapter, search, zoom. With internet disabled, show connection error and eBible fallback.
8. At screen widths 360/390/768/1024/1440, ensure no horizontal overflow or truncated navigation. Repeat in English and Kiswahili.
9. Confirm readable contrast, focus indicators, 200% zoom and reduced-motion behavior. Run a screen reader pass on each dialog.
10. Test with real non-technical church members, not only developers. See `DESIGN_SYSTEM.md` for the guided usability script.


## Research-led iteration checks (7 November 2026)

**Executed successfully in this build:**

```bash
python scripts/check_design.py         # 6 core AA palette checks — PASS
python scripts/check_sermon_logic.py   # media magic, size, URL and byte ranges — PASS
python -m compileall -q backend/app backend/tests backend/alembic/versions  # syntax — PASS
```

**Attempted but not runnable here:**

- `cd frontend && npm run build` — **blocked**, because the current container's `node_modules` has empty/partial `@types` and React packages. `npm ci` timed out in the restricted environment. Re-run after a clean dependency install on the user's machine.
- `cd backend && pytest -q tests/test_sermons.py` — **blocked**, environment missing `asyncpg` and a Docker/PostgreSQL instance. The tests were not marked as passed.

**NEW manual acceptance checks:**

1. In admin dashboard, grant a role `view_reports` but not `view_finance`/`manage_assets`. Confirm finance, assets and finance CSV are absent; test API endpoints independently with that role.
2. Use **Easy view** with keyboard, on 360px device, and switch `?tenant=grace` to `?tenant=stmarks`: preference should be independently stored per tenant.
3. Test text color contrast for both public-site themes; the script covers only canonical token pairs, not every nested UI surface.
4. Check member navigation no longer includes privileged structure management without the permission.
5. Original preview images are **static samples**, not a pass for React, accessibility, API or Docker integration.

See `BUILD_PHASES_2026_2027.md` for the next source-building sprint and launch gates.


## Phase 7B implementation test report — 7 November 2026

**Executed in this environment:**

- `python scripts/test_church_site_logic.py` — **PASS**: normalizing hostnames, rejecting 11 malformed/unsafe domains, verifying DNS TXT (success/failure with mocked DNS).
- `python -m compileall -q backend/app backend/alembic/versions` — **PASS**, Python syntax only.
- TypeScript compiler `transpileModule` of **41** `.ts`/`.tsx` files — **PASS**, syntax parsing only (not a typecheck).

**Unavailable / NOT passed:**

- `npm ci` timed out because this execution environment could not fetch packages; a React production build was **not** completed.
- `pytest tests/test_church_sites.py` was **not** run because Python `asyncpg` and a PostgreSQL environment are unavailable here; test exists for Windows/Docker.
- Production domain DNS/TLS, registration server-side constraints, full UI/keyboard checks, performance, pen testing and backup/restore are outstanding.

**Run locally in Docker after applying the ZIP as a separate test copy:**

```powershell
docker compose up -d --build
docker compose exec backend alembic upgrade head
docker compose exec backend python -m app.seeds.seed
docker compose exec backend pytest tests/test_church_sites.py -v
docker compose exec backend pytest -v
```

**Browser checks:**

- `http://localhost:5173/?site=grace.localhost` is only Grace's public homepage.
- `http://localhost:5173/?site=stmarks.localhost` is only St. Mark's public homepage.
- Both demo domains are seeded as verified local-only mappings; they are not registered public websites.
- Sign in to Grace, navigate **Church websites / Tovuti za makanisa**; update the welcome text and verify the public page changes.
- Publish a sermon under a specific org unit, ensure only the matching site displays it; tenant-global sermon feed must not leak it.
- Confirm an unverified custom domain returns 404, verify TXT ownership, configure HTTPS in hosting, and then confirm the public endpoint resolves correctly.
- Check unauthenticated visitors cannot create/update sites and a scoped editor cannot manage another unit.


### 7 November 2026 — Phase 7B hardening, still 🔄 (not ✅)

The latest source update binds domain-specific public APIs to the real HTTP Host, resolves verified domain → tenant before accepting a client tenant header, blocks broad legacy registration from church-specific domains, and prevents parish registration/sermon pages from displaying other churches. Vite now preserves the Host; database/cache/storage/admin ports bind to loopback for the local demo.

Offline validation: Python syntax, 41 TypeScript/TSX syntax parses, hostname/DNS-mock checks, media validation and six color-token contrast checks **passed**. Docker/PostgreSQL/RLS integration, full npm build, real DNS/HTTPS, security and user acceptance remain **unverified**. See `PHASE7B_SECURITY_AND_TEST_RESULTS.md` for exact commands and evidence. **Do not mark green ✅ yet.**


### 7 November 2026 — Phase 7B public bulletin publishing (current increment) 🔄

**Built in code, not production-verified:**

- Added migration `0020_public_bulletins.py`: announcements have `is_public` with a **false** database default. All existing and future notices stay private unless an authorized editor explicitly opts into public display.
- The staff announcement form includes an English/Kiswahili public-visibility checkbox (off by default), with an explanation of who can read the notice.
- Verified church homepages now show a small editorial updates section only when actual public notices exist. No placeholder notices or tenant directory.
- New `GET /sites/public/notices?hostname=<current-host>` verifies the request Host + published site, then applies tenant RLS and selects at most five deliberately public notices from the exact site unit or ancestor units. No sibling notices, internal-only announcements, publisher identity or internal org identifiers are returned. Parent-unit propagation is explicit opt-in on the publication itself.
- Added PostgreSQL integration assertions to `backend/tests/test_church_sites.py` for private/public, same-tenant sibling, cross-tenant and hostname-spoof isolation, plus database-free boundary and schema checks in `scripts/test_public_bulletins.py`.

**Offline checks passed:** `python -m compileall`, `python scripts/test_public_bulletins.py`, existing DNS and media checks, and TypeScript/TSX transpile-parsing. **Not verified:** PostgreSQL integration, RLS, full npm production build, deployment, accessibility/user acceptance. Full frontend installation was blocked by missing npm packages (offline cache incomplete); PostgreSQL/Docker are unavailable here.

**Do not award Phase 7B ✅** until the required integration and acceptance gates pass. Status stays 🔄.

### Phase 7B test evidence — 8 November 2026

PASS: Python compileall; `scripts/test_public_bulletins.py` (including mismatched, repeated, empty and malformed hierarchy paths); `scripts/test_church_site_logic.py`; `scripts/check_sermon_logic.py`; `scripts/check_design.py` (6 contrast checks); `scripts/check_typescript_syntax.cjs` (41 syntax parses).
BLOCKED: `python -m pytest -q backend/tests/test_church_sites.py` failed at collection (`ModuleNotFoundError: No module named 'asyncpg'`). Docker is unavailable; frontend node_modules absent. PostgreSQL/RLS, migrations, frontend production build, HTTPS, browser/E2E and accessibility remain unverified.

### 9 November 2026 — Phase 7B verified ancestry + separate descendant consent 🔄

The previous Phase 7B source treated `is_public=True` at any ancestor as permission to appear on **all** descendant parish websites. This increment changes that conservative default:

- Migration `0021_public_bulletin_descendants.py` adds `announcements.show_on_descendant_sites BOOLEAN NOT NULL DEFAULT FALSE`. Existing parent notices stay public **on their own church sites only**; no historical bulletin is automatically broadcast to child sites.
- `public_notice_unit_predicate()` selects public notices for the exact site unit, **or** public ancestor notices with `show_on_descendant_sites=True`. Sibling, tenant-wide NULL-scoped, private and cross-tenant announcements are excluded.
- `verified_ancestor_unit_ids()` checks each materialized ancestor path against actual `OrgUnit.id`, `parent_id`, `tenant_id` and canonical `path` rows under tenant RLS. If an ancestor is missing, belongs to a different tenant, or a parent link/path is inconsistent, the endpoint fails closed with HTTP 404.
- Authorized staff now have **two separate opt-in checkboxes** in English/Kiswahili: public on selected church website; additionally share with descendant church websites. The second checkbox is available only for a selected unit and is off by default. Institution-wide notices remain internal in this UI.
- Added PostgreSQL regression cases for parent consent, sibling and other-tenant isolation, unscoped notices, spoofed Host and a forged hierarchy path. Added offline pure-function and SQL-expression compilation checks. React public-home component is keyed by site identity to avoid stale demo-site state.
- Added `.github/workflows/phase7b-gates.yml` to **define** future PostgreSQL 16 RLS integration and full React production-build checks. The workflow has not been executed or reported green.

**Executed locally (evidence in `evidence/2026-11-09_source_checks.txt`):** Python `compileall` PASS, bulletin logic/consent/SQL compilation PASS, hostname/DNS-mock PASS, media check PASS, 6 approved contrast-token checks PASS, 41 TS/TSX transpile syntax checks PASS. This is **not** a PostgreSQL, TypeScript type-check, Vite build or domain acceptance pass.

**Blocked/unverified:** PostgreSQL integration could not collect tests (`ModuleNotFoundError: asyncpg`); no Docker binary; offline `npm ci` missing cached `yallist-3.1.1.tgz` (`ENOTCACHED`), so no production bundle. DNS/HTTPS, accessibility, editor E2E, backups and rollback remain unverified. **Phase 7B remains 🔄. Do not start Phase 8B on the assumption this phase is complete.**

See `PHASE7B_ACCEPTANCE_RUNBOOK.md` for remaining automatic and manual release gates.
