# Sanctuary Edition — Creative Product & Design System

Updated: 7 November 2026. This is an original visual direction informed by church-management usability research, **not a replica of any competitor's UI**.

## Reference insights applied

| Reference | Useful principle | Our independent implementation |
|---|---|---|
| MyChurchIT | Individual, denominational and ministry-level workflows; accessible finance | Scoped RBAC / hierarchy; future org-unit microsites, plain-language summaries |
| ChurchCMS | Sermons, media, member app, notifications, giving and QR check-in | Real sermon APIs + dashboard CMS; mobile-first planned for QR attendance |
| Subsplash | A unified church journey from first visit through digital engagement | One public church identity, joining/registering, media, scripture, member portal |
| Breeze / Tithely | Low-friction member directory, volunteer scheduling, role-specific dashboards | "Today at Church" actionable dashboards instead of a metrics wall |
| YFM (design inspiration only) | Media-led site, featured content and editorial rhythm | Sermon hero, audio/video tiles, embedded video and native upload playback |
| Planning Center | Worship planning, volunteer rotas, Calendar/Check-ins, Church Center member journeys and Home tasks | Phase 11 services/volunteers/rooms, Phase 12 mobile member journey; actionable staff dashboards |
| Breeze (now Tithely Church Management) | People, groups, events, forms, service planning and quick onboarding | Low-friction member workflows, Easy view, simpler forms and fewer privileged nav items |

Source reading: https://www.mychurchit.org/church-management-system/ · https://churchcms.app/ · https://www.subsplash.com/blog/church-management-software · https://www.breezechms.com/lp/best-church-management-software · https://www.planningcenter.com/ · https://www.planningcenter.com/home · https://www.planningcenter.com/church-center · https://www.breezechms.com/

## Brand language: **SANCTUARY / The living church**

Visual philosophy: A digital church should feel like a quiet and welcoming place, not like banking software. Combine expressive editorial typography with focused, clear and familiar controls. **Do not copy another church's photographic assets, branding or layout.**

### Palette & roles

| Token | Forest tenant | Purpose |
|---|---|---|
| Site deep | `#132B29` | high-contrast headers, hero and nav buttons |
| Site forest | `#1D433C` | structural accents, icons |
| Site paper | `#F7F5EF` | default reading and content surface |
| Site cream | `#EDE9DE` | secondary warm surfaces |
| Site gold | `#D8B878` | restrained sacred accent **on dark**, not small text on white |
| Text ink | `#1E3936` | headings and essential body text |
| Secondary body | `#5D6A64` | supplementary text on paper (5.19:1 on paper; recheck after theme changes) |
| Lines | `#DCDCD1` | dividers; not relied on alone to distinguish meaning |

St. Mark's demonstration uses the **terracotta** variant to prove churches need not have identical visual identities. Production theme variants require contrast approval before release. Use **60/30/10** layout distribution as a visual heuristic, not a mandatory rule: ~60% neutral reading surfaces, ~30% primary/deep, <10% gold accent. Reserve saturated red for errors, not ordinary buttons. No rainbow KPI cards.

### Typography & hierarchy

- Expressive serif for short headlines and scripture/feature headings; clean sans-serif for navigation, forms and data.
- Hero `clamp(54px, 5.6vw, 98px)`; section headings `clamp(40px, 4.5vw, 68px)`; default body ~14–16px with line-height 1.7–1.95.
- Meaningful content hierarchy: **one clear H1** per page, sections in H2, item titles H3.
- Never use color as the sole indicator of success, error, tab selection or urgency.

### Interaction and accessibility acceptance criteria

- Body text WCAG 2.2 AA contrast target **at least 4.5:1**; large headings **at least 3:1**; recheck every customized tenant theme. Text on images gets an opaque overlay when needed.
- Controls with large touch targets ~44 CSS pixels; visible keyboard focus; icon-only controls have an accessible label.
- Bible opening **decorative visual only**; actual chapter text fetched as **read-only** from the **World English Bible (public domain)**. Client has no edit tool. Motion disabled for `prefers-reduced-motion`; Bible remains clickable.
- Sermons **never autoplay** and are only available when published; meaningful empty/loading/offline states avoid fake church content.
- English and Kiswahili for essential journeys; labels understandable without ICT experience. A low-literacy usability study remains necessary.
- Responsive checkpoints to test: 360, 390, 768, 1024 and 1440px. Content cannot cause horizontal scrolling or clipped actions. Staff nav becomes horizontal scroll strip on small screens.
- Friendly errors with a next step, not raw exceptions; publish process is explicit **Draft → Publish → Archive**.
- Manual usability testing target: 5 members including low digital literacy + 2 church staff, on low-cost Android devices, without guidance. Measure completion of *open Bible*, *find sermon*, *join church*, *read announcement* and *submit service request*.

## Multi-tenancy contract

**One product, many independent churches.** Never render a global directory of tenant churches on a public tenant homepage. The global platform operator console is behind a separate authentication boundary. A tenant is resolved from its hostname in production, while `?tenant=grace`/`stmarks` is **a local demo convenience only**. All server private reads require JWT and RLS tenant scopes. Browser login tokens are separated by tenant slug even if local demos share the same origin.

**Important current gap:** Existing data model defines denomination/country as a tenant and individual parish/branches as org units. The public site is currently **per tenant**, not a independently branded site for every org unit. Phase 7B must add verified `church_site_domains` mapping (`hostname → tenant_id + org_unit_id`) and parish-specific site settings and media filtering. Never imply branch microsites already work.

## What is functional in this build

- Responsive original homepage with two approved design variants, accessible navigation and independent tenant branding.
- Animated opening Bible + read-only book/chapter reader through the public-domain WEB text API. Chapter loading needs internet; local offline full Bible pack is a future enhancement.
- Database-backed tenant-only sermon listing (only published media), featured message, audio/video tabs, native media playback, YouTube/Vimeo embed and external-link fallback.
- Authorized media studio: upload MP3/WAV/OGG/MP4/WebM up to 25MB or register an HTTPS trusted media link; draft/publish/archive, featured flag. No transcoding yet.
- Role-aware employee/member dashboard, with plain action buttons and real database figures (not fabricated metrics).
- PostgreSQL RLS on new sermons table and tenant-scoped auth; byte-range playback for small uploaded media files.

## Still required before launch

- Full browser and backend integration tests on an actual Docker database; this environment cannot run the Docker stack.
- File antivirus scanning, media transcoding, video CDN/streaming, thumbnail generator, content approvals and scheduled publishing.
- Independently branded parish/branch websites and custom domain ownership verification.
- Offline Bible pack; appropriate source rights for Kiswahili Bible translation. UI Kiswahili does **not** imply the WEB English Bible has been translated.
- Accessibility audit with keyboard/screen reader, contrast checker, low-end phone and slow 3G.
- GDPR/Tanzania privacy compliance review, stronger auth/2FA, per-tenant backup/restore, storage quotas, audit log for publishing, production secrets and https.


## New source-level UX improvement (7 November 2026)

- New tenant-scoped **Easy view / Mwonekano rahisi** switch in the top bar; it enlarges staff/member action targets and secondary text without removing features or changing authorization.
- Non-technical member navigation is reduced: no organization-structure admin screen unless the user's permission grants it.
- Finance and asset dashboard cards/downloads are hidden unless corresponding explicit capabilities are present. **Do not treat client-side hiding as backend security.**
- `#667671` secondary text on paper was **4.38:1**, below the ordinary-text AA target; changed to `#5D6A64` (**5.19:1**) and added reproducible test in `scripts/check_design.py`.
- The token contrast script tests core color pairs only. Entire UI still needs a proper automated + manual accessibility audit and contrast validation when tenant branding changes.
- Baseline original concept screens are stored in `design/preview-desktop.png`, `preview-tablet.png`, `preview-mobile.png`. These are **design samples**, not proof of production browser rendering.
