# Phase 7B — Independent Church Websites · Working increment

**Date:** 7 November 2026  
**Phase status:** 🔄 In progress (not eligible for ✅ until integration + acceptance checks pass).

## User journey

1. Visit a verified parish domain, e.g. `parish.example.org`.
2. Frontend calls `/api/sites/public?hostname=parish.example.org`; backend resolves the verified routing index and reads only the matched tenant/org-unit site profile.
3. React receives the public church name, welcome copy, worship times, place, theme and safe public metadata. It never displays a directory of other churches.
4. The sermon feed comes from `/api/sites/public/sermons?hostname=parish.example.org`; only matching unit's published sermons are visible. Media endpoints enforce the same scope.
5. A church leader with scoped `manage_structure` rights can update the page in **Church websites / Tovuti za makanisa**. Sermons are still published through **Sermons / Mahubiri** with scoped `manage_media` rights.

## Local demo (do not use for live users)

```powershell
# In the extracted Church_ERP folder, after creating .env from .env.example:
docker compose up -d --build
docker compose exec backend alembic upgrade head
docker compose exec backend python -m app.seeds.seed
docker compose exec backend pytest tests/test_church_sites.py -v
```

Preview only Grace: `http://localhost:5173/?site=grace.localhost`  
Preview only St. Mark's: `http://localhost:5173/?site=stmarks.localhost`

For a real address: add the public hostname in **Church websites**, publish the provided `TXT _sanctuary.<hostname>` value, select **Verify DNS**, point the domain to the HTTPS reverse proxy serving the React app + backend under `/api`, and check again. **DNS TXT ownership confirmation is not the same as DNS A/CNAME routing or TLS provisioning.**

## Security boundaries

- `church_sites` stores the `tenant_id` and `org_unit_id`, and its DB rows are RLS-protected.
- `church_site_domains` is a *public routing index* only, so it can be queried before knowing the tenant. It contains no private membership or finance data.
- A browser's requested hostname is only a *public lookup key*. It is never used as an authenticated credential; JWT + scoped grants authorize all writes.
- Uploaded recordings remain subject to existing media publisher permissions and draft/publish states.
- The old tenant-global sermon feed now includes tenant-global items only (`org_unit_id IS NULL`), not parish-specific recordings.
- A custom hostname without an owned, verified and published site returns **404**, rather than silently showing another church's brand.
- The self-registration view limits the church chooser to the current website's org unit. The new `/sites/public/register` endpoint **derives the unit server-side from the verified site**, ignoring user-supplied unit IDs. The separate legacy `/auth/register` remains tenant-level for backwards compatibility; a policy to disable direct tenant-level registration in site-only deployments is pending.
- Demo credentials and `.localhost` mappings are development-only. Rotate all secrets and disable seeded passwords before publishing.

## Phase completion gates (pending)

- PostgreSQL migration & RLS tests on both same-tenant/different-parish and different-tenant combinations.
- Domain verification failure/success via real DNS, then HTTPS and reverse-proxy routing.
- Content editor rights and full review of legacy tenant-level registration restrictions (the site-specific endpoint does enforce its own unit).
- Real uploaded/audio/video playback, unpublished content tests and 404 media scope.
- Screen reader/keyboard/English-Swahili usability tests and low-bandwidth performance.
- Backup/restore rehearsal and production privacy/security checklist.

See `BUILD_PHASES_2026_2027.md` for all Phases 5–13 and green-tick rules.


### 7 November 2026 — Phase 7B hardening, still 🔄 (not ✅)

The latest source update binds domain-specific public APIs to the real HTTP Host, resolves verified domain → tenant before accepting a client tenant header, blocks broad legacy registration from church-specific domains, and prevents parish registration/sermon pages from displaying other churches. Vite now preserves the Host; database/cache/storage/admin ports bind to loopback for the local demo.

Offline validation: Python syntax, 41 TypeScript/TSX syntax parses, hostname/DNS-mock checks, media validation and six color-token contrast checks **passed**. Docker/PostgreSQL/RLS integration, full npm build, real DNS/HTTPS, security and user acceptance remain **unverified**. See `PHASE7B_SECURITY_AND_TEST_RESULTS.md` for exact commands and evidence. **Do not mark green ✅ yet.**
