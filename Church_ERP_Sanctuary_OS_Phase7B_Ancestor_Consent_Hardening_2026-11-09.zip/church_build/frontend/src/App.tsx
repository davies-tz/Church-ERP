import { useEffect, useState } from "react";
import { getToken } from "./lib/api";
import { setRuntimeTenantSlug } from "./lib/tenant";
import { fetchPublicChurchSite, type PublicChurchSite } from "./lib/churchSites";
import { applyBranding, Branding, fetchBranding } from "./lib/branding";
import { getStoredLocale, storeLocale } from "./lib/locale";
import { Login } from "./pages/Login";
import { Register } from "./pages/Register";
import { AppShell } from "./AppShell";
import { PublicHome } from "./pages/PublicHome";

export default function App() {
  const [branding, setBranding] = useState<Branding | null>(null);
  const [authed, setAuthed] = useState<boolean>(false);
  const [churchSite, setChurchSite] = useState<PublicChurchSite | null>(null);
  const [mode, setMode] = useState<"home" | "login" | "register">("home");
  const [error, setError] = useState<string | null>(null);
  const [locale, setLocale] = useState<string>("en");

  useEffect(() => {
    // Resolve the visitor's verified church domain before tenant authentication.
    // No directory or other churches are shown on the public entrance.
    fetchPublicChurchSite()
      .then(async (site) => {
        if (site) setRuntimeTenantSlug(site.tenant_slug);
        const tenantBrand = await fetchBranding();
        const b = site ? {
          ...tenantBrand,
          display_name: site.display_name,
          tagline: site.tagline || tenantBrand.tagline,
        } : tenantBrand;
        if (site) setChurchSite(site);
        applyBranding(b);
        setBranding(b);
        setAuthed(!!getToken());
        setLocale(getStoredLocale(tenantBrand.default_locale));
      })
      .catch((e) => setError(e instanceof Error ? e.message : String(e)));
  }, []);

  function changeLocale(l: string) {
    storeLocale(l);
    setLocale(l);
  }

  if (error) return <div className="center muted" role="alert">{error}</div>;
  if (!branding) return <div className="center muted">Loading…</div>;

  if (authed)
    return (
      <AppShell
        branding={branding}
        churchSite={churchSite}
        locale={locale}
        onLocaleChange={changeLocale}
        onLogout={() => setAuthed(false)}
      />
    );

  return mode === "home" ? (
    <PublicHome key={churchSite?.id || branding.slug} branding={branding} churchSite={churchSite} locale={locale} onLocaleChange={changeLocale} onLogin={() => setMode("login")} onRegister={() => setMode("register")} />
  ) : mode === "register" ? (
    <Register
      churchSite={churchSite}
      branding={branding}
      locale={locale}
      onLocaleChange={changeLocale}
      onAuthed={() => setAuthed(true)}
      onSwitch={() => setMode("login")}
    />
  ) : (
    <Login
      branding={branding}
      locale={locale}
      onLocaleChange={changeLocale}
      onLogin={() => setAuthed(true)}
      onRegister={() => setMode("register")}
    />
  );
}
