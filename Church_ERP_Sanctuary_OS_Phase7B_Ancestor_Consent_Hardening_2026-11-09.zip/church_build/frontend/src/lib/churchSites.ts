export interface PublicChurchSite {
  id: string;
  tenant_slug: string;
  org_unit_id: string;
  hostname: string;
  display_name: string;
  tagline: string;
  welcome_message: string;
  service_times: string;
  location_label: string;
  contact_email: string;
  theme: "forest" | "terracotta";
}
export interface ChurchSiteDomain {
  id: string;
  hostname: string;
  verified_at: string | null;
  dns_record: string;
  dns_value: string;
}
export interface ManagedChurchSite {
  id: string;
  org_unit_id: string;
  display_name: string;
  tagline: string;
  welcome_message: string;
  service_times: string;
  location_label: string;
  contact_email: string | null;
  theme: "forest" | "terracotta";
  is_published: boolean;
  domains: ChurchSiteDomain[];
}
export function getSiteHostname(): string {
  const actual = window.location.hostname.toLowerCase();
  // Developer preview only; live sites are always determined by their actual domain.
  if (actual === "localhost" || actual === "127.0.0.1") {
    const requested = new URLSearchParams(window.location.search).get("site");
    if (requested && /^(grace|stmarks)\.localhost$/.test(requested)) return requested;
  }
  return actual;
}
export async function fetchPublicChurchSite(): Promise<PublicChurchSite | null> {
  const hostname = getSiteHostname();
  const res = await fetch(`/api/sites/public?hostname=${encodeURIComponent(hostname)}`);
  if (res.ok) return (await res.json()) as PublicChurchSite;
  if (res.status === 404 && (hostname === "localhost" || hostname === "127.0.0.1")) return null;
  if (res.status === 404) throw new Error("This church website has not been published on this domain.");
  throw new Error("Church site service is unavailable.");
}
