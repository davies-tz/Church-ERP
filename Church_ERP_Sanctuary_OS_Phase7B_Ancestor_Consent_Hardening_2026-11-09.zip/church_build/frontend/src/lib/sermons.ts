export interface Sermon {
  id: string;
  title: string;
  summary: string;
  speaker: string;
  language: string;
  media_kind: "audio" | "video";
  media_source: "upload" | "external";
  external_url: string | null;
  org_unit_id: string | null;
  status: "draft" | "published" | "archived";
  is_featured: boolean;
  created_at: string;
  published_at: string | null;
}
