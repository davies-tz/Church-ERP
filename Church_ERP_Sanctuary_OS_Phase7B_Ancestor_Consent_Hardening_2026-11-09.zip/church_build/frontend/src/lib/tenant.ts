// Work out which church this browser is visiting.
// Production: subdomain (grace.churcherp.app). Local dev: ?tenant=grace or
// grace.localhost:5173. Falls back to "grace" so the demo just works.
export function resolveTenantSlug(): string {
  const params = new URLSearchParams(window.location.search);
  const fromQuery = params.get("tenant");
  if (fromQuery && (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1")) {
    localStorage.setItem("tenant_slug", fromQuery);
    return fromQuery;
  }

  const host = window.location.hostname; // e.g. grace.localhost or grace.churcherp.app
  const parts = host.split(".");
  const isPlainHost = host === "localhost" || /^\d+\.\d+\.\d+\.\d+$/.test(host);
  if (!isPlainHost && parts.length > 1) {
    return parts[0];
  }

  return localStorage.getItem("tenant_slug") || "grace";
}

export let TENANT_SLUG = resolveTenantSlug();

// Set after the backend resolves a verified church hostname. Never derive tenant
// identity from an arbitrary custom-domain prefix such as parish.example.org.
export function setRuntimeTenantSlug(slug: string) {
  if (!/^[a-z0-9][a-z0-9-]{1,62}$/.test(slug)) throw new Error("Invalid tenant identifier");
  TENANT_SLUG = slug;
}

