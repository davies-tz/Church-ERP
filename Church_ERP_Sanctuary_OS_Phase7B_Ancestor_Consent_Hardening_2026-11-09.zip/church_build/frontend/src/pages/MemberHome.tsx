import { useEffect, useState } from "react";
import { api } from "../lib/api";
import { TENANT_SLUG } from "../lib/tenant";
import type { Sermon } from "../lib/sermons";
import "./Workspace.css";

export function MemberHome({locale,onNavigate}:{locale:string;onNavigate:(section:string)=>void}) {
  const sw=locale==="sw";
  const [sermons,setSermons]=useState<Sermon[]>([]);
  useEffect(()=>{api<Sermon[]>("/sermons/public").then(setSermons).catch(()=>{});},[]);
  const item=sermons[0];
  const url=item?.media_source==="external"?item.external_url:`/api/sermons/public/${TENANT_SLUG}/${item?.id}/media`;
  return <div className="workspace member-workspace">
    <section className="workspace-welcome"><div><span className="workspace-kicker">✳ {sw?"NYUMBANI KWAKO":"YOUR CHURCH HOME"}</span><h1>{sw?"Karibu tena, ndugu yetu.":"Welcome home, friend."}</h1><p>{sw?"Mahubiri, habari na huduma zako—kwa urahisi.":"Your church news, sermons, and services. Made simple."}</p></div><span className="workspace-welcome-emblem" aria-hidden="true">✝</span></section>
    <section className="workspace-actions"><div className="workspace-section-title"><span>01 / {sw?"HUDUMA ZAKO":"YOUR NEXT STEP"}</span><h2>{sw?"Unataka kufanya nini leo?":"What would you like to do today?"}</h2></div><div className="workspace-action-grid"><button onClick={()=>onNavigate("announcements")}><span className="workspace-action-icon">☷</span><span><strong>{sw?"Soma matangazo":"Church announcements"}</strong><small>{sw?"Taarifa mpya kutoka kanisani":"News from your church"}</small></span><b>→</b></button><button onClick={()=>onNavigate("requests")}><span className="workspace-action-icon">♡</span><span><strong>{sw?"Omba huduma":"Request a service"}</strong><small>{sw?"Huduma za kanisa":"Church services"}</small></span><b>→</b></button><button onClick={()=>onNavigate("members")}><span className="workspace-action-icon">♙</span><span><strong>{sw?"Taarifa zangu":"My profile"}</strong><small>{sw?"Angalia taarifa binafsi":"Your personal details"}</small></span><b>→</b></button></div></section>
    <section className="workspace-member-sermon"><div><span className="workspace-kicker">02 / {sw?"NENO LA LEO":"GROW IN FAITH"}</span><h2>{item?item.title:(sw?"Mahubiri mapya yataonekana hapa":"New sermons are coming")}</h2><p>{item?item.speaker:(sw?"Kanisa litakapochapisha mahubiri, utayaona hapa.":"When your church shares a sermon, you will see it here.")}</p></div>{item&&url&&<a href={url} target="_blank" rel="noopener noreferrer">{sw?"Sikiliza mahubiri":"Listen now"} ↗</a>}</section>
  </div>;
}
