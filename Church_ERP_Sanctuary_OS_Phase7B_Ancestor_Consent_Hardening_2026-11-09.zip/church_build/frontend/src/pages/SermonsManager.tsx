import { useEffect, useState, type FormEvent } from "react";
import { api, uploadForm } from "../lib/api";
import type { Sermon } from "../lib/sermons";
import type { PublicChurchSite } from "../lib/churchSites";
import "./SermonsManager.css";

type ChurchUnit = { id: string; name: string; level_key: string };
export function SermonsManager({ locale, churchSite }: { locale: string; churchSite: PublicChurchSite | null }) {
  const sw = locale === "sw";
  const [sermons, setSermons] = useState<Sermon[]>([]);
  const [units, setUnits] = useState<ChurchUnit[]>([]);
  const [mode, setMode] = useState<"link"|"file">("link");
  const [title, setTitle] = useState("");
  const [speaker, setSpeaker] = useState("");
  const [summary, setSummary] = useState("");
  const [unit, setUnit] = useState(churchSite?.org_unit_id || "");
  const [kind, setKind] = useState<"audio"|"video">("video");
  const [link, setLink] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const refresh = () => api<Sermon[]>("/sermons/manage").then(setSermons).catch(e => setError(e.message));
  useEffect(() => {
    void refresh();
    if (churchSite) {
      setUnit(churchSite.org_unit_id);
      setUnits([{ id: churchSite.org_unit_id, name: churchSite.display_name, level_key: "church" }]);
    } else api<ChurchUnit[]>("/tenant/churches").then(setUnits).catch(()=>{});
  }, [churchSite?.id]);
  async function create(e: FormEvent) {
    e.preventDefault();setLoading(true);setMessage("");setError("");
    try {
      if (mode === "link") {
        await api<Sermon>("/sermons", { method:"POST",body:JSON.stringify({title,speaker,summary,language:locale,media_kind:kind,external_url:link,org_unit_id:churchSite?.org_unit_id || unit || null}) });
      } else {
        if (!file) throw new Error(sw ? "Chagua faili" : "Select an audio/video file");
        const f=new FormData();
        f.append("media",file);f.append("title",title);f.append("speaker",speaker);f.append("summary",summary);f.append("language",locale);
        if(churchSite)f.append("org_unit_id",churchSite.org_unit_id);
        else if(unit)f.append("org_unit_id",unit);
        await uploadForm<Sermon>("/sermons/upload",f);
      }
      setMessage(sw ? "Mahubiri yamehifadhiwa kama draft. Yachapishe kutoka kwenye orodha." : "Saved as a draft. Publish it from the list below.");
      setTitle("");setSpeaker("");setSummary("");setLink("");setFile(null);await refresh();
    } catch (err) {setError(err instanceof Error?err.message:String(err));}
    finally {setLoading(false);}
  }
  async function changeStatus(item:Sermon, status:Sermon["status"], featured=false){
    setError("");setMessage("");
    try {await api(`/sermons/${item.id}/status`,{method:"PATCH",body:JSON.stringify({status,is_featured:featured})});await refresh();}
    catch(err){setError(err instanceof Error?err.message:String(err));}
  }
  return <div className="sm-panel">
    <div className="sm-head"><span>{sw ? "STUDIO YA KANISA" : "CHURCH MEDIA STUDIO"}</span><h1>{sw ? "Mahubiri na mafundisho" : "Sermons & teachings"}</h1><p>{sw ? "Pakia video/sauti au weka link. Hakuna mahubiri yatakayoonekana kwa waumini mpaka uyachapishe." : "Upload a video or audio file, or add a supported media link. Nothing appears publicly until you publish it."}</p></div>
    {error && <p className="sm-alert error" role="alert">{error}</p>}
    {message && <p className="sm-alert success" role="status">{message}</p>}
    <form onSubmit={create} className="sm-form">
      <div className="sm-switch"><button type="button" onClick={()=>setMode("link")} className={mode==="link"?"selected":""}>{sw?"Link ya YouTube/Vimeo":"Media link"}</button><button type="button" className={mode==="file"?"selected":""} onClick={()=>setMode("file")}>{sw?"Pakia faili":"Upload file"}</button></div>
      <div className="sm-fields"><label>{sw?"Jina la mahubiri":"Sermon title"}<input required minLength={3} maxLength={180} value={title} onChange={e=>setTitle(e.target.value)} placeholder={sw?"Mfano: Nguvu ya Imani":"e.g. Walking in Faith"}/></label><label>{sw?"Mhubiri":"Speaker"}<input maxLength={120} value={speaker} onChange={e=>setSpeaker(e.target.value)} placeholder={sw?"Jina la mhubiri":"Name of speaker"}/></label><label>{sw?"Kiwango cha kanisa":"Church level"}<select value={unit} disabled={!!churchSite} onChange={e=>setUnit(e.target.value)}>{!churchSite && <option value="">{sw?"Taasisi nzima (kwa admin mkuu)":"Entire tenant (top-level admins only)"}</option>}{units.map(u=><option key={u.id} value={u.id}>{u.name}</option>)}</select></label>
      <label>{sw?"Aina ya mahubiri":"Format"}<select value={kind} onChange={e=>setKind(e.target.value as "audio"|"video")}><option value="video">Video</option><option value="audio">Audio</option></select></label>
      <label className="sm-wide">{sw?"Maelezo mafupi":"Description"}<textarea maxLength={2000} rows={3} value={summary} onChange={e=>setSummary(e.target.value)}/></label>
      {mode==="link"?<label className="sm-wide">{sw?"Link ya video/audio":"Media URL"}<input type="url" required value={link} onChange={e=>setLink(e.target.value)} placeholder="https://www.youtube.com/watch?v=..."/><small>HTTPS YouTube / Vimeo / SoundCloud</small></label>:<label className="sm-wide">{sw?"Faili la MP3, WAV, OGG, MP4 au WebM":"MP3, WAV, OGG, MP4 or WebM"}<input type="file" required accept="audio/mpeg,audio/wav,audio/ogg,video/mp4,video/webm" onChange={e=>setFile(e.target.files?.[0]||null)}/><small>{sw?"Kwa majaribio: hadi MB 25. Video kubwa: tumia link.":"Demo upload: up to 25 MB. Use links for large videos."}</small></label>}
      </div><button className="sm-save" type="submit" disabled={loading}>{loading ? (sw?"Inahifadhi...":"Saving..."):(sw?"Hifadhi draft":"Save draft")} ↗</button>
    </form>
    <section className="sm-library"><div className="sm-library-head"><h2>{sw?"Mahubiri yaliyohifadhiwa":"Media library"}</h2><small>{sermons.length} {sw?"mahudhurio":"items"}</small></div>
      {sermons.length===0?<p className="sm-noitems">{sw?"Hakuna mahubiri yaliyowekwa bado.":"No sermons added yet."}</p>:sermons.map(s=><div className="sm-item" key={s.id}><span className="sm-item-icon">{s.media_kind === "audio"?"♫":"▶"}</span><div className="sm-item-main"><strong>{s.title}</strong><span>{s.speaker || "—"} · {s.media_kind} · {s.status}</span></div><div className="sm-item-actions">{s.status!=="published"?<button onClick={()=>changeStatus(s,"published",s.is_featured)}>{sw?"Chapisha":"Publish"}</button>:<><button onClick={()=>changeStatus(s,"published",!s.is_featured)}>{s.is_featured?(sw?"Ondoa featured":"Unfeature"):(sw?"Weka featured":"Feature")}</button><button onClick={()=>changeStatus(s,"archived")}>{sw?"Ficha":"Archive"}</button></>}{s.status==="archived"&&<button onClick={()=>changeStatus(s,"draft")}>{sw?"Rudisha draft":"Restore draft"}</button>}</div></div>)}
    </section>
  </div>;
}
