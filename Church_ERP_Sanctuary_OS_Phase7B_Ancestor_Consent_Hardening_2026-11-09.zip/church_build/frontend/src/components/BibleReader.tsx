import { useEffect, useState } from "react";

interface Verse { chapter: number; verse: number; text: string }
interface BibleData { verses: Verse[]; translation: { name: string; license: string } }
interface Book { id: string; name: string }
const preferredBooks: Book[] = [
  {id:"GEN",name:"Genesis"},{id:"PSA",name:"Psalms"},{id:"PRO",name:"Proverbs"},
  {id:"ISA",name:"Isaiah"},{id:"MAT",name:"Matthew"},{id:"MRK",name:"Mark"},
  {id:"LUK",name:"Luke"},{id:"JHN",name:"John"},{id:"ACT",name:"Acts"},
  {id:"ROM",name:"Romans"},{id:"1CO",name:"1 Corinthians"},
  {id:"EPH",name:"Ephesians"},{id:"PHP",name:"Philippians"},{id:"REV",name:"Revelation"}
];
const cache = new Map<string, Verse[]>();

export function BibleReader({ onClose, sw }: { onClose: () => void; sw: boolean }) {
  const [books, setBooks] = useState<Book[]>(preferredBooks);
  const [book, setBook] = useState("JHN");
  const [chapter, setChapter] = useState(3);
  const [verses, setVerses] = useState<Verse[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [fontSize, setFontSize] = useState(18);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const onEsc = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    document.addEventListener("keydown", onEsc);
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onEsc); document.body.style.overflow = ""; };
  }, [onClose]);

  useEffect(() => {
    fetch("https://bible-api.com/data/web")
      .then((res) => res.ok ? res.json() : Promise.reject(new Error("Unavailable")))
      .then((data: { books?: Array<{ id?: string; name?: string }> } | Array<{ id?: string; name?: string }>) => {
        const list = Array.isArray(data) ? data : data.books ?? [];
        const verified = list.filter((b): b is { id: string; name: string } => !!b.id && !!b.name);
        if (verified.length) setBooks(verified);
      }).catch(() => {});
  }, []);

  useEffect(() => {
    const k = `${book}/${chapter}`;
    if (cache.has(k)) { setVerses(cache.get(k)!); setError(""); return; }
    const ctrl = new AbortController();
    setLoading(true); setError(""); setVerses([]);
    fetch(`https://bible-api.com/data/web/${encodeURIComponent(book)}/${chapter}`, { signal: ctrl.signal })
      .then(res => res.ok ? res.json() as Promise<BibleData> : Promise.reject(new Error("Chapter unavailable")))
      .then(data => {
        if (!Array.isArray(data.verses)) throw new Error("Invalid Bible response");
        cache.set(k, data.verses); setVerses(data.verses);
      })
      .catch(err => { if (err.name !== "AbortError") setError(sw ? "Mtandao haujapatikana. Jaribu tena ukiwa online." : "Could not load the chapter. Check your connection and try again."); })
      .finally(() => setLoading(false));
    return () => ctrl.abort();
  }, [book, chapter, sw]);

  const shown = verses.filter(v => !search.trim() || v.text.toLowerCase().includes(search.trim().toLowerCase()));
  return <div className="bible-modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.currentTarget === e.target) onClose(); }}>
    <section className="bible-reader" role="dialog" aria-modal="true" aria-labelledby="bible-reader-title">
      <div className="reader-toolbar">
        <div><span className="reader-kicker">THE WORD · WORLD ENGLISH BIBLE</span><h2 id="bible-reader-title">{sw ? "Soma Biblia" : "Read the Bible"}</h2></div>
        <button className="reader-close" type="button" onClick={onClose} aria-label={sw ? "Funga" : "Close"}>✕</button>
      </div>
      <div className="reader-controls">
        <label>{sw ? "Kitabu" : "Book"}<select value={book} onChange={e => {setBook(e.target.value);setChapter(1)}}>{books.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}</select></label>
        <label>{sw ? "Sura" : "Chapter"}<input type="number" min={1} max={150} value={chapter} onChange={e => setChapter(Math.max(1,Math.min(150,Number(e.target.value)||1)))}/></label>
        <label className="reader-search-label">{sw ? "Tafuta katika sura" : "Find in chapter"}<input type="search" value={search} onChange={e=>setSearch(e.target.value)} placeholder={sw ? "Tafuta neno..." : "Search a word..."}/></label>
        <div className="reader-font"><span>{sw ? "Ukubwa" : "Text"}</span><button type="button" onClick={()=>setFontSize(n=>Math.max(16,n-2))} aria-label="Smaller text">A−</button><button type="button" onClick={()=>setFontSize(n=>Math.min(28,n+2))} aria-label="Larger text">A+</button></div>
      </div>
      <div className="reader-page" aria-live="polite" aria-busy={loading}>
        <h3>{books.find(b=>b.id===book)?.name ?? book} <span>{chapter}</span></h3>
        {loading && <p className="reader-note">{sw ? "Inapakia maandiko..." : "Loading scripture..."}</p>}
        {error && <div className="reader-note" role="alert">{error} <a href="https://ebible.org/engwebp/" target="_blank" rel="noreferrer">{sw ? "Soma kwenye eBible" : "Read at eBible"} ↗</a></div>}
        {!loading && !error && shown.length === 0 && <p className="reader-note">{sw ? "Hakuna mistari inayolingana." : "No matching verses."}</p>}
        {shown.map(v => <p className="reader-verse" key={v.verse} style={{fontSize}}><sup>{v.verse}</sup>{v.text.trim()}</p>)}
      </div>
      <div className="reader-foot"><span>{sw ? "Maandiko halisi; hayabadilishwi ndani ya mfumo." : "Authentic scripture; text is read-only."} · WEB (Public Domain)</span><span>eBible.org · bible-api.com</span></div>
    </section>
  </div>;
}
