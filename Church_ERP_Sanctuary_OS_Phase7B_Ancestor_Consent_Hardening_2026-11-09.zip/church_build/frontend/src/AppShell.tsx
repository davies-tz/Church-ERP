import { useEffect, useState } from "react";
import { api, clearToken } from "./lib/api";
import { Branding } from "./lib/branding";
import type { PublicChurchSite } from "./lib/churchSites";
import { fetchPermissions, Permissions } from "./lib/permissions";
import { Me } from "./lib/types";
import { makeT } from "./i18n";
import { ChangePassword } from "./components/ChangePassword";
import { NotificationBell } from "./components/NotificationBell";
import { VerificationBanner } from "./components/VerificationBanner";
import { LanguageToggle } from "./components/LanguageToggle";
import { AnnouncementCard } from "./components/AnnouncementCard";
import { DashboardPage } from "./pages/DashboardPage";
import { MemberHome } from "./pages/MemberHome";
import { SermonsManager } from "./pages/SermonsManager";
import { ChurchWebsitePage } from "./pages/ChurchWebsitePage";
import { VerifyPage } from "./pages/VerifyPage";
import { MembersPage } from "./pages/MembersPage";
import { StructurePage } from "./pages/StructurePage";
import { RequestsPage } from "./pages/RequestsPage";
import { TransfersPage } from "./pages/TransfersPage";
import { AnnouncementsPage } from "./pages/AnnouncementsPage";
import { FinancePage } from "./pages/FinancePage";
import { AssetsPage } from "./pages/AssetsPage";
import { UsersPage } from "./pages/UsersPage";

interface Props {
  branding: Branding;
  churchSite: PublicChurchSite | null;
  locale: string;
  onLocaleChange: (locale: string) => void;
  onLogout: () => void;
}

export function AppShell({ branding, churchSite, locale, onLocaleChange, onLogout }: Props) {
  const t = makeT(locale);
  const [me, setMe] = useState<Me | null>(null);
  const [perms, setPerms] = useState<Permissions | null>(null);
  const [section, setSection] = useState<string>("dashboard");
  const [showChangePw, setShowChangePw] = useState(false);
  // Scoped to each church, so demo tenants never share accessibility settings.
  const [simpleMode, setSimpleMode] = useState(() =>
    localStorage.getItem(`cerp_simple_mode:${branding.slug}`) === "true"
  );

  function toggleSimpleMode() {
    setSimpleMode((current) => {
      localStorage.setItem(`cerp_simple_mode:${branding.slug}`, String(!current));
      return !current;
    });
  }

  useEffect(() => {
    api<Me>("/auth/me").then(setMe).catch(() => onLogout());
    fetchPermissions()
      .then((p) => {
        setPerms(p);
        // All roles get a plain-language welcome; finance metrics are staff-only.
        setSection("dashboard");
      })
      .catch(() => {});
  }, []);

  const caps = new Set(perms?.capabilities ?? []);
  const nav = [
    { id: "dashboard", label: t("dashboard") },
    ...(caps.has("manage_media") ? [{ id: "sermons", label: locale === "sw" ? "Mahubiri" : "Sermons" }] : []),
    ...(caps.has("manage_structure") ? [{ id: "church-websites", label: locale === "sw" ? "Tovuti za makanisa" : "Church websites" }] : []),
    ...(caps.has("manage_members") || me?.member_id
      ? [{ id: "members", label: caps.has("manage_members") ? t("members") : locale === "sw" ? "Taarifa zangu" : "My profile" }]
      : []),
    ...(caps.has("manage_structure") ? [{ id: "structure", label: t("structure") }] : []),
    { id: "requests", label: t("requests") },
    { id: "transfers", label: t("transfers") },
    { id: "announcements", label: t("announcements") },
    ...(caps.has("manage_members") ? [{ id: "verify", label: t("verify") }] : []),
    ...(caps.has("view_finance") ? [{ id: "finance", label: t("finance") }] : []),
    ...(caps.has("manage_assets") ? [{ id: "assets", label: t("assets") }] : []),
    ...(caps.has("appoint") ? [{ id: "users", label: t("users") }] : []),
  ];

  function logout() {
    clearToken();
    onLogout();
  }

  return (
    <div className={`app-shell${simpleMode ? " plain-mode" : ""}`}>
      <header className="topbar">
        <div className="brand-row">
          <div className="brand-badge sm">{branding.display_name.charAt(0)}</div>
          <strong>{branding.display_name}</strong>
        </div>
        <div className="top-right">
          {me && (
            <span className="muted">
              {me.name} · {me.role}
            </span>
          )}
          <LanguageToggle value={locale} onChange={onLocaleChange} />
          <button
            type="button"
            className="simple-view-toggle"
            aria-pressed={simpleMode}
            onClick={toggleSimpleMode}
            title={locale === "sw" ? "Maandishi makubwa na vitufe rahisi" : "Larger text and simple, easy-to-tap controls"}
          >
            {simpleMode ? (locale === "sw" ? "✓ Rahisi" : "✓ Easy view") : (locale === "sw" ? "Mwonekano rahisi" : "Easy view")}
          </button>
          <NotificationBell t={t} onNavigate={(s) => setSection(s)} />
          <button className="ghost" aria-label={locale === "sw" ? "Badili nenosiri" : "Change password"} onClick={() => setShowChangePw(true)}>
            🔑
          </button>
          <button className="ghost" onClick={logout}>
            {t("logout")}
          </button>
        </div>
      </header>

      {showChangePw && (
        <ChangePassword t={t} onClose={() => setShowChangePw(false)} />
      )}

      <div className="layout">
        <nav className="sidenav">
          {nav.map((n) => (
            <button
              key={n.id}
              className={section === n.id ? "active" : ""}
              aria-current={section === n.id ? "page" : undefined}
              onClick={() => setSection(n.id)}
            >
              {n.label}
            </button>
          ))}
        </nav>
        <main className="main-area">
          <VerificationBanner t={t} />
          <AnnouncementCard t={t} onNavigate={(s) => setSection(s)} />
          {section === "dashboard" && (caps.has("view_reports") ? (
            <DashboardPage locale={locale} t={t} caps={caps} onNavigate={(s) => setSection(s)} />
          ) : (
            <MemberHome locale={locale} onNavigate={(s) => setSection(s)} />
          ))}
          {section === "sermons" && caps.has("manage_media") && <SermonsManager locale={locale} churchSite={churchSite} />}
          {section === "church-websites" && caps.has("manage_structure") && <ChurchWebsitePage locale={locale} />}
          {section === "members" && (
            <MembersPage caps={caps} locale={locale} t={t} me={me} />
          )}
          {section === "structure" && (
            <StructurePage caps={caps} locale={locale} t={t} />
          )}
          {section === "requests" && (
            <RequestsPage caps={caps} locale={locale} t={t} />
          )}
          {section === "transfers" && <TransfersPage t={t} caps={caps} me={me} />}
          {section === "announcements" && <AnnouncementsPage t={t} caps={caps} />}
          {section === "verify" && <VerifyPage t={t} />}
          {section === "finance" && (
            <FinancePage caps={caps} locale={locale} t={t} />
          )}
          {section === "assets" && (
            <AssetsPage caps={caps} locale={locale} t={t} />
          )}
          {section === "users" && <UsersPage locale={locale} t={t} />}
        </main>
      </div>
    </div>
  );
}
