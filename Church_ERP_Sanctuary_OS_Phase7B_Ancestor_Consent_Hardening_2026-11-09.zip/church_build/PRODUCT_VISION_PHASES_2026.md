# Church ERP — product phases and implementation plan (November 2026)

## Non-negotiable architecture

- Shared platform, independent tenant experiences. Public landing pages are church-specific; no tenant directory on the church homepage.
- Tenant resolution: verified custom domain or subdomain. `?tenant=` supported only in local/demo mode. Backend authorization always checks tenant and org-unit scope; PostgreSQL RLS remains mandatory.
- Separate platform-operator interface; platform operators must not appear in normal church navigation.
- Tenant-specific logos, colors, fonts, languages, media, sermons, links, and home content. Tenant admin manages only their own church content.
- Multi-level hierarchy remains configurable; users see only their authorized org units.

## Phase 5 — Membership and governance

Family relationships, leadership appointments/terms, attendance, meetings/minutes, approval workflows. Tests: member privacy, hierarchy scopes, audit entries.

## Phase 6 — Financial operations

Budgets, project/campaign fundraising, procurement approvals, income-generating assets, reports. Tests: accountant-only posting, approval separation, audit trails, balance consistency.

## Phase 7 — Public identity and sermons (CURRENT START)

1. Tenant-specific responsive homepage and identity. **Initial implementation added:** `PublicHome.tsx` and `PublicHome.css`.
2. Design a `sermons` table with tenant_id, org_unit_id, title, summary, speaker, language, media_type, storage_key/external_url, duration, published_at, status, created_by, timestamps.
3. Tenant-authorized upload with type/size limits, storage isolation, virus scanning, signed URLs, thumbnail generation and transcoding where required.
4. Draft → review → published → archived workflow, scoped to authorized media editors.
5. Public API lists only published sermons for the current verified tenant; featured sermons and latest sermons appear on public home; accessible video/audio controls and transcripts when available.
6. Never upload videos to frontend source code or expose private MinIO credentials to the browser.

**Exit:** Two tenants show distinct homepages and different sermons; unpublished and cross-tenant media cannot be accessed.

## Phase 8 — Bible experience and dashboard redesign

- Bible: an animated, realistic *visual representation* of a physical Bible opening, with a real reader behind it. Reader has book/chapter/verse navigation, search, text scaling, and bookmarks. Source translations only from public-domain or properly licensed texts; do not modify sacred text. Distinguish illustration from scripture source. Respect reduced-motion and keyboard interaction.
- Dashboard: role-adaptive **Today at Your Church** overview with 3–5 prominent actions, plain-language summaries, voice/audio assistance considered as a later enhancement, understandable charts with labels, high-contrast large targets, Kiswahili/English, optional guided mode for low digital literacy.
- Member view: announcements, sermons, worship schedule, requests, giving receipts. Leader view: pending approvals, membership, attendance. Accountant view: finance and reconciliations. Platform admin view separate.
- Usability test with literate and low-literacy participants; test mobile, slow connections, keyboard, and screen readers.

## Phase 9 — Community tools

Documents/resources, member ID cards, notification provider integrations with consent and opt-out, printable notices and low-bandwidth access.

## Phase 10 — Production readiness

Verified tenant-domain mapping; cross-tenant and cross-org isolation tests; RLS, IDOR, audit logs, strong authentication, rate limits, backups, restore tests, monitoring, storage and media security, secret rotation, TLS, privacy policies.

## Honest implementation status

As of the **Sanctuary Source Build (7 November 2026)**, source implementations have been added for published sermon APIs and media studio, a read-only World English Bible chapter reader and role-aware dashboard. The animation is not itself the Bible data; actual text is retrieved from a public-domain edition. These changes have **not passed full Docker integration testing** and are not production-ready. Independent parish microsites are **not implemented**. See `BUILD_PHASES_2026_2027.md` for current Phase 5–13 master status and acceptance criteria.

## Research update — Planning Center & Breeze/Tithely (2026-11-07)

New references studied: https://www.planningcenter.com/ , https://www.planningcenter.com/home , https://www.planningcenter.com/church-center , https://www.breezechms.com/ .

- **Planning Center insights**: tasks and reminders tied to members/events; service/worship planning, volunteer teams, check-in and calendar with room/resource conflict protection; branded member web/PWA with sermons and group activity.
- **Breeze/Tithely insights**: lower admin friction through understandable people/group/event/form workflows and useful empty states; avoid drowning non-technical staff in KPIs.
- **Product-specific originality**: church-by-church public identity while preserving denomination hierarchy and audit, editorial faith-first site, licensed scripture reader and large-button guided mode for members with different literacy levels.
- **Engineering priorities**: Phase 7B verified parish sites; Phase 8B guided usability; Phase 11 worship/calendar/volunteers; Phase 12 mobile/member journey; Phase 13 privacy-aware insights.
- **Source change started**: per-tenant Easy view preference, staff finance/asset front-end capability gates, improved secondary text contrast; all marked as source changes awaiting integration test, not complete releases.

Canonical plan: [`BUILD_PHASES_2026_2027.md`](BUILD_PHASES_2026_2027.md).
