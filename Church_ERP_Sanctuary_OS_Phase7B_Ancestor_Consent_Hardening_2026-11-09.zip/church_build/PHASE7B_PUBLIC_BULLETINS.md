# Phase 7B sprint — verified church-specific public bulletins

**Status 🔄 — implementation exists, acceptance tests not fully verified.**

## Why this feature exists

Church admins can publish public announcements on their parish's homepage without accidentally making staff/member communications public. Unlike tenant-wide notices, public bulletins are explicitly opted in; visitors to one parish see that parish's and approved ancestor-level notices, never sibling parishes' notices.

## Changed files

- `backend/alembic/versions/0020_public_bulletins.py` — adds `announcements.is_public boolean NOT NULL DEFAULT false` and an index.
- `backend/app/models/announcement.py`, `backend/app/schemas/announcement.py`, `backend/app/domain/announcements.py` — private-by-default publishing contract and minimal public DTO.
- `backend/app/api/routes/church_sites.py` — new `GET /sites/public/notices?hostname=...`; same verified Host binding and tenant RLS as other site resources.
- `backend/app/domain/public_bulletins.py` — parse ancestor org UUIDs for exact-path scoping.
- `backend/app/api/routes/announcements.py` — authenticated publish opt-in and returned visibility flag.
- `frontend/src/pages/AnnouncementsPage.tsx`, `frontend/src/i18n.ts` — English/Kiswahili consent checkbox.
- `frontend/src/pages/PublicHome.tsx`, `frontend/src/pages/PublicHome.css` — responsive editorial card layout, shown only for actual public notices.
- `backend/tests/test_church_sites.py`, `scripts/test_public_bulletins.py` — security assertions.

## Privacy/visibility rules

1. `is_public=false` by default, including all migrated legacy announcements.
2. Only logged-in roles with `manage_structure` for the selected unit can publish or opt into public visibility. Internal notifications are not affected.
3. Public endpoint first resolves the verified published site for the **real HTTP Host**; a caller-supplied hostname from an unrelated church is refused.
4. Site-specific DB query enforces tenant RLS, `is_public=True`, and **exact-site `org_unit_id`** by default. A parent-unit notice appears only with a separate `show_on_descendant_sites=true` opt-in and a database-verified parent chain. Null/unitless notices are never included in independent websites.
5. Public responses contain only `id`, `title`, `body`, `urgency` and `created_at`.
6. Private staff messages, parish sibling messages and notices from a different tenant never appear.

## Test commands

From repo root:

```powershell
python -m compileall -q backend/app backend/alembic backend/tests
python scripts/test_public_bulletins.py
python scripts/test_church_site_logic.py
python scripts/check_sermon_logic.py
node scripts/check_typescript_syntax.cjs
python scripts/check_design.py
```

On an actual **Docker + PostgreSQL** installation with the new migration:

```powershell
docker compose up -d --build
docker compose exec backend alembic upgrade head
docker compose exec backend pytest tests/test_church_sites.py -v
docker compose exec backend pytest tests/test_announcements.py -v
docker compose exec frontend npm run build
```

**Warning:** API integration and browser testing cannot be claimed passed until run against an actual PostgreSQL-backed instance. Do not use the demo passwords in production. Domain and TLS validation remain open.

## Remaining Phase 7B acceptance gates

- Real PostgreSQL+RLS tests, migration up/down test, HTTPS custom-domain routing under trusted reverse proxy.
- E2E editor, tenant-bound registration, sermon streaming, and public bulletin permissions on at least two parishes of same tenant and a different tenant.
- Accessibility test with keyboard/screen reader/mobile, and a church volunteer without technical training.
- Backups/recovery and security review before production exposure.

## 8 November 2026 — fail-closed hierarchy consistency hardening

The public bulletin endpoint now calls `scoped_ancestor_unit_ids(path, site_unit_id)` rather than trusting a materialized path alone. The helper rejects missing, malformed, repeated, or wrong-terminal-ID paths before any notice is queried; the public endpoint returns 404 instead of exposing a notice for a corrupted/mismatched church path. New offline negative tests cover all four cases. This protects public notice scope but does not replace tenant RLS and live integration testing.

**Executed locally:** `python -m compileall -q backend/app backend/alembic backend/tests`, `python scripts/test_public_bulletins.py`, `python scripts/test_church_site_logic.py`, `python scripts/check_sermon_logic.py`, `python scripts/check_design.py`, and `node scripts/check_typescript_syntax.cjs` all passed (41 TS/TSX syntax parses, 6 color contrast checks). `python -m pytest -q backend/tests/test_church_sites.py` could not collect tests because `asyncpg` is not installed; Docker executable and frontend node_modules are also unavailable. No PostgreSQL integration, full frontend build, real DNS/TLS, accessibility or E2E tests were run. **Phase 7B remains 🔄.**

### 9 November 2026 — Phase 7B unscoped bulletin isolation 🔄

- Hardened `/sites/public/notices`: public announcements with `org_unit_id IS NULL` are **not** displayed on any independent parish website. Only explicitly public notices assigned to the verified site's exact org unit or a validated ancestor are eligible. This prevents a tenant-wide unscoped announcement from inadvertently reaching every parish homepage.
- Added an offline source-regression assertion in `scripts/test_public_bulletins.py`. Ran `python scripts/test_public_bulletins.py` (PASS: both checks) and `python -m compileall -q backend/app backend/tests scripts` (PASS). These checks do **not** exercise SQL execution or RLS.
- Environment: Docker executable unavailable; `asyncpg` unavailable; frontend `node_modules` absent. PostgreSQL/RLS integration, npm production build, DNS/TLS, and browser/accessibility acceptance **not verified**. Phase 7B remains 🔄.

### 9 November 2026 — Phase 7B verified ancestry + separate descendant consent 🔄

The prior implementation treated `is_public=True` at any ancestor as permission to appear on **all** descendant parish websites. This increment changes that conservative default:

- Migration `0021_public_bulletin_descendants.py` adds `announcements.show_on_descendant_sites BOOLEAN NOT NULL DEFAULT FALSE`. Existing parent notices stay public **on their own church sites only**; no historical bulletin is automatically broadcast to child sites.
- `public_notice_unit_predicate()` selects public notices for the exact site unit, **or** public ancestor notices with `show_on_descendant_sites=True`. Sibling, tenant-wide NULL-scoped, private and cross-tenant announcements are excluded.
- `verified_ancestor_unit_ids()` checks each materialized ancestor path against actual `OrgUnit.id`, `parent_id`, `tenant_id` and canonical `path` rows under tenant RLS. If an ancestor is missing, belongs to a different tenant, or a parent link/path is inconsistent, the endpoint fails closed with HTTP 404.
- Authorized staff now have **two separate opt-in checkboxes** in English/Kiswahili: public on selected church website; additionally share with descendant church websites. The second checkbox is available only for a selected unit and is off by default. Institution-wide notices remain internal in this UI.
- Added PostgreSQL regression cases for parent consent, sibling and other-tenant isolation, unscoped notices, spoofed Host and a forged hierarchy path. Added offline pure-function and SQL-expression compilation checks. React public-home component is keyed by site identity to avoid stale demo-site state.
- Added `.github/workflows/phase7b-gates.yml` to **define** future PostgreSQL 16 RLS integration and full React production-build checks. The workflow has not been executed or reported green.

**Executed locally (evidence in `evidence/2026-11-09_source_checks.txt`):** Python `compileall` PASS, bulletin logic/consent/SQL compilation PASS, hostname/DNS-mock PASS, media check PASS, 6 approved contrast-token checks PASS, 41 TS/TSX transpile syntax checks PASS. This is **not** a PostgreSQL, TypeScript type-check, Vite build or domain acceptance pass.

**Blocked/unverified:** PostgreSQL integration could not collect tests (`ModuleNotFoundError: asyncpg`); no Docker binary; offline `npm ci` missing cached `yallist-3.1.1.tgz` (`ENOTCACHED`), so no production bundle. DNS/HTTPS, accessibility, editor E2E, backups and rollback remain unverified. **Phase 7B remains 🔄. Do not start Phase 8B on the assumption this phase is complete.**

See `PHASE7B_ACCEPTANCE_RUNBOOK.md` for remaining automatic and manual release gates.
