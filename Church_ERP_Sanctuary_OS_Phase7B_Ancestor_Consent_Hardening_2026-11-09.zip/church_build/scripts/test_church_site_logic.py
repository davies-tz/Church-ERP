"""Stand-alone, database-free Phase 7B hostname/DNS verification checks."""
import asyncio
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.domain.church_sites import normalize_hostname, domain_txt_verified, match_site_to_request


def test_hostname_rules():
    assert normalize_hostname(" StMarks.Example.ORG. ") == "stmarks.example.org"
    assert normalize_hostname("xn--bcher-kva.example.org") == "xn--bcher-kva.example.org"
    for bad in ("localhost", "grace.localhost", "127.0.0.1", "https://evil.example.com",
                "abc.example.com:80", "other.example.com@evil.test", "*.example.org",
                "../private", "singlelabel", "-site.example.org", "x..example.com"):
        try:
            normalize_hostname(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Unsafe hostname accepted: {bad}")


def test_hostname_binding():
    assert match_site_to_request("Parish.Example.ORG", "parish.example.org") == "parish.example.org"
    assert match_site_to_request("localhost", "grace.localhost", allow_demo=True) == "grace.localhost"
    assert match_site_to_request("grace.localhost", "grace.localhost", allow_demo=True) == "grace.localhost"
    for origin, requested, demo in (
        ("parish-a.example.org", "parish-b.example.org", False),
        ("parish-a.example.org", "grace.localhost", True),
        ("localhost", "parish.example.org", True),
        ("localhost", "grace.localhost", False),
        ("evil.example.org", "http://evil.example.org", False),
        ("api.example.org", "parish.example.org", False),
    ):
        try:
            match_site_to_request(origin, requested, allow_demo=demo)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Accepted cross-site request: {origin} -> {requested}")


async def test_dns_verification():
    class Record:
        def __init__(self, txt): self.strings = [txt.encode()]
    async def valid(name, rtype, **kw):
        assert name == "_sanctuary.parish.example.org" and rtype == "TXT"
        return [Record("sanctuary-site-verification=bad"), Record("sanctuary-site-verification=the-token")]
    async def invalid(name, rtype, **kw):
        return [Record("sanctuary-site-verification=not-it")]
    with patch("app.domain.church_sites.dns.asyncresolver.resolve", new=valid):
        assert await domain_txt_verified("parish.example.org", "the-token")
    with patch("app.domain.church_sites.dns.asyncresolver.resolve", new=invalid):
        assert not await domain_txt_verified("parish.example.org", "the-token")


if __name__ == "__main__":
    test_hostname_rules()
    test_hostname_binding()
    asyncio.run(test_dns_verification())
    print("PASS: hostname parsing, domain-to-Host binding, DNS TXT proof (positive and negative)")
