"""Offline Phase 7B privacy checks. No DB or internet required.

These are unit/schema/SQL-compilation checks; they DO NOT prove PostgreSQL RLS.
"""
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import dialect
from app.domain.public_bulletins import (
    ancestor_unit_ids, scoped_ancestor_unit_ids, verified_ancestor_unit_ids,
    public_notice_unit_predicate,
)
from app.schemas.announcement import AnnouncementCreate, PublicBulletin
from app.models.announcement import Announcement


def unit(tenant, uid, parent, path):
    return SimpleNamespace(tenant_id=tenant, id=uid, parent_id=parent, path=path)


def rejects(fn, *args):
    try:
        fn(*args)
    except ValueError:
        pass
    else:
        raise AssertionError(f"Unsafe input accepted: {args!r}")


def test_ancestor_proof():
    tenant, other_tenant = uuid.uuid4(), uuid.uuid4()
    root, branch, parish, unrelated = (uuid.uuid4() for _ in range(4))
    path = f"/{root}/{branch}/{parish}/"
    rows = [unit(tenant, root, None, f"/{root}/"),
            unit(tenant, branch, root, f"/{root}/{branch}/"),
            unit(tenant, parish, branch, path)]
    assert ancestor_unit_ids(path) == (root, branch, parish)
    assert scoped_ancestor_unit_ids(path, parish) == (root, branch, parish)
    assert verified_ancestor_unit_ids(path, parish, tenant, rows) == (root, branch, parish)
    assert verified_ancestor_unit_ids(path, parish, tenant, reversed(rows)) == (root, branch, parish)
    for bad in ("", "/", "abc", f"/{root}/{root}/", f"/{root}/no-uuid/",
                f"/{root}/{branch}/{parish}", f"/{root}/{branch}/../{parish}/"):
        rejects(scoped_ancestor_unit_ids, bad, parish)
    rejects(scoped_ancestor_unit_ids, path, unrelated)
    rejects(verified_ancestor_unit_ids, path, parish, tenant, rows[:-1])
    rejects(verified_ancestor_unit_ids, path, parish, other_tenant, rows)
    rejects(verified_ancestor_unit_ids, path, parish, tenant, [
        rows[0], unit(tenant, branch, unrelated, rows[1].path), rows[2]])
    rejects(verified_ancestor_unit_ids, path, parish, tenant, [
        rows[0], unit(tenant, branch, root, f"/{unrelated}/{branch}/"), rows[2]])
    rejects(verified_ancestor_unit_ids, path, parish, tenant, [
        rows[0], unit(other_tenant, branch, root, rows[1].path), rows[2]])
    rejects(verified_ancestor_unit_ids, path, parish, tenant, [rows[0], rows[0], rows[2]])


def test_publication_defaults():
    private = AnnouncementCreate(title="Internal", body="Staff briefing")
    assert private.is_public is False and private.show_on_descendant_sites is False
    local = AnnouncementCreate(title="Welcome", body="Visitor message", is_public=True)
    assert local.is_public and not local.show_on_descendant_sites
    published = AnnouncementCreate(title="Diocese", body="Open meeting", is_public=True,
                                   org_unit_id=str(uuid.uuid4()), show_on_descendant_sites=True)
    assert published.show_on_descendant_sites
    for payload in ({"show_on_descendant_sites": True},
                    {"is_public": True, "show_on_descendant_sites": True},
                    {"org_unit_id": str(uuid.uuid4()), "show_on_descendant_sites": True}):
        try:
            AnnouncementCreate(title="Invalid", body="No", **payload)
        except ValidationError:
            pass
        else:
            raise AssertionError(f"Invalid public-sharing consent accepted: {payload}")
    bulletin = PublicBulletin(id=uuid.uuid4(), title="Service", body="Come",
                              urgency="normal", created_at=datetime.now(timezone.utc))
    assert not {"tenant_id", "org_unit_id", "published_by", "is_public", "show_on_descendant_sites"} & set(bulletin.model_dump())


def test_compiled_public_bulletin_scope():
    root, child, sibling = (uuid.uuid4() for _ in range(3))
    # Test the actual SQLAlchemy predicate shape; no database execution is claimed.
    child_query = select(Announcement).where(
        Announcement.tenant_id == uuid.uuid4(), Announcement.is_public.is_(True),
        public_notice_unit_predicate(child, (root, child)))
    sql = str(child_query.compile(dialect=dialect()))
    assert "announcements.org_unit_id =" in sql
    assert "announcements.org_unit_id IN" in sql
    assert "announcements.show_on_descendant_sites IS true" in sql
    assert "announcements.is_public IS true" in sql
    compiled = child_query.compile(dialect=dialect())
    assert root in compiled.params.values() or any(root in p for p in compiled.params.values() if isinstance(p, (tuple, list)))
    assert sibling not in compiled.params.values()
    root_query = select(Announcement).where(public_notice_unit_predicate(root, (root,)))
    assert "show_on_descendant_sites" not in str(public_notice_unit_predicate(root, (root,)).compile(dialect=dialect()))
    rejects(public_notice_unit_predicate, child, (root, sibling))
    rejects(public_notice_unit_predicate, child, ())


def test_migration_default_fail_closed():
    migration = (Path(__file__).resolve().parents[1] /
                 "backend/alembic/versions/0021_public_bulletin_descendants.py").read_text()
    assert 'server_default=sa.false()' in migration
    assert 'down_revision = "0020_public_bulletins"' in migration


if __name__ == "__main__":
    test_ancestor_proof()
    test_publication_defaults()
    test_compiled_public_bulletin_scope()
    test_migration_default_fail_closed()
    print("PASS: real tenant/parent/path ancestry, explicit public-sharing consent, compiled SQL predicate, migration default")
