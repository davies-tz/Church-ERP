"""Offline fast unit smoke checks of sermon validation functions (no DB required).

Run: python scripts/check_sermon_logic.py
Does NOT replace FastAPI integration tests on Docker/PostgreSQL.
"""
import ast
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
module_source = ROOT / "backend/app/api/routes/sermons.py"
tree = ast.parse(module_source.read_text(encoding="utf-8"))
allowed_names = {"MAX_MEDIA_BYTES", "_ALLOWED_SITES", "_VALID_MIME"}
allowed_functions = {"validate_media_data", "validate_media_url", "select_range"}
nodes = [node for node in tree.body if (
    isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in allowed_names for t in node.targets)
) or (isinstance(node, ast.FunctionDef) and node.name in allowed_functions)]
namespace = {"urlparse": urlparse}
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), str(module_source), "exec"), namespace)


def rejects(fn, *args):
    try:
        fn(*args)
    except ValueError:
        return
    raise AssertionError(f"Expected ValueError from {fn.__name__}({args!r})")


validate_data = namespace["validate_media_data"]
validate_url = namespace["validate_media_url"]
select_range = namespace["select_range"]
assert validate_data(b"ID3" + b"\x00" * 16, "audio/mpeg") == "audio"
assert validate_data(b"\x00\x00\x00\x18ftypisom" + b"\x00" * 20, "video/mp4") == "video"
rejects(validate_data, b"<script>bad file</script>", "video/mp4")
rejects(validate_data, b"ID3" + b"\x00" * (25 * 1024 * 1024), "audio/mpeg")
assert validate_url("https://www.youtube.com/watch?v=abc")
rejects(validate_url, "https://youtube.com.evil.example/watch?v=x")
rejects(validate_url, "http://youtube.com/watch?v=x")
rejects(validate_url, "https://www.youtube.com@evil.example/watch?v=x")
assert select_range(None, 100) == (0, 99, False)
assert select_range("bytes=20-39", 100) == (20, 39, True)
assert select_range("bytes=-10", 100) == (90, 99, True)
rejects(select_range, "bytes=101-102", 100)
rejects(select_range, "bytes=10-1", 100)
print("PASS: media signatures, size rejection, URL allowlist, and HTTP byte-range validation")
