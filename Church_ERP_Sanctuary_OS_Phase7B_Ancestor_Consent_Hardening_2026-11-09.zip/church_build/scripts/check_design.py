"""Small offline color-contrast audit for approved Sanctuary design tokens.

Run: python scripts/check_design.py
This is a token-level check, not a substitute for WCAG browser/screen-reader QA.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CSS = (ROOT / "frontend/src/pages/PublicHome.css").read_text(encoding="utf-8")


def linear(c: int) -> float:
    x = c / 255
    return x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4


def luminance(color: str) -> float:
    rgb = [int(color[i:i+2], 16) for i in (1, 3, 5)]
    return sum(w * linear(v) for w, v in zip((0.2126, 0.7152, 0.0722), rgb))


def contrast(a: str, b: str) -> float:
    light, dark = sorted((luminance(a), luminance(b)), reverse=True)
    return (light + 0.05) / (dark + 0.05)


CASES = [
    ("Forest site: body on paper", "#1e3936", "#f7f5ef", 4.5),
    ("Forest site: dark on paper", "#132b29", "#f7f5ef", 4.5),
    ("Forest site: brass on dark", "#d8b878", "#132b29", 4.5),
    ("Forest site: secondary on paper", "#5d6a64", "#f7f5ef", 4.5),
    ("Terracotta site: body on paper", "#392c27", "#f7f5ef", 4.5),
    ("Terracotta site: text on cream", "#392c27", "#f2eae0", 4.5),
]

assert "--site-subtle:#5d6a64" in CSS, "secondary text color differs from approved token"
failed = False
for name, ink, paper, threshold in CASES:
    value = contrast(ink, paper)
    ok = value >= threshold
    failed |= not ok
    print(f"{'PASS' if ok else 'FAIL'} {name}: {value:.2f}:1 (target {threshold}:1)")
if failed:
    raise SystemExit("Contrast token check failed")
print("Core approved color tokens pass. Manual component-level audit still required.")
