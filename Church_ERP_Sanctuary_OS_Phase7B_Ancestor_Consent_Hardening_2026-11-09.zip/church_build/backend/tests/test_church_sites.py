"""Phase 7B PostgreSQL integration tests. Requires docker compose services."""
from datetime import datetime, timezone
import uuid

from httpx import ASGITransport, AsyncClient
from sqlalchemy import select

from app.core.db import SessionLocal, tenant_session
from app.main import app
from app.models import Announcement, ChurchSite, ChurchSiteDomain, OrgUnit, Sermon, Tenant


async def test_verified_sites_isolated_within_tenant_and_between_tenants(two_tenants):
    a, b = two_tenants
    suffix = uuid.uuid4().hex[:10]
    hosts = [f"north-{suffix}.example.org", f"south-{suffix}.example.org", f"east-{suffix}.example.org"]
    unit_ids = []
    for idx, tenant_id in enumerate([a, a, b]):
        async with tenant_session(tenant_id) as db:
            uid = uuid.uuid4()
            unit = OrgUnit(id=uid, tenant_id=uuid.UUID(tenant_id), level_key="parish",
                           name=f"Church {idx}", path=f"/{uid}/")
            db.add(unit)
            await db.flush()
            site = ChurchSite(tenant_id=uuid.UUID(tenant_id), org_unit_id=unit.id,
                              display_name=f"Church {idx}", theme="terracotta" if idx == 1 else "forest")
            db.add(site)
            await db.flush()
            db.add(ChurchSiteDomain(tenant_id=uuid.UUID(tenant_id), site_id=site.id,
                                    hostname=hosts[idx], verification_token="test",
                                    verified_at=datetime.now(timezone.utc)))
            db.add(Sermon(tenant_id=uuid.UUID(tenant_id), org_unit_id=unit.id,
                          title=f"Sermon {idx}", media_kind="video", media_source="external",
                          external_url="https://youtu.be/ABCDEFGHIJK", status="published",
                          published_at=datetime.now(timezone.utc)))
            db.add(Announcement(tenant_id=uuid.UUID(tenant_id), org_unit_id=unit.id,
                                title=f"Public bulletin {idx}", body="Open to all visitors",
                                urgency="normal", is_public=True))
            if idx == 0:
                db.add(Announcement(tenant_id=uuid.UUID(tenant_id), org_unit_id=unit.id,
                                    title="Staff-only message", body="Sensitive private details",
                                    urgency="urgent", is_public=False))
                db.add(Sermon(tenant_id=uuid.UUID(tenant_id), org_unit_id=unit.id,
                              title="Private draft", media_kind="video", media_source="external",
                              external_url="https://youtu.be/ABCDEFGHIJK", status="draft"))
            unit_ids.append(unit.id)
    # Pending domain should never render, even when it points to an otherwise published site.
    pending_host = f"pending-{suffix}.example.org"
    async with tenant_session(b) as db:
        east_site = (await db.execute(select(ChurchSite).where(
            ChurchSite.tenant_id == uuid.UUID(b), ChurchSite.org_unit_id == unit_ids[2]))).scalar_one()
        db.add(ChurchSiteDomain(tenant_id=uuid.UUID(b), site_id=east_site.id,
                                hostname=pending_host, verification_token="pending-proof"))
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost") as client:
        # Each public request comes from the real church's hostname.
        address = lambda host: f"https://{host}"
        north = await client.get(address(hosts[0]) + "/sites/public", params={"hostname": hosts[0]})
        south = await client.get(address(hosts[1]) + "/sites/public", params={"hostname": hosts[1]})
        east = await client.get(address(hosts[2]) + "/sites/public", params={"hostname": hosts[2]})
        pending = await client.get(address(pending_host) + "/sites/public", params={"hostname": pending_host})
        unknown = await client.get("https://unknown.example.org/sites/public", params={"hostname": "unknown.example.org"})
        feed_north = await client.get(address(hosts[0]) + "/sites/public/sermons", params={"hostname": hosts[0]})
        feed_south = await client.get(address(hosts[1]) + "/sites/public/sermons", params={"hostname": hosts[1]})
        feed_east = await client.get(address(hosts[2]) + "/sites/public/sermons", params={"hostname": hosts[2]})
        public_north = await client.get(address(hosts[0]) + "/sites/public/notices", params={"hostname": hosts[0]})
        public_south = await client.get(address(hosts[1]) + "/sites/public/notices", params={"hostname": hosts[1]})
        public_east = await client.get(address(hosts[2]) + "/sites/public/notices", params={"hostname": hosts[2]})
        spoofed_bulletins = await client.get(address(hosts[0]) + "/sites/public/notices", params={"hostname": hosts[1]})
        pending_bulletins = await client.get(address(pending_host) + "/sites/public/notices", params={"hostname": pending_host})
        not_other_site = await client.get(address(hosts[0]) + "/sites/public/sermons/" + feed_south.json()[0]["id"] + "/media",
                                          params={"hostname": hosts[0]})
        # Host A cannot pretend to be B by changing ?hostname or X-Tenant-Slug.
        spoofed_hostname = await client.get(address(hosts[0]) + "/sites/public", params={"hostname": hosts[1]})
        wrong_tenant = await client.get(address(hosts[0]) + "/tenant/branding", headers={"X-Tenant-Slug": "not-this-church"})
        limited_directory = await client.get(address(hosts[0]) + "/tenant/churches")
        tenant_slug = None
        async with SessionLocal() as db:
            tenant_slug = (await db.execute(select(Tenant.slug).where(Tenant.id == uuid.UUID(a)))).scalar_one()
        # Broad legacy tenant signup must not bypass a parish website.
        legacy_registration = await client.post(address(hosts[0]) + "/auth/register",
            headers={"X-Tenant-Slug": tenant_slug},
            json={"full_name": "Wrong Parish", "email": "wrong@example.org",
                  "password": "strong-enough", "org_unit_id": str(unit_ids[1])})
        # Site-specific registration always uses the hosting parish's unit.
        site_registration = await client.post(address(hosts[0]) + "/sites/public/register",
            params={"hostname": hosts[0]}, json={"full_name": "New Visitor",
            "email": f"site-{suffix}@example.org", "password": "strong-enough"})
        legacy = await client.get("/sermons/public", headers={"X-Tenant-Slug": tenant_slug})
        forbidden_management = await client.get("/sites/manage", headers={"X-Tenant-Slug": tenant_slug})
    assert north.status_code == south.status_code == 200
    assert north.json()["org_unit_id"] == str(unit_ids[0])
    assert south.json()["org_unit_id"] == str(unit_ids[1])
    assert east.status_code == 200 and east.json()["org_unit_id"] == str(unit_ids[2])
    assert pending.status_code == unknown.status_code == 404
    assert spoofed_hostname.status_code == 404
    assert wrong_tenant.status_code == legacy_registration.status_code == 403
    assert limited_directory.status_code == 200
    assert [u["id"] for u in limited_directory.json()] == [str(unit_ids[0])]
    assert site_registration.status_code == 201 and site_registration.json()["access_token"]
    assert [s["title"] for s in feed_north.json()] == ["Sermon 0"]
    assert [s["title"] for s in feed_south.json()] == ["Sermon 1"]
    assert [s["title"] for s in feed_east.json()] == ["Sermon 2"]
    assert public_north.status_code == public_south.status_code == public_east.status_code == 200
    assert [n["title"] for n in public_north.json()] == ["Public bulletin 0"]
    assert [n["title"] for n in public_south.json()] == ["Public bulletin 1"]
    assert [n["title"] for n in public_east.json()] == ["Public bulletin 2"]
    assert all("published_by" not in n and "org_unit_id" not in n for n in public_north.json())
    assert spoofed_bulletins.status_code == pending_bulletins.status_code == 404
    assert not_other_site.status_code == 404
    assert legacy.status_code == 200 and legacy.json() == []
    assert forbidden_management.status_code == 401


async def test_descendant_public_bulletins_need_separate_opt_in(two_tenants):
    """Real Postgres + RLS: no implicit parent broadcast, siblings or null scope."""
    tenant_a, tenant_b = two_tenants
    a, b = uuid.UUID(tenant_a), uuid.UUID(tenant_b)
    root, north, south, east = (uuid.uuid4() for _ in range(4))
    suffix = uuid.uuid4().hex[:10]
    hosts = [f"diocese-{suffix}.example.org", f"north-child-{suffix}.example.org",
             f"south-child-{suffix}.example.org", f"east-child-{suffix}.example.org"]

    async def seed_site(db, tid, uid, parent, path, hostname, name):
        db.add(OrgUnit(id=uid, tenant_id=tid, parent_id=parent, level_key="parish",
                       name=name, path=path))
        await db.flush()
        site = ChurchSite(tenant_id=tid, org_unit_id=uid, display_name=name)
        db.add(site)
        await db.flush()
        db.add(ChurchSiteDomain(tenant_id=tid, site_id=site.id,
                                hostname=hostname, verification_token="test",
                                verified_at=datetime.now(timezone.utc)))

    async with tenant_session(tenant_a) as db:
        await seed_site(db, a, root, None, f"/{root}/", hosts[0], "Diocese")
        await seed_site(db, a, north, root, f"/{root}/{north}/", hosts[1], "North")
        await seed_site(db, a, south, root, f"/{root}/{south}/", hosts[2], "South")
        db.add_all([
            Announcement(tenant_id=a, org_unit_id=root, title="Parent local only",
                         body="Only diocese site", is_public=True),
            Announcement(tenant_id=a, org_unit_id=root, title="Parent shared",
                         body="Also descendant sites", is_public=True,
                         show_on_descendant_sites=True),
            Announcement(tenant_id=a, org_unit_id=root, title="Parent internal",
                         body="Never public", is_public=False,
                         show_on_descendant_sites=False),
            Announcement(tenant_id=a, org_unit_id=north, title="North local only",
                         body="North parish", is_public=True),
            Announcement(tenant_id=a, org_unit_id=south, title="South local only",
                         body="South parish", is_public=True),
            Announcement(tenant_id=a, org_unit_id=None, title="Unscoped",
                         body="No independent site", is_public=True),
        ])
    async with tenant_session(tenant_b) as db:
        await seed_site(db, b, east, None, f"/{east}/", hosts[3], "East")
        db.add(Announcement(tenant_id=b, org_unit_id=east, title="Other tenant",
                            body="Never in A", is_public=True))

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost") as client:
        results = []
        for host in hosts:
            response = await client.get(f"https://{host}/sites/public/notices", params={"hostname": host})
            assert response.status_code == 200, response.text
            results.append({notice["title"] for notice in response.json()})
        wrong_host = await client.get(f"https://{hosts[1]}/sites/public/notices",
                                      params={"hostname": hosts[2]})
    assert results[0] == {"Parent local only", "Parent shared"}
    assert results[1] == {"Parent shared", "North local only"}
    assert results[2] == {"Parent shared", "South local only"}
    assert results[3] == {"Other tenant"}
    assert wrong_host.status_code == 404


async def test_corrupted_parent_path_rejected_before_ancestor_bulletins(two_tenants):
    """A forged path to unrelated root does not authorize another church's notice."""
    tenant_a, _ = two_tenants
    a = uuid.UUID(tenant_a)
    real_root, unrelated_root, child = (uuid.uuid4() for _ in range(3))
    host = f"corrupt-{uuid.uuid4().hex[:10]}.example.org"
    async with tenant_session(tenant_a) as db:
        db.add_all([
            OrgUnit(id=real_root, tenant_id=a, level_key="church", name="Root",
                    path=f"/{real_root}/"),
            OrgUnit(id=unrelated_root, tenant_id=a, level_key="church", name="Unrelated",
                    path=f"/{unrelated_root}/"),
        ])
        await db.flush()
        db.add(OrgUnit(id=child, tenant_id=a, parent_id=real_root,
                       level_key="parish", name="Child",
                       path=f"/{unrelated_root}/{child}/"))  # path lies about the real parent
        await db.flush()
        site = ChurchSite(tenant_id=a, org_unit_id=child, display_name="Corrupted")
        db.add(site)
        await db.flush()
        db.add(ChurchSiteDomain(tenant_id=a, site_id=site.id, hostname=host,
                                verification_token="test", verified_at=datetime.now(timezone.utc)))
        db.add(Announcement(tenant_id=a, org_unit_id=unrelated_root,
                            title="Not an ancestor", body="Must not leak", is_public=True,
                            show_on_descendant_sites=True))
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost") as client:
        response = await client.get(f"https://{host}/sites/public/notices", params={"hostname": host})
    assert response.status_code == 404
