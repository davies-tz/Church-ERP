"""Permission, isolation, data validation and media range contract tests.
Run inside Docker: docker compose exec backend pytest tests/test_sermons.py -v
"""
from datetime import datetime, timezone

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy import select

from app.api.routes.sermons import select_range, validate_media_data, validate_media_url
from app.core.db import tenant_session
from app.main import app
from app.models import Sermon


def test_media_signature_not_just_extension():
    assert validate_media_data(b"ID3" + b"\x00" * 30, "audio/mpeg") == "audio"
    assert validate_media_data(b"\x00\x00\x00\x18ftypisom" + b"\x00" * 32, "video/mp4") == "video"
    with pytest.raises(ValueError):
        validate_media_data(b"<script>malware</script>", "video/mp4")
    with pytest.raises(ValueError):
        validate_media_data(b"ID3" + b"\x00" * 30, "text/html")


def test_external_links_reject_unsafe_hosts():
    assert validate_media_url("https://www.youtube.com/watch?v=ABCDEFGHIJK")
    for url in ("http://youtube.com/watch?v=x", "https://youtube.com.evil.test/", "https://evil.test/", "javascript:alert(1)"):
        with pytest.raises(ValueError):
            validate_media_url(url)


def test_stream_byte_ranges():
    assert select_range(None, 100) == (0, 99, False)
    assert select_range("bytes=0-9", 100) == (0, 9, True)
    assert select_range("bytes=50-", 100) == (50, 99, True)
    assert select_range("bytes=-10", 100) == (90, 99, True)
    with pytest.raises(ValueError): select_range("bytes=150-", 100)
    with pytest.raises(ValueError): select_range("bytes=0-10,20-30", 100)


async def test_public_feed_filters_drafts_and_other_tenants(two_tenants):
    a, b = two_tenants
    async with tenant_session(a) as session:
        session.add(Sermon(tenant_id=a, title="Published from A", media_kind="video",
                           media_source="external", external_url="https://youtu.be/ABCDEFGHIJK",
                           status="published", published_at=datetime.now(timezone.utc)))
        session.add(Sermon(tenant_id=a, title="Secret draft", media_kind="video",
                           media_source="external", external_url="https://youtu.be/ABCDEFGHIJK", status="draft"))
    async with tenant_session(b) as session:
        session.add(Sermon(tenant_id=b, title="From B", media_kind="audio",
                           media_source="external", external_url="https://soundcloud.com/demo/test", status="published"))
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost") as client:
        # Fixture tenant slugs are test-a/test-b with a random suffix; fetch by id within tenant-independent table.
        from app.core.db import SessionLocal
        from app.models import Tenant
        async with SessionLocal() as session:
            slug_a = (await session.execute(select(Tenant.slug).where(Tenant.id == a))).scalar_one()
            slug_b = (await session.execute(select(Tenant.slug).where(Tenant.id == b))).scalar_one()
        res_a = await client.get("/sermons/public", headers={"X-Tenant-Slug": slug_a})
        res_b = await client.get("/sermons/public", headers={"X-Tenant-Slug": slug_b})
    assert res_a.status_code == 200
    assert [r["title"] for r in res_a.json()] == ["Published from A"]
    assert res_b.status_code == 200
    assert [r["title"] for r in res_b.json()] == ["From B"]
