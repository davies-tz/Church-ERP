from collections.abc import AsyncIterator

from fastapi import Depends, Header, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.db import SessionLocal, set_tenant
from app.core.config import settings
from app.domain.church_sites import normalize_hostname
from app.core.security import decode_access_token
from app.core.tenancy import resolve_tenant_slug
from app.models import ChurchSiteDomain, Tenant, User


async def get_tenant(
    request: Request,
    x_tenant_slug: str | None = Header(default=None),
) -> Tenant:
    """Resolve tenant authority from the actual HTTP Host, not a client override.

    1. Local development can explicitly choose a tenant.
    2. A verified church site hostname binds to its owning tenant (even when
       its address is a subdomain under the platform's BASE_DOMAIN).
    3. A legacy single-level <tenant>.<BASE_DOMAIN> URL remains supported.
    4. Unknown hostnames cannot select a tenant using X-Tenant-Slug alone.
    """
    host = (request.url.hostname or "").lower().removesuffix(".")
    header_slug = (x_tenant_slug or "").strip().lower()
    base = settings.BASE_DOMAIN.lower().removesuffix(".")
    base_slug = ""
    if host.endswith("." + base):
        prefix = host[:-(len(base) + 1)]
        if prefix and "." not in prefix:
            base_slug = prefix

    local = host in {"localhost", "127.0.0.1", "backend"}
    demo = settings.ENABLE_DEMO_SITE_PREVIEWS and host.endswith(".localhost")
    if local or demo:
        slug = header_slug or resolve_tenant_slug(request.headers.get("host"), None)
    else:
        try:
            hostname = normalize_hostname(host)
        except ValueError as exc:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Unknown church address") from exc
        async with SessionLocal() as session:
            routing = (await session.execute(
                select(ChurchSiteDomain, Tenant).join(Tenant, Tenant.id == ChurchSiteDomain.tenant_id).where(
                    ChurchSiteDomain.hostname == hostname,
                    ChurchSiteDomain.verified_at.is_not(None),
                    Tenant.status == "active",
                )
            )).first()
        if routing:
            _domain, tenant = routing
            if header_slug and header_slug != tenant.slug:
                raise HTTPException(status.HTTP_403_FORBIDDEN, "Church address and tenant do not match")
            return tenant
        if not base_slug:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Church domain is not verified")
        if header_slug and header_slug != base_slug:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Church address and tenant do not match")
        slug = base_slug

    if not slug:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Could not resolve tenant")
    async with SessionLocal() as session:
        tenant = (await session.execute(
            select(Tenant).where(Tenant.slug == slug, Tenant.status == "active")
        )).scalar_one_or_none()
    if not tenant:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Unknown tenant")
    return tenant


def _bearer_token(authorization: str | None) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Missing bearer token")
    return authorization.split(" ", 1)[1]


async def get_scoped_session(
    tenant: Tenant = Depends(get_tenant),
    authorization: str | None = Header(default=None),
) -> AsyncIterator[tuple[AsyncSession, User]]:
    """Authenticated + tenant-scoped DB session. Sets the RLS GUC to the caller's
    tenant and verifies the JWT belongs to the tenant of this request."""
    token = _bearer_token(authorization)
    try:
        payload = decode_access_token(token)
    except Exception:  # noqa: BLE001 - any decode error is an auth failure
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid token")

    if payload.get("tenant_id") != str(tenant.id):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Token/tenant mismatch")

    async with SessionLocal() as session:
        async with session.begin():
            await set_tenant(session, str(tenant.id))
            user = (
                await session.execute(
                    select(User).where(User.id == payload["sub"])
                )
            ).scalar_one_or_none()
            if not user or user.status != "active":
                raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Unknown user")
            yield session, user
