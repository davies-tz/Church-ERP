"""Church-specific websites. Public routes expose verified/published data only.

Important: hostname is a public lookup key, NOT an authorization credential.
Private APIs require the existing tenant JWT and scoped MANAGE_STRUCTURE grant.
"""
import secrets
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from fastapi.responses import Response
from sqlalchemy import select, case
from sqlalchemy.exc import IntegrityError

from app.api.deps import get_scoped_session
from app.core.db import SessionLocal, set_tenant
from app.core.config import settings
from app.core.storage import get as get_object, key_belongs_to
from app.domain import authz
from app.domain.church_sites import domain_txt_verified, normalize_hostname, match_site_to_request
from app.domain.public_bulletins import (scoped_ancestor_unit_ids,
    verified_ancestor_unit_ids, public_notice_unit_predicate)
from app.models import Announcement, ChurchSite, ChurchSiteDomain, OrgUnit, Sermon, Tenant
from app.schemas.church_site import DomainCreate, DomainRecord, PublicSite, SiteCreate, SiteRecord, SiteUpdate, SiteMemberRegistration
from app.schemas.sermon import SermonResponse
from app.schemas.announcement import PublicBulletin
from app.schemas.auth import RegisterRequest, TokenResponse
from app.api.routes.auth import register_member_in_unit
from app.api.routes.sermons import _response as sermon_response, select_range

router = APIRouter(prefix="/sites", tags=["church-sites"])


def _domain_record(d: ChurchSiteDomain) -> DomainRecord:
    return DomainRecord(id=str(d.id), hostname=d.hostname, verified_at=d.verified_at,
                        dns_record=f"_sanctuary.{d.hostname}",
                        dns_value=f"sanctuary-site-verification={d.verification_token}")


async def _site_record(session, s: ChurchSite) -> SiteRecord:
    domains = (await session.execute(select(ChurchSiteDomain).where(ChurchSiteDomain.site_id == s.id)
                                      .order_by(ChurchSiteDomain.hostname))).scalars().all()
    return SiteRecord(id=str(s.id), org_unit_id=str(s.org_unit_id), display_name=s.display_name,
                      tagline=s.tagline, welcome_message=s.welcome_message,
                      service_times=s.service_times, location_label=s.location_label,
                      contact_email=s.contact_email or None, theme=s.theme,
                      is_published=s.is_published, domains=[_domain_record(d) for d in domains])


async def _editable_site(session, user, site_id: uuid.UUID) -> ChurchSite:
    site = (await session.execute(select(ChurchSite).where(ChurchSite.id == site_id,
                                                         ChurchSite.tenant_id == user.tenant_id))).scalar_one_or_none()
    if site is None:
        raise HTTPException(404, "Church website not found")
    unit = (await session.execute(select(OrgUnit).where(OrgUnit.id == site.org_unit_id,
                                                       OrgUnit.tenant_id == user.tenant_id))).scalar_one_or_none()
    if unit is None:
        raise HTTPException(404, "Church unit not found")
    grants = await authz.load_grants(session, user.id)
    if not authz.can(grants, authz.MANAGE_STRUCTURE, unit.path):
        raise HTTPException(403, "Not allowed to manage this church website")
    return site


async def _public_site(hostname: str, request_host: str) -> tuple[ChurchSite, Tenant, ChurchSiteDomain]:
    """Return a verified, published mapping; tenant rows and hostname index are not RLS."""
    try:
        host = match_site_to_request(request_host, hostname,
                                     allow_demo=settings.ENABLE_DEMO_SITE_PREVIEWS)
    except ValueError as exc:
        raise HTTPException(404, "Church website not found at this address") from exc
    async with SessionLocal() as db:
        row = (await db.execute(
            select(ChurchSiteDomain, Tenant).join(Tenant, Tenant.id == ChurchSiteDomain.tenant_id)
            .where(ChurchSiteDomain.hostname == host,
                   ChurchSiteDomain.verified_at.is_not(None), Tenant.status == "active")
        )).first()
    if not row:
        raise HTTPException(404, "Church website not found")
    domain, tenant = row
    async with SessionLocal() as db:
        async with db.begin():
            await set_tenant(db, str(tenant.id))
            site = (await db.execute(select(ChurchSite).where(
                ChurchSite.id == domain.site_id, ChurchSite.tenant_id == tenant.id,
                ChurchSite.is_published.is_(True)
            ))).scalar_one_or_none()
            if site is None:
                raise HTTPException(404, "Church website not published")
            db.expunge(site)
    return site, tenant, domain


@router.get("/public", response_model=PublicSite)
async def public_website(hostname: str, request: Request):
    site, tenant, domain = await _public_site(hostname, request.url.hostname or "")
    return PublicSite(id=str(site.id), tenant_slug=tenant.slug,
                      org_unit_id=str(site.org_unit_id), hostname=domain.hostname,
                      display_name=site.display_name, tagline=site.tagline,
                      welcome_message=site.welcome_message, service_times=site.service_times,
                      location_label=site.location_label,
                      contact_email=site.contact_email, theme=site.theme)




@router.post("/public/register", response_model=TokenResponse, status_code=201)
async def public_site_registration(body: SiteMemberRegistration, hostname: str, request: Request):
    """Site visitors are registered into the resolved verified church unit.

    The submitted payload has no org-unit field; ownership comes from the DB.
    """
    site, tenant, _ = await _public_site(hostname, request.url.hostname or "")
    registration = RegisterRequest(**body.model_dump(), org_unit_id=str(site.org_unit_id))
    return await register_member_in_unit(registration, tenant)


@router.get("/public/notices", response_model=list[PublicBulletin])
async def public_site_notices(hostname: str, request: Request):
    """Only opt-in notices from this church or its ancestors, never sibling/private.

    No internal user details are serialized. Host and published-site verification
    are identical to sermons and registration and cannot be bypassed via a query.
    """
    site, tenant, _ = await _public_site(hostname, request.url.hostname or "")
    async with SessionLocal() as db:
        async with db.begin():
            await set_tenant(db, str(tenant.id))
            unit = (await db.execute(select(OrgUnit).where(
                OrgUnit.id == site.org_unit_id, OrgUnit.tenant_id == tenant.id
            ))).scalar_one_or_none()
            if not unit:
                raise HTTPException(404, "Church unit not found")
            try:
                parsed = scoped_ancestor_unit_ids(unit.path, unit.id)
                ancestors = (await db.execute(select(OrgUnit).where(
                    OrgUnit.id.in_(parsed), OrgUnit.tenant_id == tenant.id
                ))).scalars().all()
                eligible = verified_ancestor_unit_ids(unit.path, unit.id, tenant.id, ancestors)
            except ValueError as exc:
                # Never serve a potentially mis-scoped public notice.
                raise HTTPException(404, "Church hierarchy unavailable") from exc
            notices = (await db.execute(select(Announcement).where(
                Announcement.tenant_id == tenant.id,
                Announcement.is_public.is_(True),
                public_notice_unit_predicate(unit.id, eligible)
            ).order_by(
                case((Announcement.urgency == "urgent", 3),
                     (Announcement.urgency == "high", 2),
                     (Announcement.urgency == "normal", 1), else_=0).desc(),
                Announcement.created_at.desc(),
            ).limit(5))).scalars().all()
            return [PublicBulletin(id=a.id, title=a.title, body=a.body,
                                   urgency=a.urgency, created_at=a.created_at) for a in notices]


@router.get("/public/sermons", response_model=list[SermonResponse])
async def public_site_sermons(hostname: str, request: Request):
    site, tenant, _ = await _public_site(hostname, request.url.hostname or "")
    async with SessionLocal() as db:
        async with db.begin():
            await set_tenant(db, str(tenant.id))
            sermons = (await db.execute(select(Sermon).where(
                Sermon.tenant_id == tenant.id, Sermon.org_unit_id == site.org_unit_id,
                Sermon.status == "published"
            ).order_by(Sermon.is_featured.desc(), Sermon.published_at.desc()).limit(24))).scalars().all()
            return [sermon_response(s) for s in sermons]


@router.get("/public/sermons/{sermon_id}/media")
async def public_site_media(sermon_id: uuid.UUID, hostname: str, request: Request,
                            range_header: str | None = Header(default=None, alias="Range")):
    site, tenant, _ = await _public_site(hostname, request.url.hostname or "")
    async with SessionLocal() as db:
        async with db.begin():
            await set_tenant(db, str(tenant.id))
            sermon = (await db.execute(select(Sermon).where(
                Sermon.id == sermon_id, Sermon.tenant_id == tenant.id,
                Sermon.org_unit_id == site.org_unit_id, Sermon.status == "published"
            ))).scalar_one_or_none()
            if not sermon or not sermon.storage_key or not key_belongs_to(sermon.storage_key, str(tenant.id)):
                raise HTTPException(404, "Media not found")
            key, mime = sermon.storage_key, sermon.mime_type or "application/octet-stream"
    data, _ = await get_object(key)
    try:
        start, end, partial = select_range(range_header, len(data))
    except ValueError:
        return Response(status_code=416, headers={"Content-Range": f"bytes */{len(data)}", "Accept-Ranges": "bytes"})
    return Response(content=data[start:end+1], media_type=mime, status_code=206 if partial else 200,
                    headers={"Accept-Ranges":"bytes", "Content-Length":str(end-start+1),
                             "Cache-Control":"public, max-age=300", "X-Content-Type-Options":"nosniff",
                             **({"Content-Range":f"bytes {start}-{end}/{len(data)}"} if partial else {})})


@router.get("/manage", response_model=list[SiteRecord])
async def list_sites(ctx: tuple = Depends(get_scoped_session)):
    session, user = ctx
    grants = await authz.load_grants(session, user.id)
    units = (await session.execute(select(OrgUnit))).scalars().all()
    allowed_ids = {u.id for u in units if authz.can(grants, authz.MANAGE_STRUCTURE, u.path)}
    if not allowed_ids:
        raise HTTPException(403, "Not allowed to manage church websites")
    sites = (await session.execute(select(ChurchSite).where(
        ChurchSite.tenant_id == user.tenant_id, ChurchSite.org_unit_id.in_(allowed_ids)
    ).order_by(ChurchSite.display_name))).scalars().all()
    return [await _site_record(session, s) for s in sites]


@router.post("/manage", response_model=SiteRecord, status_code=201)
async def create_site(body: SiteCreate, ctx: tuple = Depends(get_scoped_session)):
    session, user = ctx
    try:
        oid = uuid.UUID(body.org_unit_id)
    except ValueError:
        raise HTTPException(400, "Invalid church unit")
    unit = (await session.execute(select(OrgUnit).where(OrgUnit.id == oid,
                                                       OrgUnit.tenant_id == user.tenant_id))).scalar_one_or_none()
    if not unit:
        raise HTTPException(404, "Church unit not found")
    grants = await authz.load_grants(session, user.id)
    if not authz.can(grants, authz.MANAGE_STRUCTURE, unit.path):
        raise HTTPException(403, "Not allowed to manage this church")
    if (await session.execute(select(ChurchSite.id).where(ChurchSite.org_unit_id == oid,
                                                        ChurchSite.tenant_id == user.tenant_id))).first():
        raise HTTPException(409, "This church already has a website")
    s = ChurchSite(tenant_id=user.tenant_id, org_unit_id=oid,
                   **body.model_dump(exclude={"org_unit_id"}, exclude_none=True))
    session.add(s)
    await session.flush()
    return await _site_record(session, s)


@router.put("/manage/{site_id}", response_model=SiteRecord)
async def update_site(site_id: uuid.UUID, body: SiteUpdate, ctx: tuple = Depends(get_scoped_session)):
    session, user = ctx
    site = await _editable_site(session, user, site_id)
    for key, value in body.model_dump().items():
        # The database stores blank contact emails as an empty string.
        setattr(site, key, value if value is not None else "")
    await session.flush()
    return await _site_record(session, site)


@router.post("/manage/{site_id}/domains", response_model=DomainRecord, status_code=201)
async def add_domain(site_id: uuid.UUID, body: DomainCreate, ctx: tuple = Depends(get_scoped_session)):
    session, user = ctx
    await _editable_site(session, user, site_id)
    try:
        host = normalize_hostname(body.hostname)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    if (await session.execute(select(ChurchSiteDomain.id).where(ChurchSiteDomain.hostname == host))).first():
        raise HTTPException(409, "This hostname is already claimed")
    domain = ChurchSiteDomain(tenant_id=user.tenant_id, site_id=site_id, hostname=host,
                              verification_token=secrets.token_urlsafe(32))
    session.add(domain)
    try:
        await session.flush()
    except IntegrityError as exc:
        raise HTTPException(409, "This hostname is already claimed") from exc
    return _domain_record(domain)


@router.post("/manage/domains/{domain_id}/verify", response_model=DomainRecord)
async def verify_domain(domain_id: uuid.UUID, ctx: tuple = Depends(get_scoped_session)):
    session, user = ctx
    domain = (await session.execute(select(ChurchSiteDomain).where(
        ChurchSiteDomain.id == domain_id, ChurchSiteDomain.tenant_id == user.tenant_id
    ))).scalar_one_or_none()
    if domain is None:
        raise HTTPException(404, "Domain not found")
    await _editable_site(session, user, domain.site_id)
    if domain.verified_at is None:
        if not await domain_txt_verified(domain.hostname, domain.verification_token):
            raise HTTPException(400, "DNS TXT verification was not found")
        domain.verified_at = datetime.now(timezone.utc)
        await session.flush()
    return _domain_record(domain)


@router.delete("/manage/domains/{domain_id}", status_code=204)
async def remove_domain(domain_id: uuid.UUID, ctx: tuple = Depends(get_scoped_session)):
    session, user = ctx
    domain = (await session.execute(select(ChurchSiteDomain).where(
        ChurchSiteDomain.id == domain_id, ChurchSiteDomain.tenant_id == user.tenant_id
    ))).scalar_one_or_none()
    if domain is None:
        raise HTTPException(404, "Domain not found")
    await _editable_site(session, user, domain.site_id)
    await session.delete(domain)
    return Response(status_code=204)
