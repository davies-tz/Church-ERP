from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.api.deps import get_tenant
from app.core.db import SessionLocal, set_tenant
from app.models import ChurchSite, ChurchSiteDomain, OrgUnit, Tenant, TenantBranding
from app.schemas.tenant import BrandingResponse, ChurchOption

router = APIRouter(prefix="/tenant", tags=["tenant"])


@router.get("/churches", response_model=list[ChurchOption])
async def churches(request: Request, tenant: Tenant = Depends(get_tenant)):
    """Church site visitors see only this parish, not a tenant-wide directory."""
    host = (request.url.hostname or "").lower().removesuffix(".")
    async with SessionLocal() as session:
        async with session.begin():
            mapped = (await session.execute(select(ChurchSiteDomain).where(
                ChurchSiteDomain.hostname == host,
                ChurchSiteDomain.tenant_id == tenant.id,
                ChurchSiteDomain.verified_at.is_not(None),
            ))).scalar_one_or_none()
        async with session.begin():
            await set_tenant(session, str(tenant.id))
            stmt = select(OrgUnit).order_by(OrgUnit.path)
            if mapped:
                # Resolve its site within RLS rather than trusting a domain index.
                site = (await session.execute(select(ChurchSite).where(
                    ChurchSite.id == mapped.site_id, ChurchSite.is_published.is_(True)
                ))).scalar_one_or_none()
                if not site:
                    raise HTTPException(status.HTTP_404_NOT_FOUND, "Church site unavailable")
                stmt = stmt.where(OrgUnit.id == site.org_unit_id)
            rows = (await session.execute(stmt)).scalars().all()
    return [
        ChurchOption(id=str(u.id), name=u.name, level_key=u.level_key) for u in rows
    ]


@router.get("/branding", response_model=BrandingResponse)
async def branding(tenant: Tenant = Depends(get_tenant)):
    """Public: lets the frontend theme the login screen before anyone signs in."""
    async with SessionLocal() as session:
        row = (
            await session.execute(
                select(Tenant)
                .options(selectinload(Tenant.branding))
                .where(Tenant.id == tenant.id)
            )
        ).scalar_one()
    b: TenantBranding = row.branding
    if not b:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No branding configured")
    return BrandingResponse(
        slug=row.slug,
        name=row.name,
        display_name=b.display_name,
        tagline=b.tagline,
        logo_light_url=b.logo_light_url,
        logo_dark_url=b.logo_dark_url,
        login_bg_url=b.login_bg_url,
        color_primary=b.color_primary,
        color_secondary=b.color_secondary,
        color_accent=b.color_accent,
        font_key=b.font_key,
        default_locale=b.default_locale,
        enabled_locales=b.enabled_locales,
    )
