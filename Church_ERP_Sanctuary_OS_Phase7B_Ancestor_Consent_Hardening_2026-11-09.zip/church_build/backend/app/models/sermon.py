"""Sermons are tenant-owned, published media; never expose unpublished assets."""
import uuid
from datetime import datetime

from sqlalchemy import Boolean, CheckConstraint, DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, TimestampMixin


class Sermon(Base, TimestampMixin):
    __tablename__ = "sermons"
    __table_args__ = (
        CheckConstraint("status IN ('draft','published','archived')", name="sermon_status_allowed"),
        CheckConstraint("media_kind IN ('audio','video')", name="sermon_kind_allowed"),
        CheckConstraint("media_source IN ('upload','external')", name="sermon_source_allowed"),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"), index=True)
    org_unit_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("org_units.id", ondelete="SET NULL"), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(180))
    summary: Mapped[str] = mapped_column(Text, default="")
    speaker: Mapped[str] = mapped_column(String(120), default="")
    language: Mapped[str] = mapped_column(String(10), default="sw")
    media_kind: Mapped[str] = mapped_column(String(8))
    media_source: Mapped[str] = mapped_column(String(10))
    storage_key: Mapped[str | None] = mapped_column(String(500), nullable=True)
    external_url: Mapped[str | None] = mapped_column(String(900), nullable=True)
    mime_type: Mapped[str | None] = mapped_column(String(80), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="draft")
    is_featured: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
