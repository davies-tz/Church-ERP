"""One public homepage per org unit, independent of denomination-wide data."""
import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, TimestampMixin


class ChurchSite(Base, TimestampMixin):
    __tablename__ = "church_sites"
    __table_args__ = (UniqueConstraint("tenant_id", "org_unit_id", name="uq_church_site_org_unit"),)

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"), index=True)
    org_unit_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("org_units.id", ondelete="CASCADE"), index=True)
    display_name: Mapped[str] = mapped_column(String(200))
    tagline: Mapped[str] = mapped_column(String(300), default="")
    welcome_message: Mapped[str] = mapped_column(Text, default="")
    service_times: Mapped[str] = mapped_column(String(300), default="")
    location_label: Mapped[str] = mapped_column(String(300), default="")
    contact_email: Mapped[str] = mapped_column(String(250), default="")
    theme: Mapped[str] = mapped_column(String(20), default="forest")
    is_published: Mapped[bool] = mapped_column(Boolean, default=True)


class ChurchSiteDomain(Base, TimestampMixin):
    """Public routing index. Deliberately NOT RLS-scoped: we need to look up tenant_id
    from a verified hostname *before* setting the tenant's RLS context. Only application
    administrators may create/verify mappings. No private church data lives here.
    """
    __tablename__ = "church_site_domains"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"), index=True)
    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("church_sites.id", ondelete="CASCADE"), index=True)
    hostname: Mapped[str] = mapped_column(String(253), unique=True, index=True)
    verification_token: Mapped[str] = mapped_column(String(100))
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
