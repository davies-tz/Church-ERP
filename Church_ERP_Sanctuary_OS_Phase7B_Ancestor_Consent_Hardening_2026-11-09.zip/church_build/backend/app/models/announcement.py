import uuid

from sqlalchemy import Boolean, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, TimestampMixin


class Announcement(Base, TimestampMixin):
    """A scoped notice published by an admin. Visible to anyone whose org unit sits
    at or below the announcement's org unit (tenant-wide when org_unit_id is null),
    ranked by urgency for the dashboard card."""

    __tablename__ = "announcements"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    # the scope this announcement is published at; null = tenant-wide
    org_unit_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("org_units.id", ondelete="CASCADE"), nullable=True, index=True
    )
    title: Mapped[str] = mapped_column(String(200))
    body: Mapped[str] = mapped_column(Text)
    # low | normal | high | urgent
    urgency: Mapped[str] = mapped_column(String(20), default="normal")
    # Opt-in: existing internal announcements must never appear on public websites.
    is_public: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    # Parent announcements are NOT automatically public on descendant parish sites.
    show_on_descendant_sites: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    published_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
