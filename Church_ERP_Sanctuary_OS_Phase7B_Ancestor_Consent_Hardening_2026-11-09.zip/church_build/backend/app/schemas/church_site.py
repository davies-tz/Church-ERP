from datetime import date, datetime

from pydantic import BaseModel, EmailStr, Field


class SiteFields(BaseModel):
    display_name: str = Field(min_length=2, max_length=200)
    tagline: str = Field(default="", max_length=300)
    welcome_message: str = Field(default="", max_length=1500)
    service_times: str = Field(default="", max_length=300)
    location_label: str = Field(default="", max_length=300)
    contact_email: EmailStr | None = None
    theme: str = Field(default="forest", pattern="^(forest|terracotta)$")
    is_published: bool = True


class SiteCreate(SiteFields):
    org_unit_id: str


class SiteUpdate(SiteFields):
    pass


class DomainCreate(BaseModel):
    hostname: str = Field(min_length=4, max_length=253)


class DomainRecord(BaseModel):
    id: str
    hostname: str
    verified_at: datetime | None
    dns_record: str
    dns_value: str


class SiteRecord(SiteFields):
    id: str
    org_unit_id: str
    domains: list[DomainRecord]


class PublicSite(BaseModel):
    id: str
    tenant_slug: str
    org_unit_id: str
    hostname: str
    display_name: str
    tagline: str
    welcome_message: str
    service_times: str
    location_label: str
    contact_email: str
    theme: str


class SiteMemberRegistration(BaseModel):
    """Visitor never selects the target org unit for a parish website."""
    full_name: str = Field(min_length=2, max_length=200)
    email: str = Field(min_length=3, max_length=255)
    password: str = Field(min_length=6, max_length=200)
    phone: str | None = None
    gender: str | None = None
    dob: date | None = None
    region: str | None = None
    district: str | None = None
