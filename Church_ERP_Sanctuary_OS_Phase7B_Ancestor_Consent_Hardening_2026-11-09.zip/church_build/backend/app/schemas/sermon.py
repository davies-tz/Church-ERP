from datetime import datetime

from pydantic import BaseModel, Field, HttpUrl


class SermonExternalCreate(BaseModel):
    title: str = Field(min_length=3, max_length=180)
    summary: str = Field(default="", max_length=2000)
    speaker: str = Field(default="", max_length=120)
    language: str = Field(default="sw", max_length=10)
    media_kind: str = "video"
    external_url: HttpUrl
    org_unit_id: str | None = None


class SermonStatusUpdate(BaseModel):
    status: str
    is_featured: bool = False


class SermonResponse(BaseModel):
    id: str
    title: str
    summary: str
    speaker: str
    language: str
    media_kind: str
    media_source: str
    external_url: str | None
    org_unit_id: str | None
    status: str
    is_featured: bool
    created_at: datetime
    published_at: datetime | None
