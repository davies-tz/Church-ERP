"""Security-critical hostname parsing and ownership verification."""
import re

import dns.asyncresolver
import dns.exception


_LABEL = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")


def normalize_hostname(value: str) -> str:
    """Only DNS hostnames; never accept arbitrary URLs, ports, IPs or wildcard labels."""
    host = value.strip().lower().removesuffix(".")
    if not host or any(x in host for x in ("/", "@", ":", "?", "#", "\\", "*")):
        raise ValueError("Enter a hostname only (e.g. parish.example.org)")
    try:
        host = host.encode("idna").decode("ascii")
    except UnicodeError as exc:
        raise ValueError("Invalid hostname") from exc
    parts = host.split(".")
    if len(parts) < 2 or len(host) > 253 or any(not _LABEL.fullmatch(part) for part in parts):
        raise ValueError("Invalid DNS hostname")
    if parts[-1].isdigit() or host.endswith(".localhost") or host.endswith(".local"):
        raise ValueError("Use a real public domain. .localhost is reserved for demo seeds.")
    return host


async def domain_txt_verified(hostname: str, token: str) -> bool:
    """Proof of control at _sanctuary.<domain>; no HTTP calls or SSRF."""
    expected = f"sanctuary-site-verification={token}"
    try:
        answers = await dns.asyncresolver.resolve(f"_sanctuary.{hostname}", "TXT", lifetime=4)
    except (dns.exception.DNSException, TimeoutError):
        return False
    for record in answers:
        value = b"".join(record.strings).decode("utf-8", errors="replace")
        if value == expected:
            return True
    return False


DEMO_HOSTNAMES = frozenset({"grace.localhost", "stmarks.localhost"})


def match_site_to_request(request_host: str | None, requested_hostname: str,
                          *, allow_demo: bool = False) -> str:
    """Bind a public website operation to its actual Host, never an arbitrary query.

    Only explicit local development can override the Host, and then only to one
    of the two known .localhost demo sites. API clients cannot impersonate an
    unrelated parish using ?hostname=other-parish.example.org.
    """
    host = (request_host or "").strip().lower().removesuffix(".")
    asked = requested_hostname.strip().lower().removesuffix(".")
    if allow_demo and asked in DEMO_HOSTNAMES and host in {"localhost", "127.0.0.1", asked}:
        return asked
    try:
        normalized_host = normalize_hostname(host)
        normalized_asked = normalize_hostname(asked)
    except ValueError as exc:
        raise ValueError("Church website hostname does not match this address") from exc
    if normalized_host != normalized_asked:
        raise ValueError("Church website hostname does not match this address")
    return normalized_host
