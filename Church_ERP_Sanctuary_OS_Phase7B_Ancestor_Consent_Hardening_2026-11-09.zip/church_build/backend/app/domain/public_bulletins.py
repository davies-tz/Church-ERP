"""Privacy-first public bulletin rules for independent church websites.

Own-unit notices require is_public; ancestor notices additionally require a
separate opt-in. Every ancestor must be verified against the real tenant tree,
not just identifiers written into the site's materialized path.
"""
import uuid
from collections.abc import Iterable

from sqlalchemy import and_, or_
from app.models.announcement import Announcement


def ancestor_unit_ids(path: str) -> tuple[uuid.UUID, ...]:
    """Parse /<root-uuid>/<child-uuid>/.../ including this church itself."""
    if not isinstance(path, str) or not path.startswith("/") or not path.endswith("/"):
        raise ValueError("Invalid church hierarchy path")
    parts = path.strip("/").split("/")
    if parts == [""]:
        return ()
    try:
        # Disallow relaxed UUID strings: the canonical paths have full UUID tokens.
        ancestors = tuple(uuid.UUID(part) for part in parts)
        if any(str(uid) != part for uid, part in zip(ancestors, parts)):
            raise ValueError("Noncanonical church hierarchy path")
        return ancestors
    except (TypeError, ValueError) as exc:
        raise ValueError("Invalid church hierarchy path") from exc


def scoped_ancestor_unit_ids(path: str, site_unit_id: uuid.UUID) -> tuple[uuid.UUID, ...]:
    """Reject missing/repeated IDs or a path ending in another church."""
    ancestors = ancestor_unit_ids(path)
    if not ancestors or ancestors[-1] != site_unit_id or len(set(ancestors)) != len(ancestors):
        raise ValueError("Church hierarchy path does not match the published site")
    return ancestors


def verified_ancestor_unit_ids(
    path: str, site_unit_id: uuid.UUID, tenant_id: uuid.UUID, units: Iterable
) -> tuple[uuid.UUID, ...]:
    """Ensure path, parent links AND tenant IDs agree for every ancestor.

    `units` are rows fetched by ID with the active tenant RLS context. A stale,
    fabricated or cross-tenant parent cannot grant public visibility.
    """
    ancestors = scoped_ancestor_unit_ids(path, site_unit_id)
    by_id = {u.id: u for u in units}
    if len(by_id) != len(ancestors):
        raise ValueError("Church hierarchy contains missing or duplicate units")
    for index, uid in enumerate(ancestors):
        unit = by_id.get(uid)
        parent_id = ancestors[index - 1] if index > 0 else None
        expected_path = "/" + "/".join(str(part) for part in ancestors[:index + 1]) + "/"
        if (unit is None or unit.tenant_id != tenant_id or
                unit.parent_id != parent_id or unit.path != expected_path):
            raise ValueError("Church hierarchy is inconsistent")
    return ancestors


def public_notice_unit_predicate(site_unit_id: uuid.UUID, verified_ancestors: tuple[uuid.UUID, ...]):
    """SQL expression: own public notices, plus explicitly shared ancestor notices.

    Callers MUST add tenant_id and is_public=True separately. Null/unscoped
    announcements and siblings are never included.
    """
    if not verified_ancestors or verified_ancestors[-1] != site_unit_id:
        raise ValueError("Verified church ancestry is required")
    parents = verified_ancestors[:-1]
    if not parents:
        return Announcement.org_unit_id == site_unit_id
    return or_(
        Announcement.org_unit_id == site_unit_id,
        and_(Announcement.org_unit_id.in_(parents), Announcement.show_on_descendant_sites.is_(True)),
    )
