"""Independent org-unit public homepages with verified domain mappings.

Revision ID: 0019_church_sites
Revises: 0018_sermons
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0019_church_sites"
down_revision = "0018_sermons"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "church_sites",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", pg.UUID(as_uuid=True), sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("org_unit_id", pg.UUID(as_uuid=True), sa.ForeignKey("org_units.id", ondelete="CASCADE"), nullable=False),
        sa.Column("display_name", sa.String(200), nullable=False),
        sa.Column("tagline", sa.String(300), nullable=False, server_default=""),
        sa.Column("welcome_message", sa.Text, nullable=False, server_default=""),
        sa.Column("service_times", sa.String(300), nullable=False, server_default=""),
        sa.Column("location_label", sa.String(300), nullable=False, server_default=""),
        sa.Column("contact_email", sa.String(250), nullable=False, server_default=""),
        sa.Column("theme", sa.String(20), nullable=False, server_default="forest"),
        sa.Column("is_published", sa.Boolean, nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.UniqueConstraint("tenant_id", "org_unit_id", name="uq_church_site_org_unit"),
        sa.CheckConstraint("theme IN ('forest','terracotta')", name="church_site_theme_allowed"),
    )
    op.create_index("ix_church_sites_tenant_id", "church_sites", ["tenant_id"])
    op.create_index("ix_church_sites_org_unit_id", "church_sites", ["org_unit_id"])
    op.execute("ALTER TABLE church_sites ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE church_sites FORCE ROW LEVEL SECURITY")
    op.execute("""
        CREATE POLICY tenant_isolation ON church_sites
        USING (tenant_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (tenant_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
    """)
    op.create_table(
        "church_site_domains",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", pg.UUID(as_uuid=True), sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("site_id", pg.UUID(as_uuid=True), sa.ForeignKey("church_sites.id", ondelete="CASCADE"), nullable=False),
        sa.Column("hostname", sa.String(253), nullable=False, unique=True),
        sa.Column("verification_token", sa.String(100), nullable=False),
        sa.Column("verified_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_church_site_domains_tenant_id", "church_site_domains", ["tenant_id"])
    op.create_index("ix_church_site_domains_site_id", "church_site_domains", ["site_id"])
    op.create_index("ix_church_site_domains_hostname", "church_site_domains", ["hostname"])
    # The non-RLS domain routing index contains only public routing metadata.
    # DB permissions for the application role still apply; it is never editable anonymously.


def downgrade() -> None:
    op.drop_table("church_site_domains")
    op.execute("DROP POLICY IF EXISTS tenant_isolation ON church_sites")
    op.drop_table("church_sites")
