"""Explicit opt-in for parish/public announcements, private by default.

Revision ID: 0020_public_bulletins
Revises: 0019_church_sites
"""
from alembic import op
import sqlalchemy as sa

revision = "0020_public_bulletins"
down_revision = "0019_church_sites"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("announcements", sa.Column("is_public", sa.Boolean(), nullable=False, server_default=sa.false()))
    op.create_index("ix_announcements_public", "announcements", ["tenant_id", "is_public", "created_at"])


def downgrade() -> None:
    op.drop_index("ix_announcements_public", table_name="announcements")
    op.drop_column("announcements", "is_public")
