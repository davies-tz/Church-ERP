"""Separate opt-in to share a public bulletin with descendant church websites.

Revision ID: 0021_public_bulletin_descendants
Revises: 0020_public_bulletins
"""
from alembic import op
import sqlalchemy as sa

revision = "0021_public_bulletin_descendants"
down_revision = "0020_public_bulletins"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Previously published notices remain public ONLY on their owning unit's site.
    # Neither private messages nor parent notices are auto-shared to parish sites.
    op.add_column("announcements", sa.Column(
        "show_on_descendant_sites", sa.Boolean(), nullable=False, server_default=sa.false()
    ))


def downgrade() -> None:
    op.drop_column("announcements", "show_on_descendant_sites")
