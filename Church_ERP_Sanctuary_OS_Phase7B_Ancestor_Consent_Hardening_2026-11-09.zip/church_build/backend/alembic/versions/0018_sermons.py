"""Tenant-isolated sermons: initial real media publishing.

Revision ID: 0018_sermons
Revises: 0017_announcements
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0018_sermons"
down_revision = "0017_announcements"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "sermons",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", pg.UUID(as_uuid=True), sa.ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("org_unit_id", pg.UUID(as_uuid=True), sa.ForeignKey("org_units.id", ondelete="SET NULL")),
        sa.Column("title", sa.String(180), nullable=False),
        sa.Column("summary", sa.Text(), nullable=False, server_default=""),
        sa.Column("speaker", sa.String(120), nullable=False, server_default=""),
        sa.Column("language", sa.String(10), nullable=False, server_default="sw"),
        sa.Column("media_kind", sa.String(8), nullable=False),
        sa.Column("media_source", sa.String(10), nullable=False),
        sa.Column("storage_key", sa.String(500)),
        sa.Column("external_url", sa.String(900)),
        sa.Column("mime_type", sa.String(80)),
        sa.Column("status", sa.String(20), nullable=False, server_default="draft"),
        sa.Column("is_featured", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("created_by", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="SET NULL")),
        sa.Column("published_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.CheckConstraint("status IN ('draft','published','archived')", name="sermon_status_allowed"),
        sa.CheckConstraint("media_kind IN ('audio','video')", name="sermon_kind_allowed"),
        sa.CheckConstraint("media_source IN ('upload','external')", name="sermon_source_allowed"),
    )
    op.create_index("ix_sermon_tenant_id", "sermons", ["tenant_id"])
    op.create_index("ix_sermon_org_unit_id", "sermons", ["org_unit_id"])
    op.create_index("ix_sermon_public_feed", "sermons", ["tenant_id", "status", "published_at"])
    op.execute("ALTER TABLE sermons ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE sermons FORCE ROW LEVEL SECURITY")
    op.execute("""
        CREATE POLICY tenant_isolation ON sermons
        USING (tenant_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (tenant_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
    """)


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS tenant_isolation ON sermons")
    op.drop_table("sermons")
