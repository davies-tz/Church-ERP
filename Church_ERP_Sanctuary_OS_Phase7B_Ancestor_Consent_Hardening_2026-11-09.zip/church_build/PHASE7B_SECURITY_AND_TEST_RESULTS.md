# Church ERP Sanctuary OS — Phase 7B follow-up increment

Date: 7 November 2026

**Status: 🔄 In progress. No ✅.** This archive extends Phase 7B but does **not** pass the release gate for independently hosted parishes.

## Implemented in this increment

1. **Real Host binding.** `/sites/public`, registration, published-sermon listing and site media require `?hostname=` to match the actual request Host. The only exception is the explicit `.localhost` demo with `ENABLE_DEMO_SITE_PREVIEWS=true`.
2. **Verified custom-domain tenant routing.** Authenticated API requests first resolve a verified domain mapping. A mismatched `X-Tenant-Slug` gets HTTP 403. Unknown custom domains cannot select an arbitrary tenant using a header. A single-level legacy tenant subdomain still works.
3. **Legacy registration guard.** Old tenant-wide `/auth/register` works on the tenant's legacy site or localhost only; an independent parish domain must use its own `/sites/public/register`, which determines church unit on the server.
4. **No public church directory on site signup.** Parish signup form no longer fetches the tenant-wide list. `/tenant/churches` is restricted to the current verified site's org unit on that domain.
5. **Sermon uploader picks the site automatically.** Authenticated sermon-manager on a parish domain targets that parish by default; it does not offer the tenant-wide option.
6. **Vite passes through the original Host.** `changeOrigin=false` is required for the API side's domain isolation.
7. **Demo exposure reduced.** PostgreSQL, Redis, MinIO and backend port bindings in `docker-compose.yml` are loopback-only. Expose **frontend** through one ngrok endpoint; do not point the same ngrok domain at multiple Docker services.
8. **Production-style static frontend recipe.** `frontend/Dockerfile.production` + `nginx.production.conf` serve a built React SPA and proxy `/api/` to the backend while preserving Host. `deploy/DockerCompose_preview_only.yml` is an example, **not a production deployment** (existing DB bootstrap secrets are still demo-grade).
9. **Negative tests added**: same-tenant and cross-tenant site resolution, unpublished content, wrong-Host spoof, wrong-tenant header, tenant-wide signup bypass, site-specific signup, scoped public church list and cross-site media denial.

## Checks actually run here

| Check | Result |
|---|---|
| Python `compileall` of app and test code | PASS (syntax only) |
| TypeScript/TSX transpile-parse (41 files) | PASS (syntax only, not type-check) |
| Pure hostname + DNS TXT mocking tests | PASS |
| Media signature + media URL + HTTP range tests | PASS |
| Approved forest/terracotta palette token contrast checks | PASS (6 checks; manual components still pending) |
| PostgreSQL + FastAPI integration suite | NOT RUN: no Docker/Postgres available in this environment; `asyncpg` missing |
| Full frontend `npm ci` + `npm run build` | NOT RUN: npm packages not available offline |
| Real TLS, DNS challenge and reverse-proxy behavior | NOT RUN: needs a real controlled domain and ingress |
| Mobile, screen-reader, usability testing | NOT RUN: needs supported devices / participant checks |

**Do not use ✅ until the pending tests above are performed and passed.**

## Commands on Windows with Docker Desktop

```powershell
Copy-Item .env.example .env
# Replace demo secrets before connecting to external users.
docker compose up -d --build
docker compose exec backend alembic upgrade head
docker compose exec backend python -m app.seeds.seed
docker compose exec backend pytest tests/test_church_sites.py -v
# For a separate frontend build check:
docker compose exec frontend npm run build
```

For local dev only (`ENABLE_DEMO_SITE_PREVIEWS=true`):
- `http://localhost:5173/?site=grace.localhost`
- `http://localhost:5173/?site=stmarks.localhost`

### Before real use

- Replace known passwords in `db/init.sql` with secret-injected app credentials, and rotate all seeded demo credentials; delete/disable demo accounts.
- Run a trusted HTTPS reverse proxy that forwards the **original Host** to both frontend and backend.
- Disable the demo site flag; use individually verified real domains (TXT proof, A/CNAME + TLS).
- Add request-rate limiting, registration abuse controls, backup/restore and tenant-level security tests.
- Confirm user testing in Kiswahili/English and accessibility on low-end phones.


### 7 November 2026 — Phase 7B public bulletin publishing (current increment) 🔄

**Built in code, not production-verified:**

- Added migration `0020_public_bulletins.py`: announcements have `is_public` with a **false** database default. All existing and future notices stay private unless an authorized editor explicitly opts into public display.
- The staff announcement form includes an English/Kiswahili public-visibility checkbox (off by default), with an explanation of who can read the notice.
- Verified church homepages now show a small editorial updates section only when actual public notices exist. No placeholder notices or tenant directory.
- New `GET /sites/public/notices?hostname=<current-host>` verifies the request Host + published site, then applies tenant RLS and selects at most five deliberately public notices from the exact site unit or ancestor units. No sibling notices, internal-only announcements, publisher identity or internal org identifiers are returned. Parent-unit propagation is explicit opt-in on the publication itself.
- Added PostgreSQL integration assertions to `backend/tests/test_church_sites.py` for private/public, same-tenant sibling, cross-tenant and hostname-spoof isolation, plus database-free boundary and schema checks in `scripts/test_public_bulletins.py`.

**Offline checks passed:** `python -m compileall`, `python scripts/test_public_bulletins.py`, existing DNS and media checks, and TypeScript/TSX transpile-parsing. **Not verified:** PostgreSQL integration, RLS, full npm production build, deployment, accessibility/user acceptance. Full frontend installation was blocked by missing npm packages (offline cache incomplete); PostgreSQL/Docker are unavailable here.

**Do not award Phase 7B ✅** until the required integration and acceptance gates pass. Status stays 🔄.

### 9 November 2026 — Phase 7B unscoped bulletin isolation 🔄

- Hardened `/sites/public/notices`: public announcements with `org_unit_id IS NULL` are **not** displayed on any independent parish website. Only explicitly public notices assigned to the verified site's exact org unit or a validated ancestor are eligible. This prevents a tenant-wide unscoped announcement from inadvertently reaching every parish homepage.
- Added an offline source-regression assertion in `scripts/test_public_bulletins.py`. Ran `python scripts/test_public_bulletins.py` (PASS: both checks) and `python -m compileall -q backend/app backend/tests scripts` (PASS). These checks do **not** exercise SQL execution or RLS.
- Environment: Docker executable unavailable; `asyncpg` unavailable; frontend `node_modules` absent. PostgreSQL/RLS integration, npm production build, DNS/TLS, and browser/accessibility acceptance **not verified**. Phase 7B remains 🔄.

### 9 November 2026 — Phase 7B verified ancestry + separate descendant consent 🔄

The prior implementation treated `is_public=True` at any ancestor as permission to appear on **all** descendant parish websites. This increment changes that conservative default:

- Migration `0021_public_bulletin_descendants.py` adds `announcements.show_on_descendant_sites BOOLEAN NOT NULL DEFAULT FALSE`. Existing parent notices stay public **on their own church sites only**; no historical bulletin is automatically broadcast to child sites.
- `public_notice_unit_predicate()` selects public notices for the exact site unit, **or** public ancestor notices with `show_on_descendant_sites=True`. Sibling, tenant-wide NULL-scoped, private and cross-tenant announcements are excluded.
- `verified_ancestor_unit_ids()` checks each materialized ancestor path against actual `OrgUnit.id`, `parent_id`, `tenant_id` and canonical `path` rows under tenant RLS. If an ancestor is missing, belongs to a different tenant, or a parent link/path is inconsistent, the endpoint fails closed with HTTP 404.
- Authorized staff now have **two separate opt-in checkboxes** in English/Kiswahili: public on selected church website; additionally share with descendant church websites. The second checkbox is available only for a selected unit and is off by default. Institution-wide notices remain internal in this UI.
- Added PostgreSQL regression cases for parent consent, sibling and other-tenant isolation, unscoped notices, spoofed Host and a forged hierarchy path. Added offline pure-function and SQL-expression compilation checks. React public-home component is keyed by site identity to avoid stale demo-site state.
- Added `.github/workflows/phase7b-gates.yml` to **define** future PostgreSQL 16 RLS integration and full React production-build checks. The workflow has not been executed or reported green.

**Executed locally (evidence in `evidence/2026-11-09_source_checks.txt`):** Python `compileall` PASS, bulletin logic/consent/SQL compilation PASS, hostname/DNS-mock PASS, media check PASS, 6 approved contrast-token checks PASS, 41 TS/TSX transpile syntax checks PASS. This is **not** a PostgreSQL, TypeScript type-check, Vite build or domain acceptance pass.

**Blocked/unverified:** PostgreSQL integration could not collect tests (`ModuleNotFoundError: asyncpg`); no Docker binary; offline `npm ci` missing cached `yallist-3.1.1.tgz` (`ENOTCACHED`), so no production bundle. DNS/HTTPS, accessibility, editor E2E, backups and rollback remain unverified. **Phase 7B remains 🔄. Do not start Phase 8B on the assumption this phase is complete.**

See `PHASE7B_ACCEPTANCE_RUNBOOK.md` for remaining automatic and manual release gates.
