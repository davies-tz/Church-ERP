# How to apply the Sanctuary OS build to Church ERP (Windows / Docker)

## 1. Back up your project, including the database

Create a copy of the current `Church_ERP-main` directory **without deleting Docker volumes**. Do not replace your current `.env` with the example from this ZIP. If working with important existing data, create a verified database backup first.

## 2. Extract and review

Extract this ZIP into a separate folder first, for example:

`C:\Users\HomePC\Desktop\Church_ERP_Research_Build_2026`

Review `BUILD_PHASES_2026_2027.md` and `DESIGN_SYSTEM.md` before selectively merging files into the main project. The existing codebase has been preserved and extended; do not delete your live `church_erp` database or MinIO volume.

## 3. Start the standalone extracted source for a local pilot

From PowerShell inside the extracted folder (copy `.env.example` to `.env`, then change secrets if this is not a local demo):

```powershell
Copy-Item .env.example .env
# Set JWT_SECRET and other secrets to strong unique values in .env.
docker compose up -d --build
docker compose exec backend alembic upgrade head
docker compose exec backend pytest tests/test_sermons.py -v
```

Open `http://localhost:5173/?tenant=grace` and `http://localhost:5173/?tenant=stmarks`.

To check design and small media logic without Docker:

```powershell
python scripts/check_design.py
python scripts/check_sermon_logic.py
```

## 4. Verify manually before broader testing

1. Grace's published sermons must not appear in St. Mark's homepage.
2. Create a sermon draft → verify hidden → publish → verify visible → archive → verify hidden again.
3. Open the Bible and confirm scripture is loaded from real World English Bible data, not fabricated placeholder words. Network is required.
4. Sign in as an ordinary member and test large-button **Mwonekano rahisi / Easy view**.
5. Check permissions on finance and assets in API, not just cards on screen.

**Important:** The service is a development build. No audit, verified custom-domain routing or production-ready live media scaling is included. Deploying to the internet requires the security and privacy gate in Phase 10.

## Phase 7B (7 November 2026)

This increment adds the Alembic revision `0019_church_sites`, a scoped site editor under **Church websites**, public domain resolution and site-level sermon streaming. Make a **database backup**, work in a separate extracted folder and test locally before merging. After `docker compose up -d --build`, run:

```powershell
docker compose exec backend alembic upgrade head
docker compose exec backend python -m app.seeds.seed
docker compose exec backend pytest tests/test_church_sites.py -v
```

Demo site addresses: `http://localhost:5173/?site=grace.localhost` and `http://localhost:5173/?site=stmarks.localhost`. The older `?tenant=` mode remains available for tenant-level development, but now its public sermons include only denomination-wide items (`org_unit_id IS NULL`); local church sermons must be scoped to an org unit and loaded from that site's verified domain. Do not deploy with seeded passwords, unverified custom domains or exposed MinIO/database/Redis ports.

**Release status: 🔄 Phase 7B under construction, not ✅.** No PostgreSQL/Docker integration tests were run by the artifact builder.


### 7 November 2026 — Phase 7B hardening, still 🔄 (not ✅)

The latest source update binds domain-specific public APIs to the real HTTP Host, resolves verified domain → tenant before accepting a client tenant header, blocks broad legacy registration from church-specific domains, and prevents parish registration/sermon pages from displaying other churches. Vite now preserves the Host; database/cache/storage/admin ports bind to loopback for the local demo.

Offline validation: Python syntax, 41 TypeScript/TSX syntax parses, hostname/DNS-mock checks, media validation and six color-token contrast checks **passed**. Docker/PostgreSQL/RLS integration, full npm build, real DNS/HTTPS, security and user acceptance remain **unverified**. See `PHASE7B_SECURITY_AND_TEST_RESULTS.md` for exact commands and evidence. **Do not mark green ✅ yet.**


### 7 November 2026 — Phase 7B public bulletin publishing (current increment) 🔄

**Built in code, not production-verified:**

- Added migration `0020_public_bulletins.py`: announcements have `is_public` with a **false** database default. All existing and future notices stay private unless an authorized editor explicitly opts into public display.
- The staff announcement form includes an English/Kiswahili public-visibility checkbox (off by default), with an explanation of who can read the notice.
- Verified church homepages now show a small editorial updates section only when actual public notices exist. No placeholder notices or tenant directory.
- New `GET /sites/public/notices?hostname=<current-host>` verifies the request Host + published site, then applies tenant RLS and selects at most five deliberately public notices from the exact site unit or ancestor units. No sibling notices, internal-only announcements, publisher identity or internal org identifiers are returned. Parent-unit propagation is explicit opt-in on the publication itself.
- Added PostgreSQL integration assertions to `backend/tests/test_church_sites.py` for private/public, same-tenant sibling, cross-tenant and hostname-spoof isolation, plus database-free boundary and schema checks in `scripts/test_public_bulletins.py`.

**Offline checks passed:** `python -m compileall`, `python scripts/test_public_bulletins.py`, existing DNS and media checks, and TypeScript/TSX transpile-parsing. **Not verified:** PostgreSQL integration, RLS, full npm production build, deployment, accessibility/user acceptance. Full frontend installation was blocked by missing npm packages (offline cache incomplete); PostgreSQL/Docker are unavailable here.

**Do not award Phase 7B ✅** until the required integration and acceptance gates pass. Status stays 🔄.
