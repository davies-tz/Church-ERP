# Phase 7B release gate — runbook (not yet passed)

**Current status: 🔄** This runbook is an executable checklist. Its presence does not prove execution.

## Automated gates

The GitHub Actions workflow `.github/workflows/phase7b-gates.yml` defines two jobs:

- PostgreSQL 16 + a **non-superuser, NOBYPASSRLS** application role, all Alembic migrations up to `0021_public_bulletin_descendants`, site isolation regressions and full backend pytest suite.
- `npm ci` and `npm run build` (the latter runs the full TypeScript type-check and Vite production bundle).

**Not executed in this environment:** external CI. A GitHub workflow file is not evidence of a passing run.

## Local development-only acceptance commands (PowerShell, from extracted project root)

```powershell
Copy-Item .env.example .env  # only if .env does not already exist
# Ensure JWT/DB/MINIO secrets are local demo-only. NEVER apply demo credentials to production.
docker compose up -d --build
# Backend container upgrades migrations on startup. Re-run explicitly to confirm head:
docker compose exec -T backend alembic upgrade head
docker compose exec -T backend alembic current
docker compose exec -T backend python -m pytest tests/test_church_sites.py -v
docker compose exec -T backend python -m pytest -v
docker compose exec -T frontend npm run build
```

**Never run a destructive migration downgrade on a production database.** To test rollback and backup/restore, first create a disposable database and preserve a verified backup of non-production data. A downgrade from `0021` removes descendant-sharing metadata: export it before any simulated rollback.

## Manual acceptance — all must pass before ✅

1. Use two parishes in the *same tenant* and a third from another tenant; each resolves to a different verified custom hostname, branding, contact, public notices and published sermons. Neither parish can retrieve private data or a sibling's media by guessing IDs. Public homepages have no global directory.
2. Parent-site public bulletin (without separate descendant consent) appears **only on its parent site**. Re-publish with `show_on_descendant_sites=true`: descendants may see it. Internal, null-scoped, sibling and cross-tenant notices must never appear on other church sites. Test an invalid parent chain and expect HTTP 404.
3. Verify fake `?hostname=`, wrong Host / tenant header, unverified TXT, withdrawn site and wrong-org registrations fail closed. Test DNS/TLS from a real trusted ingress and ensure it forwards original Host; prevent backend direct access from outside the trusted network.
4. Test localized EN/SW publishing flow, keyboard-only control of forms and media, screen reader, 200% zoom, reduced motion, mobile widths 360/390/768/1024/1440 and low bandwidth. Ensure no stale notice from a previous demo site's React state.
5. Test a **real** MP3/MP4 draft→publish→archive and byte-range playback, with unauthenticated public access only when published and properly scoped.
6. Verify tenant-scoped authorization for editor grants, active user status, finance and private member endpoints, and record audit evidence. Complete vulnerability review including account-registration abuse controls and virus-scanning strategy.
7. In a disposable PostgreSQL environment verify `alembic upgrade head`, an isolated downgrade/re-upgrade with preservation/restoration plan, backup/restore and non-superuser RLS checks. Validate real certificate issuance/renewal, production secrets and ingress before real pilot.

Record dated screenshots/command output and the exact Git commit SHA. Do not mark Phase 7B ✅ merely because offline checks pass.
